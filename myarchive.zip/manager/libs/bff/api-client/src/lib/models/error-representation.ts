/* eslint-disable */
export interface ErrorRepresentation {
  message?: string;
  status?: number;
}
