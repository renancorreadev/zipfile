/* eslint-disable */
export interface LogRepresentation {
  apiError?: string;
  dateTime?: string;
  hostname?: string;
  href?: string;
  logLevel?: string;
  message?: string;
  navigatorInfo?: string;
}
