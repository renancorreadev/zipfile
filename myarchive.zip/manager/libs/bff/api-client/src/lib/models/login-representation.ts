/* eslint-disable */
export interface LoginRepresentation {
  j_password?: string;
  j_username?: string;
}
