/* eslint-disable */
export interface StatusUp {
  status?: string;
}
