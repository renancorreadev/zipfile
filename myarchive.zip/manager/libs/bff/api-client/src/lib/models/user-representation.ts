/* eslint-disable */
export interface UserRepresentation {
  name?: string;
  roles?: Array<string>;
}
