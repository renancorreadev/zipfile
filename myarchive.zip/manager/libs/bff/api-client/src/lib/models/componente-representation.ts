/* eslint-disable */
export interface ComponenteRepresentation {
  id?: number;
  status?: string;
  version?: string;
}
