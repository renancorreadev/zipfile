import { Contract } from "libwallet"; // Importa a libwallet para interagir com contratos

/**
 * Classe intermediadora para interagir com contratos inteligentes usando libwallet.
 */
export class ContractService {
  private abi: any;
  private contractAddress: string;
  private network: string;
  private token: string;

  constructor(abi: any, contractAddress: string, network: string, token: string) {
    this.abi = abi;
    this.contractAddress = contractAddress;
    this.network = network;
    this.token = token;
  }

  /**
   * Lista todas as funções disponíveis no contrato baseado na ABI.
   */
  public listFunctions(): { name: string; type: string; inputs: any[] }[] {
    return this.abi
      .filter((item: any) => item.type === "function")
      .map((func: any) => ({
        name: func.name,
        type: func.stateMutability === "view" || func.stateMutability === "pure" ? "read" : "write",
        inputs: func.inputs,
      }));
  }

  /**
   * Executa uma função de leitura no contrato inteligente usando a libwallet.
   * @param functionName Nome da função.
   * @param params Parâmetros para a função.
   * @returns Resultado da execução.
   */
  public async executeRead(functionName: string, params: any[]) {
    try {
      const result = await Contract.read(
        functionName,
        params,
        this.contractAddress,
        this.network
      );
      return result;
    } catch (err) {
      throw err;
    }
  }

  /**
   * Executa uma função de escrita no contrato inteligente usando a libwallet.
   * @param functionName Nome da função.
   * @param params Parâmetros para a função.
   * @param pubKey Chave pública do usuário.
   * @param twoFactorAuthenticationCode Código de autenticação de dois fatores.
   * @returns Hash da transação.
   */
  public async executeWrite(
    functionName: string,
    params: any[],
    pubKey: string,
    twoFactorAuthenticationCode: string
  ) {
    try {
      const result = await Contract.write(
        pubKey,
        twoFactorAuthenticationCode,
        this.contractAddress,
        this.network,
        functionName,
        params,
        this.token
      );
      return result;
    } catch (err) {
      throw err;
    }
  }
}
