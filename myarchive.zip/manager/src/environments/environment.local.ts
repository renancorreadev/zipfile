import { ConfigurationModel, LogLevel } from '@arqt/ng15-framework';

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

/**
 * Variável com as configurações do environment local
 */
export const environment: ConfigurationModel = {
  production: false,
  projectName: 'ng15-bvlb-base-playground',
  enablePreRender: true,
  enableServerSideRender: false,
  apiBv: 'http://localhost:3200',
  apiBvConfigs: {
    health: {
      path: '/api-utils/status',
      description: 'Retorna o health-check do backend',
      method: 'GET',
      responseType: 'json',
      observe: 'body',
      withCredentials: true,
      reportProgress: false,
    },
    'accounts': {
      path: 'http://localhost:80'
    },
    log: {
      path: '/api-utils/logger',
      method: 'POST',
    },
    'api-docs': {
      path: '/v2/api-docs',
    },
  },
  logLevel: LogLevel.INFO,
  routerLogin: '/login',
  publicKey: `-----BEGIN PUBLIC KEY-----
  MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDlOJu6TyygqxfWT7eLtGDwajtN
  FOb9I5XRb6khyfD1Yt3YiCgQWMNW649887VGJiGr/L5i2osbl8C9+WJTeucF+S76
  xFxdU6jE0NQ+Z+zEdhUTooNRaY5nZiu5PgDB0ED/ZKBUSLKL7eibMxZtMlUDHjm4
  gwQco1KRMDSmXSMkDwIDAQAB
  -----END PUBLIC KEY-----`,
};
