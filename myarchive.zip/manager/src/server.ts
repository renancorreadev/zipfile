import { APP_BASE_HREF } from '@angular/common';
import { ngExpressEngine } from '@nguniversal/express-engine';
import express from 'express';
import cookieparser from 'cookie-parser';
import { existsSync, readFileSync } from 'fs';
import { join } from 'path';
import 'reflect-metadata';
import 'zone.js/dist/zone-node';
import { AppServerModule } from './main.server';
import { createProxyMiddleware } from 'http-proxy-middleware';

/** Método que contém o env NODE_TLS_REJECT_UNAUTHORIZED */
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';

/** Constante que armazena o link onde a API é executada */
const API_SERVER = 'http://localhost:3200';

/** Constante que armazena a junção do diretório atual ao dist/browser */
const DIST_FOLDER = join(process.cwd(), 'dist/browser');

/** Constante relacionada ao ambiente de PRD */
const IS_PRD = process.env['NODE_ENV'] === 'production';

import domino from 'domino';

/** Constante que realiza a leitura da junção da pasta dist/browser e o arquivo index.html
 * relacionados ao navegador
 */
const template = readFileSync(join(DIST_FOLDER, 'index.html')).toString();

/** Constante que dá suporte para a janela global e objetos do document */
const win = domino.createWindow(template);
global.window = win as Window & typeof globalThis;
Object.defineProperty(win.document.body.style, 'transform', {
  value: () => {
    return {
      enumerable: true,
      configurable: true,
    };
  },
});
global.document = win.document;

/**
 * Função que solicita requisição de headers
 * @param proxyReq
 */
function relayRequestHeaders(proxyReq: {
  getHeader: (arg0: string) => unknown;
  setHeader: (arg0: string, arg1: string) => void;
}) {
  if (proxyReq.getHeader('origin')) {
    proxyReq.setHeader('origin', API_SERVER);
  }
}

/**
 * Função de resposta headers
 * @param proxyRes
 */
function relayResponseHeaders(proxyRes: { headers: unknown }) {
  console.log('\n\n', 'proxyResponse.headers', proxyRes.headers, '\n\n');
}

/**
 * Criação do servidor
 * @returns Retorna a configuração do servidor
 */
export function app() {
  const server = express();
  const distFolder = join(process.cwd(), 'dist/browser');
  const indexHtml = existsSync(join(distFolder, 'index.original.html'))
    ? 'index.original.html'
    : 'index';

  // Our Universal express-engine (found @ https://github.com/angular/universal/tree/master/modules/express-engine)
  server.engine(
    'html',
    ngExpressEngine({
      bootstrap: AppServerModule,
    })
  );

  server.set('view engine', 'html');
  server.set('views', distFolder);

  // TODO: implement data requests securely
  server.get('/api/**', (req, res) => {
    res.status(404).send('data requests are not yet supported');
  });

  // Serve static files from /browser
  server.get(
    '*.*',
    express.static(distFolder, {
      maxAge: '1y',
    })
  );

  // All regular routes use the Universal engine
  server.get('*', (req, res) => {
    res.render(indexHtml, {
      req,
      providers: [
        { provide: APP_BASE_HREF, useValue: req.baseUrl },
        { provide: 'REQUEST', useValue: req },
        { provide: 'RESPONSE', useValue: res },
      ],
    });
  });

  return server;
}

/**
 * Define a porta de execução do servidor
 */
function run() {
  const port = process.env['PORT'] ?? 4000;

  // Start up the Node server
  const server = app();

  server.set('trust proxy', '127.0.0.1');

  if (!IS_PRD) {
    server.use(
      '/api',
      createProxyMiddleware({
        logLevel: 'debug',
        target: API_SERVER,
        secure: false, // disable SSL verification
        changeOrigin: true, // for vhosted sites, changes host header to match to target's host
        xfwd: true,
        pathRewrite: {
          '^/api/': '/',
        },
        onProxyReq: relayRequestHeaders,
        onProxyRes: relayResponseHeaders,
      })
    );
  }
  server.use(cookieparser());

  server.listen(port, () => {
    /**
     * Veracode Complains about this
     * console.log(`Node Express server listening on http://localhost:${port}`);
     */
    console.log(`Node Express server listening`);
  });
}

// Webpack will replace 'require' with '__webpack_require__'
// '__non_webpack_require__' is a proxy to Node 'require'
// The below code is to ensure that the server is run only when not requiring the bundle.

/** Proxy para NodeRequire */
declare const __non_webpack_require__: NodeRequire;

/** Módulo principal */
const mainModule = __non_webpack_require__.main;

/** Nome do arquivo do módulo */
const moduleFilename = mainModule?.filename ?? '';
if (moduleFilename === __filename || moduleFilename.includes('iisnode')) {
  run();
}

export * from './main.server';
