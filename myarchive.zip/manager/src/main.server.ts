// Verify how to enble cookie on SSR:
// https://www.npmjs.com/package/ngx-cookie-service
export { AppServerModule } from './app/app.server.module';
export { renderModule, renderModuleFactory } from '@angular/platform-server';
