/**
 * Model para definição de dados de componentes de tecnologia
 */
export interface TechItemModel {
  /** @ignore */
  tech: string;
  /** @ignore */
  version: string;
}

/**
 * Variável com os dados das versões utilizadas
 */
export const packages: TechItemModel[] = [
  { tech: 'Angular', version: '15.2.9' },
  { tech: 'Node', version: '18.16.0' },
  { tech: 'Npm', version: '9.5.1' },
  { tech: 'Typescript', version: '4.9.5' },
  { tech: 'ESLint', version: '8.33.0' },
  { tech: 'RxJS', version: '7.8.1' },
];
