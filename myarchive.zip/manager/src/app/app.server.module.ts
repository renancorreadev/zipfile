import { NgModule } from '@angular/core';
import { ServerModule } from '@angular/platform-server';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { AppModule } from './app.module';
import { InlineStyleComponent } from './shell/inline-style/inline-style.component';
import { InlineStyleModule } from './shell/inline-style/inline-style.module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { UniversalInterceptor } from './core/universal-interceptor';

@NgModule({
  bootstrap: [AppComponent, InlineStyleComponent],
  imports: [AppModule, ServerModule, NoopAnimationsModule, InlineStyleModule],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: UniversalInterceptor,
      multi: true,
    },
  ],
})
export class AppServerModule {}
