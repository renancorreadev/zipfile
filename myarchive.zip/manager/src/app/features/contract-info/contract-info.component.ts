import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


/**
 * Componente responsável pelas definições do usuário da aplicação
 */
@Component({
  selector: 'app-contract-info',
  templateUrl: './contract-info.component.html',
  styleUrls: ['./contract-info.component.scss'],
})
export class ContractInfoComponent implements OnInit {

    contractDetails = {
        name: "Real Digital",
        description: "Smart Contract do Real Digital",
        owner: '0x000000',
        symbol: 'DREX'
    };

    constructor(
        private route: ActivatedRoute,
        
    ){}

    ngOnInit(): void {
        const id = this.route.snapshot.paramMap.get('id');
        console.log('ID do contrato:', id);

    }
    
 
}
