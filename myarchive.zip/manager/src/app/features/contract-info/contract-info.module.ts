import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ContractInfoComponent } from './contract-info.component';
import { CommonModule } from '@angular/common';
import { ContractInfoRoutingModule } from './contract-info-routing.module';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  imports: [CommonModule, ContractInfoRoutingModule, SharedModule],
  declarations: [ContractInfoComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ContractInfoModule {}
