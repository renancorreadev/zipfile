import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HotSiteRoutes } from './hot-site.routing';
import { HotSiteComponent } from './hot-site.component';

@NgModule({
  imports: [CommonModule, HotSiteRoutes],
  declarations: [HotSiteComponent],
})
export class HotSiteModule {}
