import { HotSiteComponent } from './hot-site.component';
import { Routes, RouterModule } from '@angular/router';

/**
 * Armazena informações das rotas (título e descrição)
 */
/* istanbul ignore file */
const routes: Routes = [
  {
    path: '',
    component: HotSiteComponent,
    data: {
      meta: {
        title: 'back-http.title',
        description: 'back-http.text',
      },
    },
  },
];

/**
 * Armazena um módulo com diretivas de novas rotas
 */
export const HotSiteRoutes = RouterModule.forChild(routes);
