import { Component } from '@angular/core';

/**
 * Componente responsável pelo hot-site
 */
@Component({
  selector: 'app-hot-site',
  templateUrl: './hot-site.html',
})
export class HotSiteComponent {}
