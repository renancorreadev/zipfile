import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HotSiteComponent } from './hot-site.component';

describe('HotSiteComponent', () => {
  let comp: HotSiteComponent;
  let fixture: ComponentFixture<HotSiteComponent>;

  beforeEach(() => {
    const httpClientStub = { get: jest.fn(), post: jest.fn() };
    TestBed.configureTestingModule({
      declarations: [HotSiteComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [{ provide: HttpClient, useValue: httpClientStub }],
    });
    fixture = TestBed.createComponent(HotSiteComponent);
    comp = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(comp).toBeTruthy();
  });
});
