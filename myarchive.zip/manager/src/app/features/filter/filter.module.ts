import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FilterComponent } from './filter.component';
import { CommonModule } from '@angular/common';
import { FilterRoutingModule } from './filter-rounting.module';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  imports: [CommonModule, FilterRoutingModule, SharedModule],
  declarations: [FilterComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class FilterModule {}
