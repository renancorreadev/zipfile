import {EventEmitter, Component, Output } from '@angular/core';


/**
 * Componente responsável pelas definições do usuário da aplicação
 */
@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss'],
})
export class FilterComponent {
  searchTerm: string = '';

  @Output() searchEvent= new EventEmitter<string>();


  onSearch(): void {
    this.searchEvent.emit(this.searchTerm)
  }
}
