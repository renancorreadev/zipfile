/* eslint-disable @typescript-eslint/no-empty-function */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterComponent } from './filter.component';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { of } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('FilterComponent', () => {
  let component: FilterComponent;
  let fixture: ComponentFixture<FilterComponent>;
  let breakpointObserverStub;

  beforeEach(async(() => {
    breakpointObserverStub = { observe: jest.fn() };
    breakpointObserverStub.observe.mockReturnValue(of(Breakpoints.Handset));

    TestBed.configureTestingModule({
      imports: [],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [FilterComponent],
      providers: [
        { provide: BreakpointObserver, useValue: breakpointObserverStub },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
