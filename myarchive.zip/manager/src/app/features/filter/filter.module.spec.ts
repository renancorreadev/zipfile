import { FilterModule } from './filter.module';

describe('FilterModule', () => {
  let contractsModule: FilterModule;

  beforeEach(() => {
    contractsModule = new FilterModule();
  });

  it('should create an instance', () => {
    expect(contractsModule).toBeTruthy();
  });
});
