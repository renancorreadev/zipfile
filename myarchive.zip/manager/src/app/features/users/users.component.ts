import { Component, OnInit } from '@angular/core';
import { UsersService } from './users.service';

/**
 * Componente responsável pelas definições do usuário da aplicação
 */
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
})
export class UsersComponent implements OnInit {

  constructor(
    private readonly usersService: UsersService,
  ) {}

  tableHeaders = {
    id: 'Id',
    name: 'Name',
    address: 'Address',
  };

  tableData: Array<any> = [];
  isLoading = true;

  filteredItems = [...this.tableData];
  
  ngOnInit(): void {
    this.getUsers();
    
  }

  getUsers(): void {
    this.usersService.getUserAccounts().subscribe((users) => {
      users.data.forEach((user: any, index: number) => {
        this.tableData.push({id: index, name: 'nome'+ index, address: user.address});
      })
      this.filteredItems = [...this.tableData];
      this.isLoading = false;
    })
  }

  removeUser(): void {
    const aux = this.tableData.slice(1);
    this.tableData = aux;
  }

 // filteredItems = [...this.tableData];

  onSearch(searchTerm: string): void {

    this.filteredItems = this.tableData.filter((item) =>
      
       Object.values(item).some((value) => 
       {
        if(typeof value ==='string' || typeof value === 'number' || typeof value === 'boolean')
        {
          return value.toString().toLowerCase().includes(searchTerm.toLowerCase());
        }
        return false;
        }
      )
    );
  }

  action(row: any) {
    this.usersService.getUserAccountDetail(row.address).subscribe((user) => {
      console.log(user);
    })
  }
}
