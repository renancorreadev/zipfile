import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(
    private http: HttpClient,
  ) {}

  url = environment.apiBvConfigs!['accounts'].path + '/' + 'accounts';

  getUserAccounts(): Observable<any> {
    return this.http.get(this.url);
  }

  getUserAccountDetail(account: string): Observable<any> {
    return this.http.get(this.url + '/' + account);
  }
}
