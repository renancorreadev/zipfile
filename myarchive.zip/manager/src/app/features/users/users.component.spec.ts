/* eslint-disable @typescript-eslint/no-empty-function */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersComponent } from './users.component';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { of } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('UsersComponent', () => {
  let component: UsersComponent;
  let fixture: ComponentFixture<UsersComponent>;
  let breakpointObserverStub;

  beforeEach(async(() => {
    breakpointObserverStub = { observe: jest.fn() };
    breakpointObserverStub.observe.mockReturnValue(of(Breakpoints.Handset));

    TestBed.configureTestingModule({
      imports: [],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [UsersComponent],
      providers: [
        { provide: BreakpointObserver, useValue: breakpointObserverStub },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
