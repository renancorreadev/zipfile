import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { UsersComponent } from './users.component';
import { CommonModule } from '@angular/common';
import { UsersRoutingModule } from './users-rounting.module';
import { SharedModule } from '@app/shared/shared.module';
import { FilterComponent } from '../filter/filter.component';

@NgModule({
  imports: [CommonModule, UsersRoutingModule, SharedModule],
  declarations: [UsersComponent, FilterComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class UsersModule {}
