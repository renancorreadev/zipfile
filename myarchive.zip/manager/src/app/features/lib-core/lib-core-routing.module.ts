import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ErrorHandlingComponent } from './error-handling/error-handling.component';
import { ConfigurationComponent } from './configuration/configuration.component';
import { StorageComponent } from './storage/storage.component';
import { LogComponent } from './log/log.component';
import { LibCoreComponent } from './lib-core.component';

const routes: Routes = [
  {
    path: '',
    component: LibCoreComponent,
    data: {
      breadcrumb: 'Core',
    },
    children: [
      { path: '', redirectTo: 'config', pathMatch: 'full' },
      {
        path: 'config',
        component: ConfigurationComponent,
        data: {
          breadcrumb: 'Configuração',
        },
      },
      {
        path: 'log',
        component: LogComponent,
        data: {
          breadcrumb: 'Log',
        },
      },
      {
        path: 'error-handling',
        component: ErrorHandlingComponent,
        data: {
          breadcrumb: 'Erro',
        },
      },
      {
        path: 'storage',
        component: StorageComponent,
        data: {
          breadcrumb: 'Armazenamento Local',
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LibCoreRoutingModule {}
