import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LibCoreComponent } from './lib-core.component';
import { PLATFORM_ID } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LibCoreModule } from './lib-core.module';

describe('LibCoreComponent', () => {
  let comp: LibCoreComponent;
  let fixture: ComponentFixture<LibCoreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LibCoreComponent],
      imports: [HttpClientTestingModule, LibCoreModule],
      providers: [{ provide: PLATFORM_ID, useValue: 'browser' }],
    }).compileComponents();

    fixture = TestBed.createComponent(LibCoreComponent);
    comp = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(comp).toBeTruthy();
  });
});
