import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StorageComponent } from './storage.component';
import { SharedModule } from '@app/shared/shared.module';
import { BvStorageModule } from '@arqt/ng15-framework/storage';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('StorageComponent', () => {
  let component: StorageComponent;
  let fixture: ComponentFixture<StorageComponent>;

  const SESSION_KEY = 'Session_key';
  const LOCAL_KEY = 'Local_key';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedModule,
        BvStorageModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [StorageComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(StorageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should save session', () => {
    expect(sessionStorage.getItem(SESSION_KEY)).toBeUndefined();
    component.frmStorageSession.setValue({ inputSession: ['banana'] });
    component.saveSession();
    expect(sessionStorage.getItem(SESSION_KEY)).toEqual('["banana"]');
    component.removerSession();
    expect(sessionStorage.getItem(SESSION_KEY)).toBeUndefined();
  });

  it('should save local', () => {
    expect(localStorage.getItem(LOCAL_KEY)).toBeUndefined();
    component.frmStorageLocal.setValue({ inputLocal: ['tangerina'] });
    component.saveLocal();
    expect(localStorage.getItem(LOCAL_KEY)).toEqual('["tangerina"]');
    component.removerLocal();
    expect(localStorage.getItem(LOCAL_KEY)).toBeUndefined();
  });
});
