import { Component, OnInit, Inject } from '@angular/core';
import {
  BV_SESSION_STORAGE,
  BV_LOCAL_STORAGE,
  BvStorageService,
} from '@arqt/ng15-framework/storage';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';

/**
 * Componente responsável pelo gerenciamento de Storage
 */
@Component({
  selector: 'app-storage',
  templateUrl: './storage.component.html',
  styleUrls: ['./storage.component.scss'],
})
export class StorageComponent implements OnInit {
  /** @ignore */
  public sessionExampleTS = `
import { Component, OnInit, Inject } from '@angular/core';
import { BV_SESSION_STORAGE, BvStorageService } from '@arqt/ng15-framework';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-storage',
  templateUrl: './storage.component.html',
  styleUrls: ['./storage.component.scss']
})

export class StorageComponent implements OnInit {
  sessionValueSaved: string;
  private frmStorageSession: FormGroup;
  private SESSION_VALUE = "Session_key";

  constructor(@Inject(BV_SESSION_STORAGE) private storageSession: BvStorageService) {
    }


  ngOnInit() {
    this.frmStorageSession = this.formBuilder.group({
      inputSession: ['']
    });

    this.sessionValueSaved = this.storageSession.get(SESSION_VALUE);
  }

  // Session Base
  private saveSession() {
      const inputSessionValue = this.frmStorageSession.controls['inputSession'].value;
      this.storageSession.set(SESSION_VALUE, inputSessionValue);
      this.sessionValueSaved = inputSessionValue;
  }

  private removerSession() {
      this.storageSession.remove(SESSION_VALUE)
      this.sessionValueSaved = ""
  }
}`;

  /** @ignore */
  public sessionExampleHTML = `<div class="row">
  <div class="col-12">
    {{SESSION_MSG}}
  </div>
  <div class="col-12">
    <form [formGroup]="frmStorageSession" (ngSubmit)="saveSession()">
      <mat-form-field class="full-width">
        <input matInput placeholder="Valor" name="inputSession" id="inputSession" formControlName="inputSession">
      </mat-form-field>

      <div class="actions">
        <button mat-flat-button color="primary" type="submit" class="first-child">Salvar</button>
        <button mat-flat-button color="primary" (click)="removerSession()">Remover a chave</button>
      </div>
    </form>
  </div>
  <div class="col-12 result">
    {{ sessionValueSaved | json }}
  </div>
</div>`;

  /** @ignore */
  public localExampleTS = `import { Component, OnInit, Inject } from '@angular/core';
import { BV_LOCAL_STORAGE, BvStorageService } from '@arqt/ng15-framework';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-storage',
  templateUrl: './storage.component.html',
  styleUrls: ['./storage.component.scss']
})

export class StorageComponent implements OnInit {
  localValueSaved: string;
  private frmStorageValue: FormGroup;
  private LOCAL_VALUE = "Value_key";

  constructor(@Inject(BV_LOCAL_STORAGE) private localSession: BvStorageService) { }

  ngOnInit() {
    this.frmStorageLocal = this.formBuilder.group({
      inputLocal: ['']
    });

    this.localValueSaved = this.storageLocal.get(LOCAL_VALUE);
  }

  // Local Base
  private saveLocal() {
      const inputLocalValue = this.frmStorageLocal.controls['inputLocal'].value;
      this.storageLocal.set(LOCAL_VALUE, inputLocalValue);
      this.localValueSaved = inputLocalValue;
  };

  private removerLocal() {
      this.storageLocal.clear()
      this.localValueSaved = ""
  }
}`;

  /** @ignore */
  public localExampleHTML = `<div class="row">
  <div class="col-12">
    {{LOCAL_MSG}}
  </div>
  <div class="col-12">
    <form [formGroup]="frmStorageLocal" (ngSubmit)="saveLocal()">
      <mat-form-field class="full-width">
        <input matInput placeholder="Valor" name="value" id="value" formControlName="inputLocal">
      </mat-form-field>

      <div class="actions">
        <button mat-flat-button color="primary" type="submit" class="first-child">Salvar</button>
        <button mat-flat-button color="primary" (click)="removerLocal()">Limpar</button>
      </div>
    </form>
  </div>
  <div class="col-12 result">
    {{ localValueSaved | json }}
  </div>
</div>`;

  /** @ignore */
  public sessionValueSaved: string = '';
  /** @ignore */
  public localValueSaved: string = '';
  /** @ignore */
  public frmStorageSession: UntypedFormGroup = this.formBuilder.group({
    inputSession: [''],
  });
  /** @ignore */
  public frmStorageLocal: UntypedFormGroup = this.formBuilder.group({
    inputLocal: [''],
  });
  /** @ignore */
  private SESSION_KEY = 'Session_key';
  /** @ignore */
  private LOCAL_KEY = 'Local_key';

  /** @ignore */
  public exampleSCSS = `.actions {
    button {
        margin: 0 10px;
        &.first-child {
            margin: 0 10px 0 0;
        }

    }
}

.result {
  background: #d4d4d4;
  margin: 15px;
  padding: 5px;
  flex: 0 100%;
}`;

  /** @ignore */
  public SESSION_MSG =
    'Os dados irão persistir até o usuário fechar a Tab ou a Janela, extremamente útil para gravar alguns estados temporários.';
  /** @ignore */
  public LOCAL_MSG = `Os dados irão persistir até o usuário limpar os dados pelo browser
ou até o desenvolvedor chamar uma função para fazer a limpeza, perfeito para persistência de dados.`;

  /**
   * Constructor
   * @param storageSession <BvStorageService>
   * @param storageLocal <BvStorageService>
   * @param formBuilder <UntypedFormBuilder>
   */
  constructor(
    @Inject(BV_SESSION_STORAGE) private storageSession: BvStorageService,
    @Inject(BV_LOCAL_STORAGE) private storageLocal: BvStorageService,
    private formBuilder: UntypedFormBuilder
  ) {}

  /**
   * Inicialização do Componente
   */
  ngOnInit() {
    this.sessionValueSaved = this.storageSession.get(this.SESSION_KEY);
    this.localValueSaved = this.storageLocal.get(this.LOCAL_KEY);
  }

  // Session Base

  /**
   * Salva a sessão
   */
  public saveSession() {
    const inputSessionValue =
      this.frmStorageSession.controls['inputSession'].value;
    this.storageSession.set(this.SESSION_KEY, inputSessionValue);
    this.sessionValueSaved = inputSessionValue;
  }

  /**
   * Remove a sessão
   */
  public removerSession() {
    this.storageSession.remove(this.SESSION_KEY);
    this.sessionValueSaved = '';
  }

  // Local Base

  /**
   * Salva o local base
   */
  public saveLocal() {
    const inputLocalValue = this.frmStorageLocal.controls['inputLocal'].value;
    this.storageLocal.set(this.LOCAL_KEY, inputLocalValue);
    this.localValueSaved = inputLocalValue;
  }

  /**
   * Remove o Local base
   */
  public removerLocal() {
    this.storageLocal.remove(this.LOCAL_KEY);
    this.localValueSaved = '';
  }
}
