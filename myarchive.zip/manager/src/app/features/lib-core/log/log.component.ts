import { Component } from '@angular/core';
import { BvLogService } from '@arqt/ng15-framework';

/**
 * Componente responsável pelo gerenciamento de Logs
 */
@Component({
  selector: 'app-log',
  templateUrl: './log.component.html',
})
export class LogComponent {
  /** @ignore */
  public exampleHTML = `<button mat-raised-button color="primary" (click)="info()">Info</button>
<button mat-raised-button color="accent" (click)="warn()">Warning</button>
<button mat-raised-button color="warn" (click)="error()">Error</button>`;

  /** @ignore */
  public exampleTS = `import { Component } from '@angular/core';
import { BvLogService } from '@arqt/ng15-framework';

@Component({
  selector: 'app-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.scss']
})
export class LogComponent {
  constructor(
    private bvLogService: BvLogService
  ) { }

  info() {
    this.bvLogService.info('LogComponent', 'Info Log');
  }

  warn() {
    this.bvLogService.warn('LogComponent', 'Warning Log');
  }

  error() {
    this.bvLogService.error('LogComponent', 'Error Log');
  }

}`;
  /** @ignore */
  public exampleSCSS = `/** Nenhum CSS para esse exemplo */`;

  /**
   * Constructor
   * @param bvLogService <BvLogService>
   */
  constructor(private bvLogService: BvLogService) {}

  /**
   * Exibe log de Informação
   */
  info() {
    this.bvLogService.info('LogComponent', 'Info Log');
  }

  /**
   * Exibe log de Cuidado
   */
  warn() {
    this.bvLogService.warn('LogComponent', 'Warning Log');
  }

  /**
   * Exibe log de Error
   */
  error() {
    this.bvLogService.error('LogComponent', 'Error Log');
  }
}
