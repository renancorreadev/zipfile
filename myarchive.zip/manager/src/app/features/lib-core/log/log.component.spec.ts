import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BvLogService } from '@arqt/ng15-framework';

import { LogComponent } from './log.component';

describe('LogComponent', () => {
  let component: LogComponent;
  let fixture: ComponentFixture<LogComponent>;

  const bvLogServiceStub = {
    info: () => ({}),
    warn: () => ({}),
    error: () => ({}),
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LogComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [{ provide: BvLogService, useValue: bvLogServiceStub }],
    });

    fixture = TestBed.createComponent(LogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call info', () => {
    jest.spyOn(bvLogServiceStub, 'info');
    component.info();
    expect(bvLogServiceStub.info).toHaveBeenCalledWith(
      'LogComponent',
      'Info Log'
    );
  });

  it('should call warn', () => {
    jest.spyOn(bvLogServiceStub, 'warn');
    component.warn();
    expect(bvLogServiceStub.warn).toHaveBeenCalledWith(
      'LogComponent',
      'Warning Log'
    );
  });

  it('should call error', () => {
    jest.spyOn(bvLogServiceStub, 'error');
    component.error();
    expect(bvLogServiceStub.error).toHaveBeenCalledWith(
      'LogComponent',
      'Error Log'
    );
  });
});
