import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorHandlingComponent } from './error-handling.component';
import { SharedModule } from '@app/shared//shared.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ErrorHandlingComponent', () => {
  let component: ErrorHandlingComponent;
  let fixture: ComponentFixture<ErrorHandlingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ErrorHandlingComponent],
      imports: [SharedModule, HttpClientTestingModule],
      providers: [],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorHandlingComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call runtimeError function', () => {
    jest.spyOn(component, 'runtimeError');
    try {
      component.runtimeError();
    } catch (e) {
      // go on
    }
    expect(component.runtimeError).toHaveBeenCalled();
  });

  it('should create httpError function', () => {
    jest.spyOn(component, 'httpError');
    try {
      component.httpError();
    } catch (e) {
      // go on
    }
    expect(component.httpError).toHaveBeenCalled();
  });
});
