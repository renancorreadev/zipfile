import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { take } from 'rxjs';

/**
 * Componente responsável pelo gerenciamento de erros
 */
@Component({
  selector: 'app-error-handling',
  templateUrl: './error-handling.component.html',
})
export class ErrorHandlingComponent {
  /** @ignore */
  public exampleHTML = `/** Nenhum HTML para esse exemplo */`;
  /** @ignore */
  public exampleTSRuntimeError = `
  import { Component, OnInit } from '@angular/core';

  @Component({
    selector: 'app-error-handling',
    templateUrl: './error-handling.component.html',
    styleUrls: ['./error-handling.component.scss']
  })
  export class ErrorHandlingComponent {
    constructor() { }

    public runtimeError() {
      throw new Error('Erro Simulado');
    }

  }

  /*-----App Component-----*/

  this.errorService.subscribe(
    (error: ErrorModel) => {
      if (error.type === 'runtime') {
        this.notificationService.error(error.shortDescription);
        console.error(error);
      } else {
        this.notificationService.warn(error.shortDescription);
        console.warn(error);
      }
    }
  );
  );

    `;

  /** @ignore */
  public exampleTSHttpError = `
  import { Component, OnInit } from '@angular/core';

  @Component({
    selector: 'app-error-handling',
    templateUrl: './error-handling.component.html',
    styleUrls: ['./error-handling.component.scss']
  })
  export class ErrorHandlingComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }

    public httpError() {
      this.httpClient.get('nowhere').pipe(take(1)).subscribe();
    }

  }

  /*-----App Component-----*/

  this.errorService.subscribe(
    (error: ErrorModel) => {
      if (error.type === 'runtime') {
        this.notificationService.error(error.shortDescription);
        console.error(error);
      } else {
        this.notificationService.warn(error.shortDescription);
        console.warn(error);
      }
    }
  );

    `;
  /** @ignore */
  public exampleSCSS = `/** Nenhum CSS para esse exemplo */`;

  /**
   * Constructor
   * @param httpClient <HttpClient>
   */
  constructor(private httpClient: HttpClient) {}

  /**
   * Publica Runtime Error
   */
  public runtimeError() {
    throw new Error('Erro de Runtime Simulado');
  }

  /**
   * Publica http Error
   */
  public httpError() {
    this.httpClient.get('nowhere').pipe(take(1)).subscribe();
  }
}
