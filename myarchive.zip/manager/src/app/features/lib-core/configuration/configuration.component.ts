import { Component, OnInit } from '@angular/core';
import { ConfigurationService } from '@arqt/ng15-framework';

/**
 * Componente para gerenciamento de configurações da aplicação
 */
@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
})
export class ConfigurationComponent implements OnInit {
  // public settings: ConfigurationModel;
  /** @ignore */
  public settings: string = '';

  /** @ignore */
  public exampleSCSS = `/** Nenhum SCSS para esse exemplo */`;
  /** @ignore */
  public exampleHTML = `/** Nenhum HTML para esse exemplo */`;
  /** @ignore */
  public exampleTS = `this.settings = JSON.stringify(this.configurationService.settings);`;

  /**
   * Constructor
   * @param configurationService <ConfigurationService>
   */
  constructor(private configurationService: ConfigurationService) {}

  /**
   * Inicialização do Componente
   */
  ngOnInit() {
    this.settings = `import { ConfigurationModel, LogLevel } from '@arqt/ng15-framework';
export const environment: ConfigurationModel = {
  production: false,
  apiBv: 'http://localhost:3200',
  apiBvConfigs: {
    'health': {
      path: '/api-utils/status',
      description: 'Retorna o health-check do backend',
      method: 'GET',
      responseType: 'json',
      observe: 'body',
      withCredentials: true,
      reportProgress: false
    },
    'log': {
      path: '/api-utils/logger',
      method: 'POST'
    },
    'api-docs': {
      path: '/v2/api-docs'
    }
  },
  logLevel: LogLevel.INFO,
  theme: 'corporativo',
  publicKey: '-----BEGIN PUBLIC KEY-----
  MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDlOJu6TyygqxfWT7eLtGDwajtN
  FOb9I5XRb6khyfD1Yt3YiCgQWMNW649887VGJiGr/L5i2osbl8C9+WJTeucF+S76
  xFxdU6jE0NQ+Z+zEdhUTooNRaY5nZiu5PgDB0ED/ZKBUSLKL7eibMxZtMlUDHjm4
  gwQco1KRMDSmXSMkDwIDAQAB
  -----END PUBLIC KEY-----'
}`;
  }
}
