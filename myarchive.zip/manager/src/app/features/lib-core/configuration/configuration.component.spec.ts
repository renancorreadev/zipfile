import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ConfigurationComponent } from './configuration.component';
import { ConfigurationService } from '@arqt/ng15-framework';

describe('ConfigurationComponent', () => {
  let component: ConfigurationComponent;
  let fixture: ComponentFixture<ConfigurationComponent>;

  beforeEach(() => {
    const configurationServiceStub = {};
    TestBed.configureTestingModule({
      declarations: [ConfigurationComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        { provide: ConfigurationService, useValue: configurationServiceStub },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(ConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('settings', () => {
    expect(component.settings).toBeDefined();
  });
});
