import { Component, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

/**
 * Componente responsável pelo gerenciamento da lib-core
 */
@Component({
  selector: 'app-lib-core',
  templateUrl: './lib-core.component.html',
})
export class LibCoreComponent {
  /**
   * Constructor
   * @param _platformId <object>
   * @param http <HttpClient>
   */
  constructor(
    @Inject(PLATFORM_ID) private _platformId: object,
    private http: HttpClient
  ) {}
}
