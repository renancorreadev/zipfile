import { LibCoreModule } from './lib-core.module';

describe('LibCoreModule', () => {
  let libCoreModule: LibCoreModule;

  beforeEach(() => {
    libCoreModule = new LibCoreModule();
  });

  it('should create an instance', () => {
    expect(libCoreModule).toBeTruthy();
  });
});
