import {
  NgModule,
  NO_ERRORS_SCHEMA,
  CUSTOM_ELEMENTS_SCHEMA,
} from '@angular/core';
import { CommonModule } from '@angular/common';

import { LibCoreRoutingModule } from './lib-core-routing.module';
import { SharedModule } from '@app/shared/shared.module';

import { ErrorHandlingComponent } from './error-handling/error-handling.component';
import { ConfigurationComponent } from './configuration/configuration.component';
import { StorageComponent } from './storage/storage.component';
import { LogComponent } from './log/log.component';
import { LibCoreComponent } from './lib-core.component';
import { BvStorageModule } from '@arqt/ng15-framework/storage';
import { TrackByComponent } from '../exemplos/track-by/track-by.component';

@NgModule({
  imports: [CommonModule, LibCoreRoutingModule, SharedModule, BvStorageModule],
  declarations: [
    LibCoreComponent,
    ErrorHandlingComponent,
    ConfigurationComponent,
    StorageComponent,
    LogComponent,
    TrackByComponent,
  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
})
export class LibCoreModule {}
