import { Component } from '@angular/core';

/**
 * Componente responsável por restringir acesso
 */
@Component({
  selector: 'app-forbidden',
  templateUrl: './forbidden.component.html',
  styleUrls: ['./forbidden.component.scss'],
})
export class ForbiddenComponent {}
