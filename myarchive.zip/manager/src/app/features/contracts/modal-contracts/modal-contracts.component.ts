import { ChangeDetectionStrategy, Component } from '@angular/core';
import {
  FileSystemFileEntry,
  NgxFileDropEntry,
} from 'ngx-file-drop';

@Component({
  selector: 'app-contracts',
  templateUrl: './modal-contracts.component.html',
  styleUrls: ['./modal-contracts.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ModalContractsComponent {
  public files: NgxFileDropEntry[] = [];

  public dropped(files: NgxFileDropEntry[]) {
    this.files = files;
    for (const droppedFile of files) {
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {
          this.addFileToLocalStorage(file);
        });
      }
    }
  }

  private addFileToLocalStorage(file: File): void {
    let contractFiles = JSON.parse(localStorage.getItem('contractFiles') || '[]');
    const reader = new FileReader();
    reader.onloadend = () => {
      contractFiles.push(reader.result);
      localStorage.setItem('contractFiles', contractFiles);
    }

    reader.readAsText(file);
  }
}
