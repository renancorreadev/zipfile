import { Component, OnInit, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModalContractsComponent } from './modal-contracts/modal-contracts.component';

/**
 * Componente responsável pelos smart contracts da aplicação
 */
@Component({
  selector: 'app-contracts',
  templateUrl: './contracts.component.html',
  styleUrls: ['./contracts.component.scss'],
})
export class ContractsComponent implements OnInit {
  readonly dialog = inject(MatDialog)
  contracts: any[] = []

  ngOnInit(): void {
    this.openAddSmartContracts();
  }

  openAddSmartContracts(): void {
    const dialogRef = this.dialog.open(ModalContractsComponent, {
      width: '400px',
      height: '300px'
    });

    dialogRef.afterClosed().subscribe(() => {
      this.getLocalStorageContracts();
    })

  }

  getLocalStorageContracts(): void {
    this.contracts = JSON.parse(localStorage.getItem('contractFiles') || '[]');
  }
}
