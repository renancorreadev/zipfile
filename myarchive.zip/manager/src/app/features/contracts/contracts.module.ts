import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ContractsComponent } from './contracts.component';
import { CommonModule } from '@angular/common';
import { ContractsRoutingModule } from './contracts-rounting.module';
import { SharedModule } from '@app/shared/shared.module';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { ModalContractsComponent } from './modal-contracts/modal-contracts.component';
import { MatIconModule } from '@angular/material/icon';
import { NgxFileDropModule } from 'ngx-file-drop';

@NgModule({
  imports: [
    CommonModule,
    ContractsRoutingModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    NgxFileDropModule,
    SharedModule,
  ],
  declarations: [
    ContractsComponent,
    ModalContractsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ContractsModule {}
