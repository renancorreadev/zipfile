import { Component, OnInit } from '@angular/core';
import { BaseComponent, BvRolesService } from '@arqt/ng15-framework';
import { Observable, takeUntil } from 'rxjs';

/**
 * Componente responsável por gerenciar as diretivas de usuário
 */
@Component({
  selector: 'app-diretivas',
  templateUrl: './diretivas.component.html',
})
export class DiretivasComponent extends BaseComponent implements OnInit {
  /** @ignore */
  public gridExemplo1: Observable<boolean> | undefined;
  /** @ignore */
  public gridExemplo2: Observable<boolean> | undefined;

  /** @ignore */
  public btnExemplo1: boolean | undefined;
  /** @ignore */
  public btnExemplo2: boolean | undefined;

  /** @ignore */
  public exampleHTML1 = `<p>Abaixo encontram-se dois textos, um que será exibido se uma das roles do usuário logado for <strong>ADMIN</strong> e o outro se uma delas for <strong>FUNC</strong>:</p>
<p *ngIf="gridExemplo1 | async">O usuário logado tem role de ADMIN</p>
<p *ngIf="gridExemplo2 | async">O usuário logado tem role de FUNCIONARIO</p>`;

  /** @ignore */
  public exampleHTML2 = `<p>Caso a role do usuário seja <strong>ADMIN</strong>, será possível interagir com o botão abaixo:</p>
<button [disabled]="btnExemplo1" mat-raised-button color="primary">Ver Rendimentos</button>
<p>Caso a role do usuário seja <strong>FUNC</strong>, será possível interagir com o botão abaixo:</p>
<button [disabled]="btnExemplo2" mat-raised-button color="primary">Ver Guia</button>`;

  /** @ignore */
  public exampleTS1 = `import { Component, OnInit } from '@angular/core';
import { BvRolesService } from '@arqt/ng15-framework';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-diretivas',
  templateUrl: './diretivas.component.html',
  styleUrls: ['./diretivas.component.scss']
})
export class DiretivasComponent implements OnInit {
  public gridExemplo1: Observable<boolean>;
  public gridExemplo2: Observable<boolean>;

  constructor(
    private bvRolesService: BvRolesService
  ) { }

  ngOnInit() {
    this.gridExemplo1 = this.bvRolesService.userInRoles(['ADMIN']);
    this.gridExemplo2 = this.bvRolesService.userInRoles(['FUNC']);
  }
}`;

  /** @ignore */
  public exampleTS2 = `import { Component, OnInit } from '@angular/core';
import { BaseComponent, BvRolesService } from '@arqt/ng15-framework';
import { Observable, takeUntil } from 'rxjs';

@Component({
  selector: 'app-diretivas',
  templateUrl: './diretivas.component.html',
  styleUrls: ['./diretivas.component.scss']
})
export class DiretivasComponent extends BaseComponent implements OnInit {
  public btnExemplo1: boolean;
  public btnExemplo2: boolean;

  constructor(private bvRolesService: BvRolesService) {
    super();
  }

  ngOnInit() {
    this.bvRolesService
      .userInRoles(['ADMIN'])
      .pipe(takeUntil(this.onDestroy))
      .subscribe((hasPermission) => (this.btnExemplo1 = !hasPermission));

    this.bvRolesService
      .userInRoles(['FUNC'])
      .pipe(takeUntil(this.onDestroy))
      .subscribe((hasPermission) => (this.btnExemplo2 = !hasPermission));
  }
}`;

  /** @ignore */
  public exampleSCSS = `/** Nenhum CSS para esse exemplo */`;

  /**
   * Constructor
   * @param bvRolesService <BvRolesService>
   */
  constructor(private bvRolesService: BvRolesService) {
    super();
  }

  /**
   * Inicialização do Componente
   */
  ngOnInit() {
    this.gridExemplo1 = this.bvRolesService.userInRoles(['ADMIN']);
    this.gridExemplo2 = this.bvRolesService.userInRoles(['FUNC']);

    this.bvRolesService
      .userInRoles(['ADMIN'])
      .pipe(takeUntil(this.onDestroy))
      .subscribe((hasPermission) => (this.btnExemplo1 = !hasPermission));

    this.bvRolesService
      .userInRoles(['FUNC'])
      .pipe(takeUntil(this.onDestroy))
      .subscribe((hasPermission) => (this.btnExemplo2 = !hasPermission));
  }
}
