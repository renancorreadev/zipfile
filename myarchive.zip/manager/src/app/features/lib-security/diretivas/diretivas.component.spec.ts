import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BvRolesService } from '@arqt/ng15-framework';

import { DiretivasComponent } from './diretivas.component';

/* Import prism core */
import 'prismjs/prism';

/* Import the language you need to highlight */
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-sass';
import { PrismComponent } from '@app/shared/prism/prism.component';
import { SharedModule } from '@app/shared//shared.module';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Subject } from 'rxjs';

describe('DiretivasComponent', () => {
  let component: DiretivasComponent;
  let fixture: ComponentFixture<DiretivasComponent>;
  const userInRolesMock = new Subject<boolean>();

  beforeEach(async () => {
    const bvRolesServiceStub = {
      userInRoles: () => userInRolesMock.asObservable(),
    };

    await TestBed.configureTestingModule({
      declarations: [DiretivasComponent, PrismComponent],
      imports: [SharedModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: BvRolesService, useValue: bvRolesServiceStub }],
    }).compileComponents();

    fixture = TestBed.createComponent(DiretivasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change visibility', () => {
    expect(component.btnExemplo1).toBe(undefined);
    expect(component.btnExemplo2).toBe(undefined);

    userInRolesMock.next(true);
    expect(component.btnExemplo1).toBe(false);
    expect(component.btnExemplo2).toBe(false);

    userInRolesMock.next(false);
    expect(component.btnExemplo1).toBe(true);
    expect(component.btnExemplo2).toBe(true);
  });
});
