import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DiretivasComponent } from './diretivas/diretivas.component';
import { CryptographyComponent } from './cryptography/cryptography.component';

const routes: Routes = [
  {
    path: 'diretivas',
    component: DiretivasComponent,
    data: {
      breadcrumb: 'Diretivas',
    },
  },
  {
    path: 'criptografia',
    component: CryptographyComponent,
    data: {
      breadcrumb: 'Criptografia',
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LibSecurityRoutingModule {}
