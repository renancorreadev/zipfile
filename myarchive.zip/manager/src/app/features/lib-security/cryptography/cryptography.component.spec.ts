/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';

import { CryptographyComponent } from './cryptography.component';
import { SharedModule } from '@app/shared/shared.module';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BvCryptographyService } from '@arqt/ng15-framework';
import { of } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  PLATFORM_ID,
  CUSTOM_ELEMENTS_SCHEMA,
  NO_ERRORS_SCHEMA,
} from '@angular/core';

describe('CryptographyComponent', () => {
  let component: CryptographyComponent;
  let fixture: ComponentFixture<CryptographyComponent>;
  let element: HTMLElement;
  let cryptographyServiceStub: { initializeKey: any; encrypt: any };

  beforeEach(() => {
    cryptographyServiceStub = { encrypt: jest.fn(), initializeKey: jest.fn() };
    cryptographyServiceStub.initializeKey.mockReturnValue(of(true));

    TestBed.configureTestingModule({
      imports: [
        SharedModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        BrowserAnimationsModule,
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [CryptographyComponent],
      providers: [
        FormBuilder,
        { provide: BvCryptographyService, useValue: cryptographyServiceStub },
      ],
    });

    fixture = TestBed.createComponent(CryptographyComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
  });

  describe('initialize', () => {
    it('should create', () => {
      cryptographyServiceStub.encrypt.mockReturnValue(of('encrypted'));
      expect(component).toBeTruthy();
    });

    it('should Init', () => {
      cryptographyServiceStub.encrypt.mockReturnValue(of('encrypted'));
      component.ngOnInit();
      fixture.detectChanges();
      const textArea = element.querySelector('textarea');
      expect(textArea).toBeTruthy();
      if (textArea) expect(textArea.value).toEqual('Dado criptografado: ');
    });
  });

  describe('valueChanges', () => {
    it('should encrypt Value', fakeAsync(() => {
      const textValue = 'beforeEncrypted';
      cryptographyServiceStub.encrypt.mockReturnValue(of('afterEncrypted'));
      component.ngOnInit();
      fixture.detectChanges();
      tick();
      const input: HTMLInputElement | null =
        element.querySelector('input[name=dado]');
      if (input) {
        input.value = 'beforeEncrypted';
        input.dispatchEvent(new Event('input'));
      }
      fixture.detectChanges();
      tick(200);
      expect(cryptographyServiceStub.encrypt).toHaveBeenCalledWith(textValue);
      fixture.detectChanges();
      tick();
      const textArea = element.querySelector('textarea');
      expect(textArea).toBeTruthy();
      if (textArea)
        expect(textArea.value).toEqual('Dado criptografado: afterEncrypted');
    }));
  });
});

describe('CryptographyComponent with PLATFORM_SERVER_ID null', () => {
  let component: CryptographyComponent;
  let fixture: ComponentFixture<CryptographyComponent>;
  let element: HTMLElement;
  let cryptographyServiceStub: { initializeKey: any; encrypt: any };
  const PLATFORM_SERVER_ID = null;

  beforeEach(() => {
    cryptographyServiceStub = { encrypt: jest.fn(), initializeKey: jest.fn() };
    cryptographyServiceStub.initializeKey.mockReturnValue(of(true));

    TestBed.configureTestingModule({
      imports: [
        SharedModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        BrowserAnimationsModule,
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [CryptographyComponent],
      providers: [
        FormBuilder,
        { provide: BvCryptographyService, useValue: cryptographyServiceStub },
        { provide: PLATFORM_ID, useValue: PLATFORM_SERVER_ID },
      ],
    });

    fixture = TestBed.createComponent(CryptographyComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
  });

  describe('initialize', () => {
    it('should create', () => {
      cryptographyServiceStub.encrypt.mockReturnValue(of('encrypted'));
      expect(component).toBeTruthy();
    });

    it('should Init', () => {
      cryptographyServiceStub.encrypt.mockReturnValue(of('encrypted'));
      component.ngOnInit();
      fixture.detectChanges();
      const textArea = element.querySelector('textarea');
      expect(textArea).toBeTruthy();
      if (textArea) expect(textArea.value).toEqual('Dado criptografado: ');
    });
  });
});
