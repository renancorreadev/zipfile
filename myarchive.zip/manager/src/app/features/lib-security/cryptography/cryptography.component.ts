import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { BvCryptographyService, BaseComponent } from '@arqt/ng15-framework';
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  UntypedFormControl,
} from '@angular/forms';
import {
  debounceTime,
  filter,
  switchMap,
  take,
  takeUntil,
} from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';

/**
 * Componente responsável por gerenciar a criptografia da aplicação
 */
@Component({
  selector: 'app-cryptography',
  templateUrl: './cryptography.component.html',
  styleUrls: ['./cryptography.component.scss'],
})
export class CryptographyComponent extends BaseComponent implements OnInit {
  /** @ignore */
  public frmCrypt: UntypedFormGroup = this.formBuilder.group({});
  /** @ignore */
  private frmContrlDados: UntypedFormControl | undefined;
  /** @ignore */
  public encryptedValue: string | undefined;

  /** @ignore */
  public exampleHTML = `
  <div class="d-flex justify-content-around">
  <form [formGroup]="frmCrypt" class="full-width ">
    <div class="row align-items-center ">

      <mat-form-field class="full-width ">
        <input matInput placeholder="Insira um dado para ser criptografado" id="dado" name="dado" maxlength="100" formControlName="dado">
      </mat-form-field>

    </div>
    <div class="row align-items-center">
      <textarea rows="5" cols="60" class="full-width " >Dado criptografado: {{encryptedValue}}</textarea>
    </div>
  </form>
</div>`;

  /** @ignore */
  public exampleTS = `
  import { Component, OnInit } from '@angular/core';
  import { BaseComponent, BvCryptographyService } from '@arqt/ng15-framework';
  import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl } from '@angular/forms';
  import { debounceTime, take, takeUntil, } from 'rxjs/operators';

  @Component({
    selector: 'app-cryptography',
    templateUrl: './cryptography.component.html',
    styleUrls: ['./cryptography.component.scss']
  })
  export class CryptographyComponent extends BaseComponent implements OnInit {

    public frmCrypt: UntypedFormGroup;
    private frmContrlDados: UntypedFormControl;
    public encryptedValue;

    constructor(
      private formBuilder: UntypedFormBuilder,
      private cryptography: BvCryptographyService) { }

    ngOnInit() {
      this.frmContrlDados = new UntypedFormControl();
      this.frmCrypt = this.formBuilder.group({
        dado: this.frmContrlDados,
      });

      this.cryptography
        .initializeKey()
        .pipe(take(1))
        .subscribe((res) => {
          console.log(res);
        });

      this.frmContrlDados.valueChanges
        .pipe(
          takeUntil(this.onDestroy),
          debounceTime(200),
          filter((value) => value !== undefined),
          switchMap((value) => {
            return this.cryptography.encrypt(value).pipe(take(1));
          })
        )
        .subscribe((cryptValue) => {
          this.encryptedValue = cryptValue;
        });
    }

  }`;

  /** @ignore */
  public exampleSCSS = `/** Nenhum CSS para esse exemplo */`;

  /**
   * Constructor
   * @param formBuilder <UntypedFormBuilder>
   * @param cryptography <BvCryptographyService>
   * @param platformId <object>
   */
  constructor(
    private formBuilder: UntypedFormBuilder,
    private cryptography: BvCryptographyService,
    @Inject(PLATFORM_ID) private platformId: object
  ) {
    super();
  }

  /**
   * Inicialização do Componente
   */
  ngOnInit() {
    this.frmContrlDados = new UntypedFormControl();
    this.frmCrypt = this.formBuilder.group({
      dado: this.frmContrlDados,
    });

    if (isPlatformBrowser(this.platformId)) {
      this.cryptography
        .initializeKey()
        .pipe(take(1))
        .subscribe((res) => {
          console.log(res);
        });

      this.frmContrlDados.valueChanges
        .pipe(
          takeUntil(this.onDestroy),
          debounceTime(200),
          filter((value) => value !== undefined),
          switchMap((value) => {
            return this.cryptography.encrypt(value).pipe(take(1));
          })
        )
        .subscribe((cryptValue) => {
          this.encryptedValue = cryptValue;
        });
    }
  }
}
