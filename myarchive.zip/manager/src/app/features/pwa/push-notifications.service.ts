import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

/**
 * Serviço responsável por gerenciar as notificações junto ao Service Worker
 */
@Injectable({
  providedIn: 'root',
})
export class PushNotificationsService {
  /**
   * Constructor
   *
   * @param http <HttpClient>
   */
  constructor(private http: HttpClient) {}

  /**
   * Adiciona usuário a lista de usuários que recebem notificações
   * @param sub <unknown>
   * @returns resultado da requisição a assinatura de notificações
   */
  addPushSubscriber(sub: unknown) {
    return this.http.post('/api/notifications', sub);
  }

  /**
   * Envia notificação para usuário
   *
   * @returns conteúdo da notificação retornado pelo servidor
   */
  send() {
    return this.http.post('/api/pushnotifications', null);
  }
}
