import { Component } from '@angular/core';
import { SwPush } from '@angular/service-worker';
import { PushNotificationsService } from '../push-notifications.service';

/**
 * Componente responsável por controlar as interações da tela de Push Notifications
 */
@Component({
  selector: 'app-push-notifications',
  templateUrl: './push-notifications.component.html',
})
export class PushNotificationsComponent {
  /**
   * Chave habilita o usuario a receber notificações a partir de um backend
   */
  readonly VAPID_PUBLIC_KEY =
    'BH2oP-QhYNA0y1N4J1RNFbe_yDGfVQ81HPuXf7oTG2I8n_3PCBB2L_U35PQ6-hEpT7JP3cEDRLLRRh2BpBpdaa8';
  /** @ignore */
  public exampleHTML = `<div class="actions">
  <button mat-raised-button color="primary" (click)="subscribeToNotifications()" class="first-child">Assinar</button>
</div> `;

  /** @ignore */
  public exampleTS = `import { Component } from '@angular/core';
import { SwPush } from '@angular/service-worker';
import { PushNotificationsService } from '../push-notifications.service';

/**
 * Componente responsável por controlar as interacoes da tela de Push Notifications
 */
@Component({
  selector: 'app-push-notifications',
  templateUrl: './push-notifications.component.html',
  styleUrls: ['./push-notifications.component.scss']
})
export class PushNotificationsComponent {

  /**
   * Chave habilita o usuario a receber notificacoes a partir de um backend
   */
  readonly VAPID_PUBLIC_KEY = 'BH2oP-QhYNA0y1N4J1RNFbe_yDGfVQ81HPuXf7oTG2I8n_3PCBB2L_U35PQ6-hEpT7JP3cEDRLLRRh2BpBpdaa8';

  /**
   * Constructor
   *
   * @param SwPush
   * @param PushNotificationsService
   */
  constructor(
    private swPush: SwPush,
    private pushNotificationsService: PushNotificationsService) {}

  /**
   * Realiza chamada para adiciona usuario a lista de usuarios que recebem notificacoes
   */
  subscribeToNotifications() {
    this.swPush.requestSubscription({
      serverPublicKey: this.VAPID_PUBLIC_KEY
    })
    .then(sub => this.pushNotificationsService.addPushSubscriber(sub).subscribe())
    .catch(err => console.error("Could not subscribe to notifications", err));
  }
}`;

  /** @ignore */
  public exampleSCSS = `/** Nenhum SCSS para esse exemplo */`;

  /**
   * Constructor
   *
   * @param swPush <SwPush>
   * @param pushNotificationsService <PushNotificationsService>
   */
  constructor(
    private swPush: SwPush,
    private pushNotificationsService: PushNotificationsService
  ) {}

  /**
   * Realiza chamada para adicionar usuário a lista de usuários que recebem notificações
   */
  subscribeToNotifications() {
    this.swPush
      .requestSubscription({
        serverPublicKey: this.VAPID_PUBLIC_KEY,
      })
      .then((sub) =>
        this.pushNotificationsService.addPushSubscriber(sub).subscribe()
      )
      .catch((err) =>
        console.error('Could not subscribe to notifications', err)
      );
  }
}
