import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PushNotificationsComponent } from './push-notifications.component';
import { SharedModule } from '@app/shared/shared.module';
import { SwPush } from '@angular/service-worker';
import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { Subject, firstValueFrom } from 'rxjs';

describe('PushNotificationsComponent', () => {
  let component: PushNotificationsComponent;
  let fixture: ComponentFixture<PushNotificationsComponent>;
  const swPushStub = { requestSubscription: jest.fn() };
  const pushSbject = new Subject<unknown>();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule, SharedModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [PushNotificationsComponent],
      providers: [{ provide: SwPush, useValue: swPushStub }],
    }).compileComponents();

    fixture = TestBed.createComponent(PushNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add push subscriber', () => {
    jest
      .spyOn(swPushStub, 'requestSubscription')
      .mockReturnValue(firstValueFrom(pushSbject.asObservable()));
    jest.spyOn(console, 'error').mockImplementation();
    component.subscribeToNotifications();
    pushSbject.next({});
    pushSbject.complete();
  });

  it('should get error on adding push subscriber', () => {
    jest
      .spyOn(swPushStub, 'requestSubscription')
      .mockReturnValue(firstValueFrom(pushSbject.asObservable()));
    jest.spyOn(console, 'error').mockImplementation();
    component.subscribeToNotifications();
    pushSbject.error(new Error('Dummy Error'));
    pushSbject.complete();
  });
});
