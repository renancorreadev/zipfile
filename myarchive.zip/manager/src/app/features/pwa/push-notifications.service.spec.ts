import { TestBed } from '@angular/core/testing';

import { PushNotificationsService } from './push-notifications.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';

describe('PushNotificationsService', () => {
  let service: PushNotificationsService;
  let http: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });

    http = TestBed.inject(HttpClient);
    service = new PushNotificationsService(http);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call addPushSubscriber', () => {
    jest.spyOn(http, 'post').mockReturnValue(of({}));
    service.addPushSubscriber('teste');
    expect(http.post).toHaveBeenCalledWith('/api/notifications', 'teste');
  });

  it('should call send', () => {
    jest.spyOn(http, 'post').mockReturnValue(of({}));
    service.send();
    expect(http.post).toHaveBeenCalledWith('/api/pushnotifications', null);
  });
});
