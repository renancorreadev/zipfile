import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CameraComponent } from './camera/camera.component';
import { SharedModule } from './../../shared/shared.module';
import { PwaRoutingModule } from './pwa-routing.module';
import { PushNotificationsComponent } from './push-notifications/push-notifications.component';

@NgModule({
  imports: [CommonModule, SharedModule, PwaRoutingModule],
  declarations: [CameraComponent, PushNotificationsComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class PwaModule {}
