import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CameraComponent } from './camera/camera.component';
import { PushNotificationsComponent } from './push-notifications/push-notifications.component';

const routes: Routes = [
  {
    path: 'camera',
    component: CameraComponent,
    data: {
      breadcrumb: 'Câmera',
    },
  },
  {
    path: 'push-notifications',
    component: PushNotificationsComponent,
    data: {
      breadcrumb: 'Push Notifications',
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PwaRoutingModule {}
