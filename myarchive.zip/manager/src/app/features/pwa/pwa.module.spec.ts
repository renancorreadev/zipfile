import { PwaModule } from './pwa.module';

describe('PwaModule', () => {
  let pwaModule: PwaModule;

  beforeEach(() => {
    pwaModule = new PwaModule();
  });

  it('should create an instance', () => {
    expect(pwaModule).toBeTruthy();
  });
});
