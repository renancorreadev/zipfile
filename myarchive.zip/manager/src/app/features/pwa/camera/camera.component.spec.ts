/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-empty-function */
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CameraComponent } from './camera.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('CameraComponent', () => {
  let component: CameraComponent;
  let fixture: ComponentFixture<CameraComponent>;
  const { mediaDevices } = global.navigator;

  beforeAll(() => {
    Object.defineProperty(global.navigator, 'mediaDevices', {
      value: {
        getUserMedia: jest.fn(
          async () => new Promise<void>((resolve) => resolve())
        ),
      },
    });

    HTMLCanvasElement.prototype.getContext = () => null;
    HTMLCanvasElement.prototype.toDataURL = (
      type?: string,
      quality?: unknown
    ) => '';
  });

  afterAll(() => {
    const pauseStub = jest
      .spyOn(window.HTMLMediaElement.prototype, 'pause')
      .mockImplementation(() => {});
    const playStub = jest
      .spyOn(window.HTMLMediaElement.prototype, 'play')
      .mockImplementation(() => new Promise(() => {}));
    [pauseStub, playStub].map((stub) => stub.mockRestore());

    Object.defineProperty(global.navigator, 'mediaDevices', {
      value: mediaDevices,
    });
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CameraComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(CameraComponent);
    component = fixture.componentInstance;
    component.ngAfterViewInit();

    fixture.detectChanges();
  });

  afterEach(() => {
    jest.spyOn(component, 'initCamera').mockRestore();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('video integraction', () => {
    it('start', () => {
      jest
        .spyOn(window.HTMLMediaElement.prototype, 'play')
        .mockImplementation(() => new Promise(() => {}));

      jest.spyOn(component, 'initCamera');
      component.start();
      expect(component.initCamera).toHaveBeenCalled();
    });

    it('snapshot', () => {
      component.snapshot();
    });

    it('downloadSnapshot', () => {
      component.downloadSnapshot();
    });

    it('resume', () => {
      const playStub = jest
        .spyOn(window.HTMLMediaElement.prototype, 'play')
        .mockImplementation(() => new Promise(() => {}));
      component.resume();
      expect(playStub).toHaveBeenCalled();
    });

    it('pause', () => {
      const pauseStub = jest
        .spyOn(window.HTMLMediaElement.prototype, 'pause')
        .mockImplementation(() => {});
      component.pause();
      expect(pauseStub).toHaveBeenCalled();
    });

    it('only for coverage', () => {
      Object.defineProperty(global.navigator, 'mediaDevices', { value: null });
      component.start();
    });
  });
});
