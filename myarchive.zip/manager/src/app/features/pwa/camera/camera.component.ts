/* eslint-disable @typescript-eslint/consistent-type-assertions */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, ViewChild, AfterViewInit } from '@angular/core';

/**
 * Componente responsável por controlar as interações da tela de câmera
 */
@Component({
  selector: 'app-camera',
  templateUrl: './camera.component.html',
  styleUrls: ['./camera.component.scss'],
})
export class CameraComponent implements AfterViewInit {
  /** @ignore */
  public video: any;

  /** @ignore */
  public canvas: any;

  /** @ignore */
  public isPlaying = false;

  /** @ignore */
  public displayControls = true;

  /** @ignore */
  @ViewChild('videoElement', { static: true }) videoElement: any;

  /** @ignore */
  @ViewChild('canvasElement', { static: true }) canvasElement: any;

  /**
   * Setup de variáveis iniciais do componente após inicialização da view
   */
  ngAfterViewInit() {
    this.video = this.videoElement.nativeElement;
    this.canvas = this.canvasElement.nativeElement;
  }

  /**
   * Define as configurações iniciais da câmera
   */
  start() {
    this.initCamera({ video: true, audio: false });
  }

  /**
   * Pausa o stream da câmera
   */
  pause() {
    this.video.pause();
  }

  /**
   * Continua o stream da câmera
   */
  resume() {
    this.video.play();
  }

  /**
   * Captura imagem a partir do stream da câmera
   */
  snapshot() {
    this.canvas.width = this.video.videoWidth;
    this.canvas.height = this.video.videoHeight;
    const element = this.canvas.getContext('2d');
    if (element) {
      element.drawImage(
        this.video,
        0,
        0,
        this.canvas.width,
        this.canvas.height
      );
    }
  }

  /**
   * Realiza download da imagem capturada
   */
  downloadSnapshot() {
    const snapshot = (this.canvas.toDataURL('image/jpeg', 1.0) || '').replace(
      /^data:image\/[^;]/,
      'data:application/octet-stream'
    );
    const link = document.createElement('a');
    link.setAttribute('download', 'img.png');
    link.setAttribute('href', snapshot);
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  /**
   * Inicializa a câmera do dispositivo
   * @param config <object>
   */
  initCamera(config: object) {
    const browser = <any>navigator;

    browser.getUserMedia =
      browser.getUserMedia ||
      browser.webkitGetUserMedia ||
      browser.mozGetUserMedia ||
      browser.msGetUserMedia;

    if (browser.mediaDevices) {
      browser.mediaDevices
        .getUserMedia(config)
        .then((stream: Blob | MediaSource) => {
          try {
            this.video.srcObject = stream;
          } catch (error) {
            this.video.src = window.URL.createObjectURL(stream);
          }
          this.video.play();
        });
    }
  }
}
