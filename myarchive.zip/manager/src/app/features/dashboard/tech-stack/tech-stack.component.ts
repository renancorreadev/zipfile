import { Component } from '@angular/core';
import { packages } from '../../../app.versions';
/**
 * Componente responsável pelo gerenciamento do suporte de tecnologias
 */
@Component({
  selector: 'app-tech-stack',
  templateUrl: './tech-stack.component.html',
})
export class TechStackComponent {
  /** @ignore */
  public displayedColumns: string[] = ['tech', 'version'];
  /** @ignore */
  public dataSource = packages;
}
