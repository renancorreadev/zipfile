/* eslint-disable @typescript-eslint/no-empty-function */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardComponent } from './dashboard.component';
import { TechStackComponent } from './tech-stack/tech-stack.component';
import { BrowserSupportComponent } from './browser-support/browser-support.component';
import { MatLegacyTableModule as MatTableModule } from '@angular/material/legacy-table';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { of } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('ArquiteturaComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let breakpointObserverStub;

  beforeEach(async(() => {
    breakpointObserverStub = { observe: jest.fn() };
    breakpointObserverStub.observe.mockReturnValue(of(Breakpoints.Handset));

    TestBed.configureTestingModule({
      imports: [MatTableModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [
        DashboardComponent,
        TechStackComponent,
        BrowserSupportComponent,
      ],
      providers: [
        { provide: BreakpointObserver, useValue: breakpointObserverStub },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should adapt to break point Handset', () => {
    fixture.detectChanges();
    component.cards.subscribe((value) => {
      expect(value).toEqual([
        { title: 'Arquitetura SPA', cols: 2, rows: 1, content: '' },
        { title: 'Pré-Requisitos', cols: 1, rows: 1, content: '<h1>A</h1>' },
        {
          title: 'Navegadores Suportados',
          cols: 1,
          rows: 1,
          content: '<app-browser-support></app-browser-support>',
        },
      ]);
    });
    expect(component).toBeTruthy();
  });
});
