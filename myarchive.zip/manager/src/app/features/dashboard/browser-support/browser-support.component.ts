import { Component } from '@angular/core';

/**
 * Model responsável por armazenar browsers e versões suportadas
 */
export interface BrowserItemModel {
  /** @ignore */
  browser: string;
  /** @ignore */
  version: string;
}

/**
 * Variável com os dados de browsers
 */
const BROWSER_DATA: BrowserItemModel[] = [
  { browser: 'Chrome', version: '2 últimas versões' },
  {
    browser: 'Firefox',
    version: 'Versões ESR (extended support release) e latest',
  },
  { browser: 'Edge', version: '2 últimas versões major' },
  { browser: 'Safari', version: '2 últimas versões major' },
  { browser: 'iOS', version: '2 últimas versões major' },
  { browser: 'Android', version: '2 últimas versões major' },
];

/**
 * Componente responsável pelo gerenciamento de suporte de browsers
 */
@Component({
  selector: 'app-browser-support',
  templateUrl: './browser-support.component.html',
})
export class BrowserSupportComponent {
  /** @ignore */
  public displayedColumns: string[] = ['browser', 'version'];
  /** @ignore */
  public dataSource = BROWSER_DATA;
}
