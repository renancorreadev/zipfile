import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserSupportComponent } from './browser-support.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';

describe('BrowserSupportComponent', () => {
  let component: BrowserSupportComponent;
  let fixture: ComponentFixture<BrowserSupportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BrowserSupportComponent],
      imports: [MatTableModule, MatCardModule],
      schemas: [NO_ERRORS_SCHEMA],
    });

    fixture = TestBed.createComponent(BrowserSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
