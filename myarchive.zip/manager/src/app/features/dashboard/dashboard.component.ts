import { Component } from '@angular/core';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { map } from 'rxjs/operators';

/**
 * Componente responsável pelas definições do Dashboard da aplicação
 */
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent {
  /**
   * Com base no tamanho da tela, alterne de padrão para uma coluna por linha
   */
  public cards = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(() => [
      { title: 'Arquitetura SPA', cols: 2, rows: 1, content: '' },
      { title: 'Pré-Requisitos', cols: 1, rows: 1, content: '<h1>A</h1>' },
      {
        title: 'Navegadores Suportados',
        cols: 1,
        rows: 1,
        content: '<app-browser-support></app-browser-support>',
      },
    ])
  );

  /**
   * Constructor
   * @param breakpointObserver <BreakpointObserver>
   */
  constructor(private breakpointObserver: BreakpointObserver) {}
}
