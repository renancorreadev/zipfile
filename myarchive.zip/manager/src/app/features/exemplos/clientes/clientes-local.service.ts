import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';

import { ClienteModel, EstadoCivilModel } from './models';

/**
 * Serviço com funções de base com clientes
 */
@Injectable()
export class ClientesLocalService {
  /** @ignore */
  private listaClientes: ClienteModel[] = [
    {
      id: 1,
      nome: 'Olegário Maciel',
      email: 'olegario.maciel@bancovotorantim.com.br',
      dataNascimento: new Date(1987, 10, 10).toISOString(),
      estadoCivil: 'Solteiro',
      sexo: 'M',
      cpf: '87523383807',
    },
    {
      id: 2,
      nome: 'Jessica Jones',
      email: 'jessica.jones@bancovotorantim.com.br',
      dataNascimento: new Date(1983, 5, 24).toISOString(),
      estadoCivil: 'Casado',
      sexo: 'F',
      cpf: '64411770806',
    },
  ];

  /**
   * Salva o novo cliente na lista de clientes
   *
   * @param model <ClienteModel>
   * @returns Adiciona ou substitui cliente na lista
   */
  salvar(model: ClienteModel): Observable<object> {
    if (model.id) {
      this.listaClientes = this.listaClientes.filter((item) => {
        return item.id !== model.id;
      });
      this.listaClientes.push(model);
    } else {
      const array = new Uint32Array(1);
      model.id = Math.ceil(Math.ceil(crypto.getRandomValues(array)[0] / 10000));
      this.listaClientes.push(model);
    }
    return of({});
  }

  /**
   * Seleciona um cliente de acordo com o id
   *
   * @param id <number>
   * @returns retorna o cliente com o id correspondente
   */
  get(id: number): Observable<ClienteModel> {
    const cliente = this.listaClientes.find((item) => {
      return item.id === id;
    });

    if (!cliente) {
      return throwError(() => new Error('Cliente não encontrado'));
    }

    return of(cliente);
  }

  /**
   * Lista todos os clientes salvos
   *
   * @returns retorna uma lista de clientes
   */
  listar(): Observable<ClienteModel[]> {
    return of(this.listaClientes);
  }

  /**
   * Exclui um cliente da lista pelo seu id
   *
   * @param id <number>
   * @returns Exclui o elemento ou retorna erro caso id não exista
   */
  excluir(id: number): Observable<object> {
    this.listaClientes = this.listaClientes.filter((item) => {
      return item.id !== id;
    });
    return of({});
  }

  /**
   * Devolve uma lista com estados civis
   *
   * @returns retorna uma lista de estados civis
   */
  getListaEstadoCivil(): Observable<EstadoCivilModel[]> {
    return of([
      {
        id: 1,
        nome: 'Solteiro',
      },
      {
        id: 2,
        nome: 'Casado',
      },
      {
        id: 3,
        nome: 'Divorciado',
      },
    ]);
  }
}
