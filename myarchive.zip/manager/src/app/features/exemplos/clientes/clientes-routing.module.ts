import { NgModule, Provider } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ClientesService } from '@atle/ng15-biblioteca';
import { ClientesLocalService } from './clientes-local.service';
import {
  ErrorStateMatcher,
  ShowOnDirtyErrorStateMatcher,
} from '@angular/material/core';

export function provideClientLocalService(): Provider[] {
  return [
    {
      provide: ClientesService,
      useClass: ClientesLocalService,
    },
    {
      provide: ErrorStateMatcher,
      useClass: ShowOnDirtyErrorStateMatcher,
    },
  ];
}

const routes: Routes = [
  {
    path: '',
    providers: [provideClientLocalService()],
    data: {
      breadcrumb: 'Clientes',
    },
    loadComponent: () =>
      import('@atle/ng15-biblioteca').then((lib) => lib.ClientesMfeComponent),
    children: [
      {
        path: '',
        redirectTo: 'lista',
        pathMatch: 'full',
      },
      {
        path: 'lista',
        loadComponent: () =>
          import('@atle/ng15-biblioteca').then((lib) => lib.ListaComponent),
        data: {
          breadcrumb: 'Lista',
        },
      },
      {
        path: 'cadastro',
        loadComponent: () =>
          import('@atle/ng15-biblioteca').then((lib) => lib.CadastroComponent),
        data: {
          breadcrumb: 'Cadastro',
          metatags: {
            title: 'Cadastro',
          },
        },
      },
      {
        path: 'cadastro/:id',
        loadComponent: () =>
          import('@atle/ng15-biblioteca').then((lib) => lib.CadastroComponent),
        data: {
          breadcrumb: 'Edição',
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ClientesRoutingModule {}
