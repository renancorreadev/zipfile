/**
 * Model para definição de dados de Cliente
 */
export interface ClienteModel {
  /** @ignore */
  id?: number;
  /** @ignore */
  nome: string;
  /** @ignore */
  email: string;
  /** @ignore */
  estadoCivil: string;
  /** @ignore */
  sexo: string;
  /** @ignore */
  dataNascimento: string;
  /** @ignore */
  cpf: string;
}
