export { ClienteModel } from './cliente.model';
export { EstadoCivilModel } from './estado-civil.model';
