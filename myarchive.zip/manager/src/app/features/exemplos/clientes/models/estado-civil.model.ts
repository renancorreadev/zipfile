/**
 * Model para definição de dados de Estado civil
 */
export interface EstadoCivilModel {
  /** @ignore */
  id: number;
  /** @ignore */
  nome: string;
}
