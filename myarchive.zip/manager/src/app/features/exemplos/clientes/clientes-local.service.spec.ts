import { firstValueFrom } from 'rxjs';
import { ClientesLocalService } from './clientes-local.service';
import { ClienteModel } from './models';

describe('ClientesLocalService', () => {
  let clientesService: ClientesLocalService;

  beforeEach(() => {
    clientesService = new ClientesLocalService();
  });

  it('can load instance', () => {
    expect(clientesService).toBeTruthy();
  });

  describe('Salvar', () => {
    it('Sem id', async () => {
      const cliente: ClienteModel = {
        id: undefined,
        nome: 'Ana',
        email: 'ana@example.com',
        estadoCivil: 'solteira',
        sexo: 'feminino',
        dataNascimento: new Date(1998, 6, 3).toISOString(),
        cpf: '33366699911',
      };

      await firstValueFrom(clientesService.salvar(cliente));
      const lista = await firstValueFrom(clientesService.listar());
      expect(lista.length).toBe(3);
    });

    it('Com id', async () => {
      const testCliente: ClienteModel = {
        id: 2,
        nome: 'Igor',
        email: 'igor@example.com',
        estadoCivil: 'solteiro',
        sexo: 'masculino',
        dataNascimento: new Date(1998, 6, 2).toISOString(),
        cpf: '12366699911',
      };

      await firstValueFrom(clientesService.salvar(testCliente));
      const cliente = await firstValueFrom(clientesService.get(2));
      expect(cliente.nome).toEqual(testCliente.nome);
    });
  });

  describe('Recuperar informações', () => {
    it('Lista de estado civil', async () => {
      const resCliente = await firstValueFrom(
        clientesService.getListaEstadoCivil()
      );
      expect(resCliente.length).toBe(3);
    });

    it('Cliente inexistente', async () => {
      const cliente = await firstValueFrom(clientesService.get(99))
        .then((value) => {
          expect(value).toBeUndefined();
        })
        .catch((e: unknown) => {
          expect(e).toBeDefined();
        });
      expect(cliente).toBeUndefined();
    });
  });

  describe('Remover', () => {
    it('Cliente pelo Id', async () => {
      await firstValueFrom(clientesService.excluir(2));
      const lista = await firstValueFrom(clientesService.listar());
      expect(lista.length).toBe(1);
    });
  });
});
