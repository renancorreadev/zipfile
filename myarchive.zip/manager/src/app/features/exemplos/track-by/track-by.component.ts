import { Component } from '@angular/core';

/**
 * Interface do objeto item utilizado no exemplo
 */
interface ItemModel {
  /** @ignore */
  id: number;
}

/**
 * Componente que contém um exemplo de quando utilizar track by
 */
@Component({
  selector: 'app-track-by',
  templateUrl: './track-by.component.html',
})
export class TrackByComponent {
  /** @ignore */
  public collection: ItemModel[];

  /** @ignore */
  public exampleHTML = `<p>Para visualizar a ação do operador abra o DevTools e selecione a lista na aba Elements.
A seguir clique no botão.</p>
<ul>
  <li *ngFor="let item of collection;trackBy: trackByFn">{{item.id}}</li>
</ul>
<button mat-flat-button color="primary" (click)="getItems()">Atualizar Lista</button>`;

  /** @ignore */
  public exampleTS = `import { Component } from '@angular/core';

/**
 * Interface do objeto item utilizado no exemplo
 */
interface ItemModel {
  id: number;
}

/**
 * Componente que contém um exemplo de quando utilizar track by
 */
@Component({
  selector: 'app-track-by',
  templateUrl: './track-by.component.html'
})
export class TrackByComponent {

  /** @ignore */
  public collection: Array<ItemModel>;

  /**
   * Constructor
   *
   * @param route
   */
  constructor() {
    this.collection = [{id: 1}, {id: 2}, {id: 3}];
  }

  /**
   * Carrega a lista de itens na colecao
   */
  getItems() {
    this.collection = this.getItemsFromServer();
  }

  /**
   * Retorna a lista de itens a partir do servidor
   */
  getItemsFromServer() {
    return [{id: 1}, {id: 2}, {id: 3}, {id: 4}];
  }

  /**
   * Retorna o item que deve ser atualizado pelo Angular
   */
  trackByFn(index, item) {
    return index; // ou item.id
  }

}
`;

  /** @ignore */
  public exampleSCSS = `/** Nenhum CSS para esse exemplo */`;

  /**
   * Constructor
   */
  constructor() {
    this.collection = [{ id: 1 }, { id: 2 }, { id: 3 }];
  }

  /**
   * Carrega a lista de itens na colecao
   */
  getItems() {
    this.collection = this.getItemsFromServer();
  }

  /**
   * Retorna a lista de itens a partir do servidor
   */
  getItemsFromServer() {
    return [{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }];
  }

  /**
   * Rastreia o item ou id
   * @param index <number>
   * @returns Retorna o item que deve ser atualizado pelo Angular
   */
  trackByFn(index: number) {
    return index; // ou item.id
  }
}
