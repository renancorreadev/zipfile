import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TrackByComponent } from './track-by.component';
import { SharedModule } from '@app/shared//shared.module';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('TrackByComponent', () => {
  let comp: TrackByComponent;
  let fixture: ComponentFixture<TrackByComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: [TrackByComponent],
      schemas: [NO_ERRORS_SCHEMA],
    });
    fixture = TestBed.createComponent(TrackByComponent);
    comp = fixture.componentInstance;
  });
  describe('initialize', () => {
    it('can load instance', () => {
      expect(comp).toBeTruthy();
    });

    it('get itens', () => {
      comp.getItems();
      expect(comp.collection).toEqual([
        { id: 1 },
        { id: 2 },
        { id: 3 },
        { id: 4 },
      ]);
    });

    it('trackBy', () => {
      expect(comp.trackByFn(5)).toBe(5);
    });
  });
});
