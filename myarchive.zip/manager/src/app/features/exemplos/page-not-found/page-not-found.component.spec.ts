import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Params } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found.component';
import { Subject } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('PageNotFoundComponent', () => {
  let comp: PageNotFoundComponent;
  let fixture: ComponentFixture<PageNotFoundComponent>;
  let paramsSub: Subject<Params>;

  beforeEach(() => {
    paramsSub = new Subject<Params>();

    TestBed.configureTestingModule({
      declarations: [PageNotFoundComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: { params: paramsSub, url: paramsSub },
        },
      ],
    });
    fixture = TestBed.createComponent(PageNotFoundComponent);
    comp = fixture.componentInstance;
  });
  describe('initialize', () => {
    it('can load instance', () => {
      expect(comp).toBeTruthy();
    });
  });

  describe('navigate', () => {
    it('rota defaults to: not found', () => {
      comp.ngOnInit();
      fixture.detectChanges();
      paramsSub.next([{ path: 'exemplos' }, { path: 'not found' }]);
      fixture.detectChanges();

      expect(comp.rota).toEqual('not found');

      comp.ngOnDestroy();
      fixture.detectChanges();
      expect(comp.urlSubscription?.closed).toBe(true);
    });
  });
});
