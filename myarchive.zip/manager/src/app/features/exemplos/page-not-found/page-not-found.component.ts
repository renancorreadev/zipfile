import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

/**
 * Compoenente responsável por gerenciar a tela de Page Not Found
 */
@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.componente.scss'],
})
export class PageNotFoundComponent implements OnInit, OnDestroy {
  /** @ignore */
  rota: string = '';
  /** @ignore */
  urlSubscription?: Subscription;

  /**
   * Constructor
   *
   * @param route <ActivatedRoute>
   */
  constructor(private route: ActivatedRoute) {}

  /**
   * Inicialização do componente
   */
  ngOnInit(): void {
    this.urlSubscription = this.route.url.subscribe(
      (url) => (this.rota = url[url.length - 1].path)
    );
  }

  /**
   * Finalização do componente
   */
  ngOnDestroy(): void {
    if (this.urlSubscription && !this.urlSubscription.closed) {
      this.urlSubscription.unsubscribe();
    }
  }
}
