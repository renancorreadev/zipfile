import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientesMfeModule } from '@atle/ng15-biblioteca';

@NgModule({
  imports: [CommonModule, ClientesMfeModule],
  declarations: [],
})
export class MfeModule {}
