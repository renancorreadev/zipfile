import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TransferHttpCacheModule } from '@nguniversal/common';
import { BvNotificationModule } from '@arqt/ng15-ui/notification';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './features/exemplos/page-not-found/page-not-found.component';
import { AppRoutingModule } from './app-routing.module';
import { CoreModule } from '@app/core/core.module';
import { ShellModule } from '@app/shell/shell.module';
import { BvCoreModule } from '@arqt/ng15-framework';
import { ForbiddenComponent } from './features/forbidden/forbidden.component';
import { AppMetatagsService } from '@app/core/app-metatags.service';
import { HttpClientModule } from '@angular/common/http';

import { BffApiModule } from '@bff/api-client';
import { environment } from '../environments/environment';

// import { AuthInterceptor } from './core/auth-interceptor';
// Import new modules only on FeatureModule, SharedModule or CoreModule.

@NgModule({
  imports: [
    BrowserModule.withServerTransition({
      appId: 'ng15-bvlb-base-wallet-manager-app',
    }),
    BvCoreModule.forRoot(environment),
    BffApiModule.forRoot({ rootUrl: environment.apiBv }),
    HttpClientModule,
    TransferHttpCacheModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    CoreModule,
    ShellModule,
    BvNotificationModule,
  ],
  declarations: [AppComponent, PageNotFoundComponent, ForbiddenComponent],
  providers: [
    AppMetatagsService,
    // ,{
    //     provide: HTTP_INTERCEPTORS,     // apenas em casos de desenho com JWT alinhados com arquitetura
    //     useClass: AuthInterceptor,
    //     multi: true
    // }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {}
