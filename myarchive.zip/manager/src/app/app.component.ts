import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';

import {
  BaseComponent,
  BvErrorService,
  BvLogService,
  BvSecurityAccessService,
  ErrorModel,
  SecurityAccessModel,
} from '@arqt/ng15-framework';

import { BvNotificationService } from '@arqt/ng15-ui/notification';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivationEnd } from '@angular/router';
import { AppMetatagsService } from '@app/core/app-metatags.service';
import { filter, takeUntil } from 'rxjs/operators';

/**
 * Componente responsável pelo gerenciamento da aplicação
 */
@Component({
  selector: 'app-root',
  template: '<router-outlet></router-outlet>',
})
export class AppComponent extends BaseComponent implements OnInit {
  /**
   * Constructor
   * @param logger <BvLogService>
   * @param errorService <BvErrorService>
   * @param securityAccessService <BvSecurityAccessService>
   * @param notificationService <BvNotificationService>
   * @param router <Router>
   * @param metatags <AppMetatagsService>
   * @param _platformId <object>
   */
  constructor(
    private logger: BvLogService,
    private errorService: BvErrorService,
    private securityAccessService: BvSecurityAccessService,
    private notificationService: BvNotificationService,
    private router: Router,
    private metatags: AppMetatagsService,
    @Inject(PLATFORM_ID) private _platformId: object
  ) {
    super();
    if (isPlatformBrowser(this._platformId)) {
      this.securityAccessService.securityAccess$
        .pipe(takeUntil(this.onDestroy))
        .subscribe((access: SecurityAccessModel) => {
          if (access.type === 'invalidKey') {
            this.notificationService.warn(
              'Chave Pública Invalida',
              'Fechar',
              5000
            );
            return;
          }
          if (access.type === 'forbidden') {
            this.notificationService.warn('Acesso Negado', 'Fechar', 5000);
          }
        });
    }

    this.router.events
      .pipe(
        takeUntil(this.onDestroy),
        filter(
          // Metatags para SEO
          (event): event is ActivationEnd =>
            event instanceof ActivationEnd &&
            event.snapshot.children.length === 0
        )
      )
      .subscribe((event: ActivationEnd) => {
        this.metatags.setMetatags(event);
      });
  }

  /**
   * Inicialização do componente
   */
  ngOnInit() {
    if (isPlatformBrowser(this._platformId)) {
      this.logger.info('AppComponent:ngOnInit', 'Teste log');

      this.errorService.error$
        .pipe(takeUntil(this.onDestroy))
        .subscribe((error: ErrorModel) => {
          if (error.type === 'runtime') {
            this.notificationService.error(error.shortDescription, 5000);
            console.error(error);
            if (error.fullDescription) {
              console.error(error.fullDescription);
            }
          } else {
            this.notificationService.warn(
              error.shortDescription,
              undefined,
              5000
            );
            console.warn(error);
          }
        });
    }
  }
}
