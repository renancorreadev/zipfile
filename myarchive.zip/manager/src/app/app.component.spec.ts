import { NO_ERRORS_SCHEMA, PLATFORM_ID } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { Router, ActivationEnd, ActivatedRoute } from '@angular/router';
import {
  BvErrorService,
  BvLogService,
  BvSecurityAccessService,
  ErrorModel,
  SecurityAccessModel,
  BvCoreModule,
  ConfigurationModel,
  ConfigurationService,
} from '@arqt/ng15-framework';

import { AppComponent } from './app.component';
import { Subject } from 'rxjs';
import {
  BvNotificationModule,
  BvNotificationService,
} from '@arqt/ng15-ui/notification';
import { environment } from '../environments/environment';
import { AppMetatagsService } from './core/app-metatags.service';

import { spyOn } from 'jest-mock';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('AppComponent', () => {
  let comp: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  let notificationService: BvNotificationService;
  let logService: BvLogService;
  let errorService: BvErrorService;
  let securityAccessService: BvSecurityAccessService;
  let mockConfiguration: { settings: Partial<ConfigurationModel> };
  let route: ActivatedRoute;
  let metatags: AppMetatagsService;

  const routerStub = {
    events: new Subject<ActivationEnd>(),
  };

  const snapshotStub = {
    snapshot: {
      data: {
        metatags: {
          title: 'banco BV title',
          canonical: 'https://www.bv.com.br',
          description: 'banco BV desc',
        },
      },
      children: [],
    },
  };

  beforeAll(() => {
    spyOn(console, 'error').mockImplementation(() => {
      return;
    });
    spyOn(console, 'warn').mockImplementation(() => {
      return;
    });
  });

  beforeEach(async () => {
    mockConfiguration = {
      settings: {
        apiBv: 'http://localhost:3200',
        apiBvConfigs: {
          health: {
            path: '/api-utils/status',
            description: 'Retorna o health-check do backend',
            method: 'GET',
            responseType: 'json',
            observe: 'body',
            withCredentials: true,
            reportProgress: false,
          },
          log: {
            path: '/api-utils/logger',
            method: 'POST',
          },
          'api-docs': {
            path: '/v2/api-docs',
          },
        },
      },
    };

    await TestBed.configureTestingModule({
      declarations: [AppComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [
        BvCoreModule.forRoot(environment),
        BvNotificationModule,
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([]),
      ],
      providers: [
        BvNotificationService,
        AppMetatagsService,
        { provide: PLATFORM_ID, useValue: 'browser' },
        { provide: ConfigurationService, useValue: mockConfiguration },
        { provide: ActivatedRoute, useValue: snapshotStub },
        { provide: Router, useValue: routerStub },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    comp = fixture.componentInstance;

    notificationService = TestBed.inject(BvNotificationService);
    logService = TestBed.inject(BvLogService);
    errorService = TestBed.inject(BvErrorService);
    securityAccessService = TestBed.inject(BvSecurityAccessService);
    route = TestBed.inject(ActivatedRoute);
    metatags = TestBed.inject(AppMetatagsService);

    spyOn(notificationService, 'error').mockImplementation(() => {
      return;
    });
    spyOn(notificationService, 'warn').mockImplementation(() => {
      return;
    });
    spyOn(notificationService, 'success').mockImplementation(() => {
      return;
    });
  });

  afterAll(() => {
    spyOn(logService, 'info').mockRestore();
    spyOn(logService, 'warn').mockRestore();
    spyOn(console, 'error').mockRestore();
    spyOn(console, 'warn').mockRestore();
  });

  afterEach(() => {
    spyOn(notificationService, 'error').mockRestore();
    spyOn(notificationService, 'warn').mockRestore();
    spyOn(notificationService, 'success').mockRestore();
    spyOn(metatags, 'setMetatags').mockRestore();
  });

  it('can load instance', () => {
    expect(comp).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(logService, 'info');
      comp.ngOnInit();
      expect(logService.info).toHaveBeenCalled();
    });
  });

  describe('Error Notification', () => {
    it('should handle runtime error', () => {
      spyOn(notificationService, 'error');

      comp.ngOnInit();
      const errorModelStub = new ErrorModel(
        'runtime',
        '999',
        'Error Message',
        'Error Stack'
      );

      errorService.next(errorModelStub);
      fixture.detectChanges();

      expect(notificationService.error).toHaveBeenCalledWith(
        errorModelStub.shortDescription,
        5000
      );
    });

    it('should handle http error', () => {
      comp.ngOnInit();
      const errorModelStub = new ErrorModel(
        'http',
        '404',
        'Erro Message',
        '',
        'guid'
      );
      errorService.next(errorModelStub);
      fixture.detectChanges();
      expect(notificationService.warn).toHaveBeenCalledWith(
        errorModelStub.shortDescription,
        undefined,
        5000
      );
      expect(console.warn).toHaveBeenCalled();
    });
  });

  describe('Security Notification', () => {
    it('should handle invalidKey error', () => {
      const securityModelStub: SecurityAccessModel = {
        route: 'teste',
        type: 'invalidKey',
      };
      securityAccessService.next(securityModelStub);
      fixture.detectChanges();
      expect(notificationService.warn).toHaveBeenCalledWith(
        'Chave Pública Invalida',
        'Fechar',
        5000
      );
      expect(console.warn).toHaveBeenCalled();
    });

    it('should handle forbidden error', () => {
      const securityModelStub: SecurityAccessModel = {
        route: 'teste',
        type: 'forbidden',
      };
      securityAccessService.next(securityModelStub);
      fixture.detectChanges();
      expect(notificationService.warn).toHaveBeenCalledWith(
        'Acesso Negado',
        'Fechar',
        5000
      );
      expect(console.warn).toHaveBeenCalled();
    });
  });

  describe('Router Events', () => {
    it('should set metatags', () => {
      const event = new ActivationEnd(route.snapshot);
      spyOn(metatags, 'setMetatags');
      routerStub.events.next(event);
      expect(metatags.setMetatags).toBeCalled();
    });
  });
});
