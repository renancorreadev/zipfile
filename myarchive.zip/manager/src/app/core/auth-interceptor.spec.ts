import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpResponse,
  HTTP_INTERCEPTORS,
} from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { AuthInterceptor } from './auth-interceptor';
import { BvLoginService } from '@arqt/ng15-framework';
import { of, throwError } from 'rxjs';

describe('Http Interceptor', () => {
  let controller: HttpTestingController;
  let http: HttpClient;
  let loginService: BvLoginService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],

      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: AuthInterceptor,
          multi: true,
        },
      ],
    });

    http = TestBed.inject(HttpClient);
    controller = TestBed.inject(HttpTestingController);
    loginService = TestBed.inject(BvLoginService);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    controller.verify();
    sessionStorage.clear();
    jest.restoreAllMocks();
  });

  /**
   * Testa se o Interceptor grava os tokens após o login
   */
  it('Authorization and Refresh must be defined on sessionStorage, after login', (done) => {
    const KEY_JWT = 'Authorization';
    const token = 'token_abc';
    const KEY_REFRESH = 'Refresh';
    const refreshToken = 'refresh_abc';
    expect.assertions(3);

    http.get('/j_security_check').subscribe((j_security_check) => {
      expect(j_security_check).toBeTruthy();
      expect(sessionStorage.getItem(KEY_JWT)).toEqual(token);
      expect(sessionStorage.getItem(KEY_REFRESH)).toEqual(refreshToken);
      done();
    });
    const req = controller.expectOne('/j_security_check');
    req.flush(new HttpResponse(), {
      status: 200,
      statusText: 'OK',
      headers: new HttpHeaders()
        .set(KEY_JWT, token)
        .set(KEY_REFRESH, refreshToken),
    });
  });

  /**
   * Testa se o Interceptor grava os tokens após o refresh
   */
  it('Refresh and Authorization must be defined on sessionStorage, after refreshing', (done) => {
    const KEY_JWT = 'Authorization';
    const token = 'token_abc';
    const KEY_REFRESH = 'Refresh';
    const refreshToken = 'refresh_abc';
    expect.assertions(3);

    http.get('/api-security/refresh').subscribe((refresh) => {
      expect(refresh).toBeTruthy();
      expect(sessionStorage.getItem(KEY_JWT)).toEqual(token);
      expect(sessionStorage.getItem(KEY_REFRESH)).toEqual(refreshToken);
      done();
    });
    const req = controller.expectOne('/api-security/refresh');
    req.flush(new HttpResponse(), {
      status: 200,
      statusText: 'OK',
      headers: new HttpHeaders()
        .set(KEY_JWT, token)
        .set(KEY_REFRESH, refreshToken),
    });
  });

  /**
   * Testa se o Interceptor pega o auth token da sessionStorage
   */
  it('Authorization must be set on request', (done) => {
    const KEY_JWT = 'Authorization';
    const token = 'token_abc';
    sessionStorage.setItem(KEY_JWT, token);
    expect.assertions(2);

    http.get('/api/endpoint').subscribe(() => {
      done();
    });

    const req = controller.expectOne('/api/endpoint');
    req.flush(new HttpResponse(), {
      status: 200,
      statusText: 'OK',
      headers: new HttpHeaders().set(KEY_JWT, token),
    });

    expect(req.request.headers.has(KEY_JWT)).toBe(true);
    expect(req.request.headers.get(KEY_JWT)).toEqual(token);
  });

  /**
   * Testa se o Interceptor trata erro de rede
   */
  it('should occur an network error', (done) => {
    const mockError = new HttpErrorResponse({
      status: 503,
      statusText: 'ERROR',
      url: '/test',
    });
    http.get('/test').subscribe({
      next: (value) => {
        expect(value).toBeFalsy();
        done();
      },
      error: (error) => {
        expect(error).toBeTruthy();
        done();
      },
    });
    const req = controller.expectOne('/test');

    req.flush({}, mockError);
  });

  /**
   * Testa se o Interceptor trata erro 401 (Auth)
   */
  it('should occur an auth error (401)', () => {
    jest.spyOn(loginService, 'refreshToken').mockReturnValue(of('newToken'));

    const KEY_REFRESH = 'Refresh';
    const refreshToken = 'refresh_abc';
    sessionStorage.setItem(KEY_REFRESH, refreshToken);

    const mockError = new HttpErrorResponse({
      status: 401,
      statusText: 'ERROR',
      url: '/test',
    });
    http.get('/test').subscribe();

    const req = controller.expectOne('/test');
    req.flush({}, mockError);
    controller.match('/test');

    expect.assertions(2);
    expect(req.cancelled).toBeTruthy();
    expect(loginService.refreshToken).toHaveBeenCalledTimes(1);
  });

  it('- should occur an auth error (401) again and call logout', () => {
    const mockRefreshError = new HttpErrorResponse({
      status: 401,
      statusText: 'ERROR',
      url: '/refresh',
    });

    jest
      .spyOn(loginService, 'refreshToken')
      .mockImplementation(() => throwError(() => mockRefreshError));
    jest.spyOn(loginService, 'logout').mockReturnValue(of({}));

    const KEY_REFRESH = 'Refresh';
    const refreshToken = 'refresh_abc';
    sessionStorage.setItem(KEY_REFRESH, refreshToken);

    const mockError = new HttpErrorResponse({
      status: 401,
      statusText: 'ERROR',
      url: '/test',
    });

    // first call
    http.get('/test').subscribe();
    let req = controller.expectOne('/test');
    req.flush({}, mockError);
    controller.match('/test');
    expect(req.cancelled).toBeTruthy();

    // second call
    http.get('/test').subscribe();
    req = controller.expectOne('/test');
    req.flush({}, mockError);
    controller.match('/test');
    expect(req.cancelled).toBeTruthy();

    expect.assertions(4);
    expect(loginService.refreshToken).toHaveBeenCalledTimes(1);
    expect(loginService.logout).toHaveBeenCalledTimes(1);
  });
});
