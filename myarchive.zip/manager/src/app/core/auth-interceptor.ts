import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, switchMap, take, tap } from 'rxjs/operators';
import { BvLoginService } from '@arqt/ng15-framework';

/**
 * Interceptador de requisições e suas autorizações
 */
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  /** @ignore */
  private KEY_JWT = 'Authorization';
  /** @ignore */
  private KEY_REFRESH = 'Refresh';
  /** @ignore */
  private LOGIN_ENDPOINT = '/J_SECURITY_CHECK';
  /** @ignore */
  private REFRESH_ENDPOINT = '/API-SECURITY/REFRESH';

  private isRefreshing: boolean = false;

  /**
   * Constructor
   * @param loginService <BvLoginService>
   */
  constructor(private loginService: BvLoginService) {}

  /**
   * Captura requisições, modifica e as retornam atualizadas
   * @param request <HttpRequest>
   * @param next <HttpHandler>
   * @returns Retorna uma resposta de requisição de acordo com o token da sessão
   */
  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    const token = sessionStorage.getItem(this.KEY_JWT);

    if (token !== null && !this.verifyValidUrl(request.url)) {
      request = request.clone({
        setHeaders: {
          Authorization: `${token}`,
        },
      });
    }

    return next.handle(request).pipe(
      tap((res: HttpEvent<unknown>) => this.handleHttpEvent(res)),
      catchError((err: unknown) => this.handleError(request, next, err))
    );
  }

  /** @ignore */
  private handleHttpEvent(res: HttpEvent<unknown>): HttpEvent<unknown> {
    if (res instanceof HttpResponse && this.verifyValidUrl(res.url)) {
      const key_jwt = res.headers.get(this.KEY_JWT);
      const key_refresh = res.headers.get(this.KEY_REFRESH);
      if (key_jwt) {
        sessionStorage.setItem(this.KEY_JWT, key_jwt);
      }

      if (key_refresh) {
        sessionStorage.setItem(this.KEY_REFRESH, key_refresh);
      }
    }
    return res;
  }

  /** @ignore */
  private handleError(
    request: HttpRequest<unknown>,
    next: HttpHandler,
    err: unknown
  ): Observable<HttpEvent<unknown>> {
    const refreshToken = sessionStorage.getItem(this.KEY_REFRESH);

    if (
      err instanceof HttpErrorResponse &&
      err.status === 401 &&
      !this.verifyValidUrl(err.url) &&
      refreshToken !== null
    ) {
      if (!this.isRefreshing) {
        this.isRefreshing = true;
        return this.loginService.refreshToken(refreshToken).pipe(
          switchMap(() => {
            this.isRefreshing = false;
            return next.handle(request);
          })
        );
      } else {
        this.loginService.logout().pipe(take(1)).subscribe();
        return throwError(() => err);
      }
    } else {
      return throwError(() => err);
    }
  }

  /** @ignore */
  private verifyValidUrl(url: unknown): boolean {
    if (typeof url !== 'string') {
      return false;
    }
    return (
      url.toUpperCase().endsWith(this.LOGIN_ENDPOINT) ||
      url.toUpperCase().endsWith(this.REFRESH_ENDPOINT)
    );
  }
}
