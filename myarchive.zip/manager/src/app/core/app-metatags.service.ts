import { Injectable, Inject } from '@angular/core';
import { Title, Meta } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/common';
import { ActivationEnd } from '@angular/router';

/**
 * Serviço responsável por gerenciar os marcadores em formato de texto
 */
@Injectable({
  providedIn: 'root',
})
export class AppMetatagsService {
  /** @ignore */
  defaultTitle: string;
  /** @ignore */
  defaultDescription: string;
  /** @ignore */
  titleText?: string;
  /** @ignore */
  canonicalUrl?: string;
  /** @ignore */
  descriptionText?: string;

  /**
   * Constructor
   * @param title <Title>
   * @param meta <Meta>
   * @param doc <Document>
   */
  constructor(
    private title: Title,
    private meta: Meta,
    @Inject(DOCUMENT) private doc: Document
  ) {
    this.defaultTitle = 'banco BV';
    this.defaultDescription = 'banco BV';
  }

  /**
   * Define o título da página
   * @param title <string>
   */
  setPageTitle(title = '') {
    this.titleText = title || this.defaultTitle;
    this.title.setTitle(this.titleText);
  }

  /**
   * Define um link aos mecanismos de busca e o codifica
   * @param canonical <string>
   */
  setCanonicalUrl(canonical = '') {
    this.canonicalUrl = canonical || this.doc.URL;
    const link = this.doc.querySelector('link[rel="canonical"]');
    if (link) {
      link.setAttribute('href', encodeURIComponent(this.canonicalUrl));
    }
  }

  /**
   * Define a descrição da página (nome e conteúdo)
   * @param description <string>
   */
  setPageDescription(description = '') {
    this.descriptionText = description || this.defaultDescription;
    this.meta.updateTag({ name: 'description', content: this.descriptionText });
  }

  /**
   * Incorpora as metatags referentes as páginas
   * @param event <ActivationEnd>
   */
  setMetatags(event: ActivationEnd) {
    const { metatags = {} } = event.snapshot.data;
    this.setPageTitle(metatags.title);
    this.setCanonicalUrl(metatags.canonical);
    this.setPageDescription(metatags.description);
  }
}
