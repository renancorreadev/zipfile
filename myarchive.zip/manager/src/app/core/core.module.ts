import { CommonModule } from '@angular/common';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { ConfigurationService } from '@arqt/ng15-framework';
import { RouteReuseStrategy } from '@angular/router';
import { RouteReusableStrategyService } from '@app/core/route-reusable-strategy.service';
import { AppConfigService } from '@app/core/app-config.service';

/*
  core.module
  Interceptors, global components and singleton services that
  you load to be used to instantiate your app.
  Don´t import modules or non singleton service
*/
@NgModule({
  providers: [
    {
      provide: RouteReuseStrategy,
      useClass: RouteReusableStrategyService,
    },
    {
      provide: ConfigurationService,
      useClass: AppConfigService,
    },
  ],
  imports: [CommonModule],
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule?: CoreModule) {
    if (parentModule) {
      throw new Error(
        `CoreModule has already been loaded. Import Core module in the AppModule only.`
      );
    }
  }
}
