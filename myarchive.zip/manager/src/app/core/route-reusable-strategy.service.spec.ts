import { RouteReusableStrategyService } from './route-reusable-strategy.service';
import {
  ActivatedRouteSnapshot,
  RouteReuseStrategy,
  UrlSegment,
  convertToParamMap,
} from '@angular/router';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('AppConfigService', () => {
  let service: RouteReusableStrategyService;
  const commonSnapshot = {
    data: jest.fn(),
    url: [new UrlSegment('path', { id: '33' })],
    params: [],
    paramMap: convertToParamMap(new Map<string, string>()),
    queryParams: [],
    queryParamMap: convertToParamMap(new Map<string, string>()),
    fragment: null,
    outlet: '',
    component: null,
    routeConfig: null,
    root: new ActivatedRouteSnapshot(),
    parent: null,
    firstChild: null,
    children: [],
    pathFromRoot: [],
  };
  const mockCurrentActivatedRouteSnapshot: ActivatedRouteSnapshot = {
    ...commonSnapshot,
    title: '',
  };

  const mockFutureActivatedRouteSnapshot: ActivatedRouteSnapshot = {
    ...commonSnapshot,
    routeConfig: {},
    title: '',
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [],
      schemas: [],
      providers: [
        {
          provide: RouteReuseStrategy,
          useClass: RouteReusableStrategyService,
        },
      ],
    });
    service = TestBed.inject(RouteReuseStrategy);
  });

  it('can load service', () => {
    const route = new ActivatedRouteSnapshot();
    expect(service).toBeTruthy();
    expect(service.shouldDetach(route)).toBeFalsy();
    expect(service.shouldAttach(route)).toBeFalsy();
    expect(service.retrieve(route)).toBeNull();
  });

  it('should reuse route true', () => {
    expect(
      service.shouldReuseRoute(
        mockFutureActivatedRouteSnapshot,
        mockFutureActivatedRouteSnapshot
      )
    ).toBeTruthy();
  });

  it('should reuse route false', () => {
    expect(
      service.shouldReuseRoute(
        mockFutureActivatedRouteSnapshot,
        mockCurrentActivatedRouteSnapshot
      )
    ).toBeFalsy();
  });
});
