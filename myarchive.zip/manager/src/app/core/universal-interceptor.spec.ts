import { TestBed } from '@angular/core/testing';
import { HttpHandler, HttpHeaders, HttpResponse } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { PLATFORM_ID } from '@angular/core';
import { REQUEST } from '@nguniversal/express-engine/tokens';
import { TransferState } from '@angular/platform-browser';
import { UniversalInterceptor } from './universal-interceptor';
import { of } from 'rxjs';
import { spyOn } from 'jest-mock';

describe('UniversalInterceptor', () => {
  let service: UniversalInterceptor;

  // const PLATFORM_BROWSER_ID = 'browser';
  const PLATFORM_SERVER_ID = 'server';
  beforeEach(() => {
    const httpHandlerStub = { handle: jest.fn() };
    // const httpRequestStub = { url: '/test', clone: jest.fn() };
    const httpRequestStub = new HttpRequest('GET', '/test');
    const requestStub = {
      cookies: [{ j_session_id: '123' }, { jwt: 'jwtteste' }],
    };
    const transferStateStub = {};
    TestBed.configureTestingModule({
      providers: [
        UniversalInterceptor,
        { provide: HttpHandler, useValue: httpHandlerStub },
        { provide: HttpRequest, useValue: httpRequestStub },
        { provide: REQUEST, useValue: requestStub },
        { provide: TransferState, useValue: transferStateStub },
        { provide: PLATFORM_ID, useValue: PLATFORM_SERVER_ID },
        { provide: 'ORIGIN_URL', useValue: 'http://server' },
      ],
    });
    service = TestBed.get(UniversalInterceptor);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('intercept', () => {
    it('makes expected calls', () => {
      const httpHandlerStub: HttpHandler = TestBed.inject(HttpHandler);
      const httpRequestStub: HttpRequest<unknown> = TestBed.inject(HttpRequest);
      const headers = new HttpHeaders()
        .append('Cookie', 'key=valor')
        .append('Cookies', "[{ j_session_id: '123' }, { jwt: 'xoansdsoand' }]");

      spyOn(httpHandlerStub, 'handle').mockReturnValue(of(new HttpResponse()));
      spyOn(httpRequestStub, 'clone').mockReturnValue(
        httpRequestStub.clone({
          url: 'http://server/test',
          headers: headers,
        })
      );
      service.intercept(httpRequestStub, httpHandlerStub).subscribe();
      expect(httpHandlerStub.handle).toHaveBeenCalled();
      expect(httpRequestStub.clone).toHaveBeenCalled();
    });
  });
});

describe('UniversalInterceptor ORIGIN_URL null', () => {
  let service: UniversalInterceptor;

  // const PLATFORM_BROWSER_ID = 'browser';
  const PLATFORM_SERVER_ID = 'server';
  beforeEach(() => {
    const httpHandlerStub = { handle: jest.fn() };
    // const httpRequestStub = { url: '/test', clone: jest.fn() };
    const httpRequestStub = new HttpRequest('GET', '/test');
    const requestStub = { cookies: {} };
    const transferStateStub = {};
    TestBed.configureTestingModule({
      providers: [
        UniversalInterceptor,
        { provide: HttpHandler, useValue: httpHandlerStub },
        { provide: HttpRequest, useValue: httpRequestStub },
        { provide: REQUEST, useValue: requestStub },
        { provide: TransferState, useValue: transferStateStub },
        { provide: PLATFORM_ID, useValue: PLATFORM_SERVER_ID },
        { provide: 'ORIGIN_URL', useValue: null },
      ],
    });
    service = TestBed.inject(UniversalInterceptor);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('intercept', () => {
    it('makes expected calls', () => {
      const httpHandlerStub: HttpHandler = TestBed.inject(HttpHandler);
      const httpRequestStub: HttpRequest<unknown> = TestBed.inject(HttpRequest);
      const headers = new HttpHeaders()
        .append('Cookie', 'key=valor')
        .append('Cookies', "[{ j_session_id: '123' }, { jwt: 'jwtteste' }]");
      /* .append('j_session_id', '123')
        .append('jwt', 'jwtteste'); */

      spyOn(httpHandlerStub, 'handle').mockReturnValue(of(new HttpResponse()));
      spyOn(httpRequestStub, 'clone').mockReturnValue(
        httpRequestStub.clone({
          url: 'http://server/test',
          headers: headers,
        })
      );

      service.intercept(httpRequestStub, httpHandlerStub).subscribe();
      expect(httpHandlerStub.handle).toHaveBeenCalled();
    });
  });

  describe('intercept', () => {
    it('makes expected calls', () => {
      const httpHandlerStub: HttpHandler = TestBed.inject(HttpHandler);
      const httpRequestStub: HttpRequest<unknown> = TestBed.inject(HttpRequest);
      const headers = new HttpHeaders()
        .append('Cookie', 'key=valor')
        .append('Cookies', "[{ j_session_id: '123' }, { jwt: 'jwtteste' }]");

      spyOn(httpHandlerStub, 'handle').mockReturnValue(of(new HttpResponse()));
      spyOn(httpRequestStub, 'clone').mockReturnValue(
        httpRequestStub.clone({
          url: 'http://server/test',
          headers: headers,
        })
      );

      service.intercept(httpRequestStub, httpHandlerStub).subscribe();
      expect(httpHandlerStub.handle).toHaveBeenCalled();
    });
  });
});

describe('UniversalInterceptor com PLATFORM_SERVER_ID nulo e ORIGIN_URL nulo', () => {
  let service: UniversalInterceptor;

  const PLATFORM_SERVER_ID = null;
  beforeEach(() => {
    const httpHandlerStub = { handle: jest.fn() };
    // const httpRequestStub = { url: '/test', clone: jest.fn() };
    const httpRequestStub = new HttpRequest('GET', '/test');
    const requestStub = { cookies: {} };
    const transferStateStub = {};
    TestBed.configureTestingModule({
      providers: [
        UniversalInterceptor,
        { provide: HttpHandler, useValue: httpHandlerStub },
        { provide: HttpRequest, useValue: httpRequestStub },
        { provide: REQUEST, useValue: requestStub },
        { provide: TransferState, useValue: transferStateStub },
        { provide: PLATFORM_ID, useValue: PLATFORM_SERVER_ID },
        { provide: 'ORIGIN_URL', useValue: null },
      ],
    });
    service = TestBed.inject(UniversalInterceptor);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('intercept', () => {
    it('makes expected calls', () => {
      const httpHandlerStub: HttpHandler = TestBed.inject(HttpHandler);
      const httpRequestStub: HttpRequest<unknown> = TestBed.inject(HttpRequest);
      const headers = new HttpHeaders()
        .append('Cookie', 'key=valor')
        .append('Cookies', "[{ j_session_id: '123' }, { jwt: 'xoansdsoand' }]");

      spyOn(httpHandlerStub, 'handle').mockReturnValue(of(new HttpResponse()));
      spyOn(httpRequestStub, 'clone').mockReturnValue(
        httpRequestStub.clone({
          url: 'http://server/test',
          headers: headers,
        })
      );

      service.intercept(httpRequestStub, httpHandlerStub).subscribe();
      expect(httpHandlerStub.handle).toHaveBeenCalled();
    });
  });

  describe('intercept', () => {
    it('makes expected calls', () => {
      const httpHandlerStub: HttpHandler = TestBed.inject(HttpHandler);
      const httpRequestStub: HttpRequest<unknown> = TestBed.inject(HttpRequest);
      const headers = new HttpHeaders().append('Cookie', 'cookieString');

      spyOn(httpHandlerStub, 'handle').mockReturnValue(of(new HttpResponse()));
      spyOn(httpRequestStub, 'clone').mockReturnValue(
        httpRequestStub.clone({
          url: '',
          headers: headers,
        })
      );

      service.intercept(httpRequestStub, httpHandlerStub).subscribe();
      expect(httpHandlerStub.handle).toHaveBeenCalled();
    });
  });
});

describe('UniversalInterceptor', () => {
  let service: UniversalInterceptor;
  const PLATFORM_SERVER_ID = null;

  beforeEach(() => {
    const httpHandlerStub = { handle: jest.fn() };
    // const httpRequestStub = { url: '/test', clone: jest.fn() };
    const httpRequestStub = new HttpRequest('GET', '/test');
    const requestStub = { cookies: {} };
    const transferStateStub = {};
    TestBed.configureTestingModule({
      providers: [
        UniversalInterceptor,
        { provide: HttpHandler, useValue: httpHandlerStub },
        { provide: HttpRequest, useValue: httpRequestStub },
        { provide: REQUEST, useValue: requestStub },
        { provide: TransferState, useValue: transferStateStub },
        { provide: PLATFORM_ID, useValue: PLATFORM_SERVER_ID },
        { provide: 'ORIGIN_URL', useValue: 'http://server' },
      ],
    });
    service = TestBed.get(UniversalInterceptor);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('intercept', () => {
    it('makes expected calls', () => {
      const httpHandlerStub: HttpHandler = TestBed.inject(HttpHandler);
      const httpRequestStub: HttpRequest<unknown> = TestBed.inject(HttpRequest);
      const headers = new HttpHeaders().append('Cookie', 'cookieString');

      spyOn(httpHandlerStub, 'handle').mockReturnValue(of(new HttpResponse()));
      spyOn(httpRequestStub, 'clone').mockReturnValue(
        httpRequestStub.clone({
          url: 'http://server/test',
          headers: headers,
        })
      );

      service.intercept(httpRequestStub, httpHandlerStub).subscribe();
      expect(httpHandlerStub.handle).toHaveBeenCalled();
      expect(httpRequestStub.clone).toHaveBeenCalled();
    });
  });
});
