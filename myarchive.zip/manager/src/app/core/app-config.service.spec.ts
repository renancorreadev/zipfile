import { AppConfigService } from './app-config.service';

describe('AppConfigService', () => {
  let service: AppConfigService;

  beforeEach(() => {
    service = new AppConfigService();
  });

  it('can retrieve settings', () => {
    expect(service).toBeTruthy();
    expect(service.settings).toBeDefined();
  });
});
