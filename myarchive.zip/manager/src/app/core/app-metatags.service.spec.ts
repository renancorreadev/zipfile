import { TestBed } from '@angular/core/testing';
import { AppMetatagsService } from './app-metatags.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Title, Meta } from '@angular/platform-browser';
import { ActivationEnd, ActivatedRoute } from '@angular/router';

describe('AppMetatagsService', () => {
  let service: AppMetatagsService;
  let route: ActivatedRoute;
  let testData: { title: string; canonical: string; description: string };

  beforeEach(async () => {
    testData = {
      title: 'Teste title, banco BV',
      canonical: 'https://www.bancobv.com.br',
      description: 'Teste description, banco BV',
    };

    document.head.innerHTML = '<link rel="canonical" href="/">';

    const TitleStub = {
      setTitle: () => {
        return;
      },
    };

    const MetaStub = {
      updateTag: () => {
        return;
      },
    };

    const SnapshotStub = {
      snapshot: {
        data: {
          metatags: {
            title: 'banco BV title',
            canonical: 'https://www.bv.com.br',
            description: 'banco BV desc',
          },
        },
      },
    };

    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        AppMetatagsService,
        { provide: Title, useValue: TitleStub },
        { provide: Meta, useValue: MetaStub },
        { provide: ActivatedRoute, useValue: SnapshotStub },
      ],
    }).compileComponents();
    service = TestBed.inject(AppMetatagsService);
    route = TestBed.inject(ActivatedRoute);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it(`Should have as default title 'banco BV'`, () => {
    expect(service.defaultTitle).toEqual('banco BV');
  });

  it(`Should have as default description 'banco BV'`, () => {
    expect(service.defaultDescription).toEqual('banco BV');
  });

  describe('SEO', () => {
    it('Should set page title', () => {
      service.setPageTitle(testData.title);
      expect(service.titleText).toEqual('Teste title, banco BV');
    });

    it('Should set page title to default', () => {
      service.setPageTitle('');
      expect(service.titleText).toEqual('banco BV');
    });

    it('Should set page description', () => {
      service.setPageDescription(testData.description);
      expect(service.descriptionText).toEqual('Teste description, banco BV');
    });

    it('Should set page description to default', () => {
      service.setPageDescription('');
      expect(service.descriptionText).toEqual('banco BV');
    });

    it('Should set metatags', () => {
      const event = new ActivationEnd(route.snapshot);
      service.setMetatags(event);
      expect(service.titleText).toEqual('banco BV title');
      expect(service.canonicalUrl).toEqual('https://www.bv.com.br');
      expect(service.descriptionText).toEqual('banco BV desc');
    });
  });

  describe('Testing setters', () => {
    it('setting', () => {
      service.setPageTitle('PAGE_TITLE');
      service.setCanonicalUrl('CAN_URL');
      service.setPageDescription('PAGE_DESCRIPTION');

      expect(service.titleText).toEqual('PAGE_TITLE');
      expect(service.canonicalUrl).toEqual('CAN_URL');
      expect(service.descriptionText).toEqual('PAGE_DESCRIPTION');

      service.setPageTitle();
      service.setCanonicalUrl();
      service.setPageDescription();

      expect(service.titleText).toEqual('banco BV');
      expect(service.descriptionText).toEqual('banco BV');
    });
  });
});
