/* eslint-disable @typescript-eslint/no-unused-vars */
import {
  ActivatedRouteSnapshot,
  DetachedRouteHandle,
  RouteReuseStrategy,
} from '@angular/router';
import { Injectable } from '@angular/core';

/**
 * Uma estratégia de rota que permite a reutilização explícita de rotas.
 * Usado como uma solução alternativa para https://github.com/angular/angular/issues/18374
 * Para reutilizar uma determinada rota, adicione 'data: { reuse: true }' à definição de rota.
 */
@Injectable()
export class RouteReusableStrategyService extends RouteReuseStrategy {
  /**
   * Informações extraídas de uma rota
   * @param route <ActivatedRouteSnapshot>
   * @returns Retorna um boleano false
   */
  public shouldDetach(route: ActivatedRouteSnapshot): boolean {
    return false;
  }

  /**
   * Armazena as informações das rotas
   * @param route <ActivatedRouteSnapshot>
   * @param detachedTree <DetachedRouteHandle>
   * @returns void
   */
  public store(
    route: ActivatedRouteSnapshot,
    detachedTree: DetachedRouteHandle | null
  ): void {
    return;
  }

  /**
   * Anexa as informações extraídas da rota
   * @param route <ActivatedRouteSnapshot>
   * @returns Retorna um boleano false
   */
  public shouldAttach(route: ActivatedRouteSnapshot): boolean {
    return false;
  }

  /**
   * Recupera as informações da rota
   * @param route <ActivatedRouteSnapshot>
   * @returns Retorna um valor nulo
   */
  public retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle | null {
    return null;
  }

  /**
   * Reutiliza as informações da rota
   * @param future <ActivatedRouteSnapshot>
   * @param curr <ActivatedRouteSnapshot>
   * @returns Retorna os dados de routeConfig
   */
  public shouldReuseRoute(
    future: ActivatedRouteSnapshot,
    curr: ActivatedRouteSnapshot
  ): boolean {
    return (
      Boolean(future.data['reuse']) ||
      (!!future.routeConfig && future.routeConfig === curr.routeConfig)
    );
  }
}
