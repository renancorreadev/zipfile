import { Injectable, Inject, Optional, PLATFORM_ID } from '@angular/core';
import {
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpEvent,
  HttpResponse,
} from '@angular/common/http';
import { isPlatformServer } from '@angular/common';
import { Request } from 'express';
import { REQUEST } from '@nguniversal/express-engine/tokens';
import { TransferState } from '@angular/platform-browser';
import { map } from 'rxjs/operators';

/** require: NodeRequire */
declare let require: NodeRequire;

/**
 * Interceptador de requisições
 */
@Injectable()
export class UniversalInterceptor implements HttpInterceptor {
  /**
   * Constructor
   * @param _platformId <object>
   * @param req <Request>
   * @param transferState <TransferState>
   * @param serverUrl <string>
   */
  constructor(
    @Inject(PLATFORM_ID) private _platformId: object,
    @Inject(REQUEST) private req: Request,
    protected transferState: TransferState,
    @Optional() @Inject('ORIGIN_URL') protected serverUrl: string
  ) {}

  /**
   * Captura e verifica requisições em conformidade
   * @param request <HttpRequest>
   * @param next <HttpHandler>
   * @returns Retorna uma requisição atualizada depois de verificar se a URL é válida
   */
  intercept(request: HttpRequest<unknown>, next: HttpHandler) {
    // Absolute paths to relative
    if (!this.serverUrl || !request.url.startsWith('/')) {
      return next.handle(request);
    }

    request = request.clone({
      url: `${this.serverUrl}${request.url}`,
    });

    if (isPlatformServer(this._platformId)) {
      // JSESSIONID
      const cookieString = Object.keys(this.req.cookies).reduce(
        (accumulator, cookieName) => {
          accumulator += cookieName + '=' + this.req.cookies[cookieName] + ';';
          return accumulator;
        },
        ''
      );

      request = request.clone({
        setHeaders: {
          Cookie: cookieString,
        },
      });
    }

    return next.handle(request).pipe(
      map((event: HttpEvent<unknown>) => {
        if (
          event instanceof HttpResponse &&
          isPlatformServer(this._platformId)
        ) {
          console.log(
            '\n Http event',
            require('util').inspect(event, false, null, true),
            '\n'
          );
        }
        return event;
      })
    );
  }
}
