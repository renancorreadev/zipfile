import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

/**
 * Serviço responsável pelo tratamento do componente de Configuration
 */
@Injectable({
  providedIn: 'root',
})
export class AppConfigService {
  get settings() {
    return environment;
  }
}
