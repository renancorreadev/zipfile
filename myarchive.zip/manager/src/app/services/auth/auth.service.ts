import { Injectable } from '@angular/core';
import {Auth} from "libwallet";

@Injectable({
  providedIn: 'root',
})
export class AuthService {


  async login(email: string, password: string): Promise<string>{
    try{
    const response = await Auth.loggingIn(email, password);
    return response as string 
    }catch(error){
        throw new Error('Falha no login:' + (error as any).Error);
    }
  }


}