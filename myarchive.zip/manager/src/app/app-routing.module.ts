import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { Shell } from '@app/shell/shell.service';
import { ShellComponent } from '@app/shell/shell.component';
import { PageNotFoundComponent } from '@app/features/exemplos/page-not-found/page-not-found.component';
import { BvAuthorizationGuard } from '@arqt/ng15-framework';
import { ForbiddenComponent } from './features/forbidden/forbidden.component';

const routes: Routes = [
  // Opção PreRender AppShell '/' route
  {
    path: '',
    component: ShellComponent,
    data: { reuse: true, redirectAfterRender: '/dashboard' },
  },
  // Opção SSR // Desabilitar '/' de static paths
  // { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  {
    path: 'login',
    loadChildren: () =>
      import('./login/login.module').then((m) => m.LoginModule),
    data: {
      metatags: {
        // Opções de metatags para SEO
        title: 'Login - Aplicação de Referência Angular 15 | banco BV',
        canonical: '',
        description: 'banco BV, página de login',
      },
    },
  },
  {
    path: 'static/hot-site',
    loadChildren: () =>
      import('./features/hot-site/hot-site.module').then(
        (m) => m.HotSiteModule
      ),
  },
  Shell.childRoutes([
    /**
     * BvAuthenticationGuard aplicado no canActivate de todas as rotas abaixo,
     * através do utilitário Shell. Mesmo que canMatch permita o carregamento
     * do módulo, se o canActivate aplicado proibir o acesso, a rota não será carregada.
     */
    {
      path: 'users',
      loadChildren: () =>
        import('./features/users/users.module').then((m) => m.UsersModule),
    },
    {
      path: 'contracts',
      loadChildren: () =>
        import('./features/contracts/contracts.module').then(
          (m) => m.ContractsModule
        ),
    },
    {
      path: 'exemplos/notfound',
      component: PageNotFoundComponent,
      data: { breadcrumb: 'Página 404' },
    },
    {
      path: 'forbidden',
      component: ForbiddenComponent,
      data: { breadcrumb: 'Forbidden' },
    },
    {
      path: 'core',
      loadChildren: () =>
        import('./features/lib-core/lib-core.module').then(
          (m) => m.LibCoreModule
        ),
      canMatch: [BvAuthorizationGuard.canMatch],
      data: {
        roleIn: ['USER'],
        metatags: {},
        breadcrumb: 'Core',
      },
    },
  ]),
  {
    path: '**',
    component: PageNotFoundComponent,
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      preloadingStrategy: PreloadAllModules,
      initialNavigation: 'enabledBlocking',
      enableTracing: false,
    }),
  ],
  exports: [RouterModule],
  providers: [],
})
export class AppRoutingModule {}
