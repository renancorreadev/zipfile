import { Shell } from './shell.service';
import { ShellComponent } from './shell.component';
import { BvAuthenticationGuard } from '@arqt/ng15-framework';

describe('Shell', () => {
  const routes = [
    {
      path: 'dashboard',
      loadChildren: () =>
        import('../features/dashboard/dashboard.module').then(
          (m) => m.DashboardModule
        ),
    },
  ];

  it('childRoutes', () => {
    const resp = {
      path: '',
      component: ShellComponent,
      children: routes,
      canActivate: [BvAuthenticationGuard],
      data: { reuse: true },
    };

    expect(Shell.childRoutes(routes)).toEqual(resp);
  });
});
