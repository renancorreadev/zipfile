import { Component } from '@angular/core';

/**
 * Componente responsável pelo gerenciamento da barra de navegação
 */
@Component({
  selector: 'app-bv-navbar',
  templateUrl: './bv-navbar.component.html',
  styleUrls: ['./bv-navbar.component.scss'],
})
export class BvNavbarComponent {}
