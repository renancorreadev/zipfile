import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BvNavbarComponent } from './bv-navbar.component';

describe('BvNavbarComponent', () => {
  let component: BvNavbarComponent;
  let fixture: ComponentFixture<BvNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BvNavbarComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(BvNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
