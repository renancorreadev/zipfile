import { Routes, Route } from '@angular/router';
import { ShellComponent } from './shell.component';
import { BvAuthenticationGuard } from '@arqt/ng15-framework';

/**
 * Fornece métodos auxiliares para criar rotas
 */
export class Shell {
  /**
   * Cria rotas usando o componente de shell e autenticação
   * @param routes <Routes>
   * @return Retorna a nova rota usando shell como base
   */
  static childRoutes(routes: Routes): Route {
    return {
      path: '',
      component: ShellComponent,
      children: routes,
      canActivate: [BvAuthenticationGuard],
      // Reutilizar instância de ShellComponent ao navegar entre modos de exibição filho
      data: { reuse: true },
    };
  }
}
