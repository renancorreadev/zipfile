import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, PLATFORM_ID } from '@angular/core';
import { ShellComponent } from './shell.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';

describe('ShellComponent', () => {
  let comp: ShellComponent;
  let fixture: ComponentFixture<ShellComponent>;
  let mockRouter: any;
  let mockActivatedRoute: any;

  beforeEach(async () => {
    mockRouter = {
      navigate: jest.fn(),
    };
    mockActivatedRoute = {
      snapshot: {
        data: {
          redirectAfterRender: 'test-route',
        },
      },
    };

    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [ShellComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: PLATFORM_ID, useValue: 'browser' },
      ],
    });
    fixture = TestBed.createComponent(ShellComponent);
    comp = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('can load instance', () => {
    expect(comp).toBeTruthy();
  });

  it('should not navigate to redirectAfterRender is empty', () => {
    mockActivatedRoute.snapshot.data.redirectAfterRender = '';
    comp.ngOnInit();
    expect(mockRouter.navigate).not.toHaveBeenCalled();
  });
});
