import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ShellComponent } from './shell.component';
import { BvUiNavModule } from '@arqt/ng15-ui/nav';
import { SharedModule } from '@app/shared/shared.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  imports: [
    CommonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    BvUiNavModule,
    RouterModule,
    SharedModule,
  ],
  declarations: [ShellComponent],
})
export class ShellModule {}
