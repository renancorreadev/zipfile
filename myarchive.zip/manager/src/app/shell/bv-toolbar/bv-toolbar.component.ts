import {
  Component,
  OnInit,
  AfterViewInit,
  OnChanges,
  Renderer2,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from '@angular/core';
import { Router } from '@angular/router';
import { ConfigurationService, BvLoginService } from '@arqt/ng15-framework';
import { firstValueFrom } from 'rxjs';

/**
 * Componente responsável pelo gerenciamento da barra de ferramentas
 */
@Component({
  selector: 'bv-toolbar',
  templateUrl: './bv-toolbar.component.html',
  styleUrls: ['./bv-toolbar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BvToolbarComponent implements OnInit, AfterViewInit, OnChanges {
  /** @ignore */
  public logoImg: string = './assets/images/logo-banco-bv.svg';

  /**
   * Constructor
   *
   * @param renderer <Renderer2>
   * @param configurationService <ConfigurationService>
   * @param loginService <BvLoginService>
   * @param router <Router>
   * @param cdr <ChangeDetectorRef>
   */
  constructor(
    private renderer: Renderer2,
    private configurationService: ConfigurationService,
    private loginService: BvLoginService,
    private router: Router,
    private cdr: ChangeDetectorRef // private windowService: WindowService
  ) {}

  /**
   * Inicialização do componente
   */
  ngOnInit() {
    this.renderer.addClass(document.querySelector('.logo'), 'corporativo');
  }

  /**
   * Desabilita a detecção de alteração para esta view após sua inicialização
   */
  ngAfterViewInit() {
    this.cdr.detach();
  }

  /**
   * Evento que verifica se houve alguma alteração no componente
   */
  ngOnChanges() {
    this.cdr.detectChanges();
  }

  /**
   * Execução do logout
   */
  async logout() {
    await firstValueFrom(this.loginService.logout());
    this.router.navigate(['/login']);
  }
}
