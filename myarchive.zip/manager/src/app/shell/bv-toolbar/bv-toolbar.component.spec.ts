import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import {
  ConfigurationService,
  BvLoginService,
  BvRolesService,
  ConfigurationModel,
} from '@arqt/ng15-framework';
import { BvToolbarComponent } from './bv-toolbar.component';
import { spyOn } from 'jest-mock';
import { of } from 'rxjs';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('BvToolbarComponent', () => {
  let comp: BvToolbarComponent;
  let fixture: ComponentFixture<BvToolbarComponent>;

  let mockHttp: HttpClient;
  let mockConfiguration: { settings: Partial<ConfigurationModel> };
  let bvLoginService: BvLoginService;

  beforeEach(async () => {
    mockConfiguration = {
      settings: {
        apiBv: 'http://localhost:3200',
      },
    };

    const routerStub = {
      navigate: () => ({}),
    };

    await TestBed.configureTestingModule({
      declarations: [BvToolbarComponent],
      imports: [HttpClientTestingModule],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        BvRolesService,
        { provide: Router, useValue: routerStub },
        { provide: ConfigurationService, useValue: mockConfiguration },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(BvToolbarComponent);
    comp = fixture.componentInstance;

    mockHttp = TestBed.inject(HttpClient);
    bvLoginService = TestBed.inject(BvLoginService);
  });

  it('can load instance', () => {
    expect(comp).toBeTruthy();
  });

  describe('logout', () => {
    it('makes expected calls', async () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate');
      spyOn(bvLoginService, 'logout');
      spyOn(mockHttp, 'get').mockReturnValue(
        of(new HttpResponse({ status: 200, body: {} }))
      );
      comp.ngOnInit();
      comp.ngAfterViewInit();
      fixture.detectChanges();
      comp.ngOnChanges();
      expect(document.querySelector('.logo')).toBeTruthy();
      await comp.logout();
      expect(routerStub.navigate).toHaveBeenCalled();
      expect(bvLoginService.logout).toHaveBeenCalled();
    });
  });
});
