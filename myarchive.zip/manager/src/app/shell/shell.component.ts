import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

/**
 * Componente responsável pelas shell da aplicação
 */
@Component({
  selector: 'app-shell',
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss'],
})
export class ShellComponent implements OnInit {
  /**
   * Constructor
   * @param router <Router>
   * @param _route <ActivatedRoute>
   * @param _platformId <object>
   */
  constructor(
    private router: Router,
    private _route: ActivatedRoute,
    @Inject(PLATFORM_ID) private _platformId: object
  ) {}

  /**
   * Inicialização do componente
   */
  ngOnInit(): void {
    const { redirectAfterRender = '' } = this._route.snapshot.data;
    if (redirectAfterRender && isPlatformBrowser(this._platformId)) {
      this.router.navigate([redirectAfterRender]);
    }
  }
}
