import { Component, ViewEncapsulation } from '@angular/core';

/**
 * Componente responsável por inline-style
 */
@Component({
  selector: 'app-inline-style',
  template: '',
  styleUrls: ['./inline-style.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class InlineStyleComponent {}
