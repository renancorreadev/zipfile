import {
  Component,
  OnDestroy,
  OnInit,
  Renderer2,
  ViewEncapsulation,
  PLATFORM_ID,
  Inject,
} from '@angular/core';

import {
  FormControl,
  FormGroup,
  UntypedFormBuilder,
  Validators,
} from '@angular/forms';

import { Router } from '@angular/router';
import { BvLoginService, ConfigurationService } from '@arqt/ng15-framework';
import { BvNotificationService } from '@arqt/ng15-ui/notification';
import { take } from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';
import packageInfo from '@app/version';
import {AuthService} from "../services/auth/auth.service";


/**
 * Interface responsável pelas propriedades do formulário de login
 */
interface LoginForm {
  /** @ignore */
  login: FormControl<string | null>;
  /** @ignore */
  password: FormControl<string | null>;
}

/**
 * Componente responsável pelo gerenciamento da página de login da aplicação
 */
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LoginComponent implements OnInit, OnDestroy {
  /** @ignore */
  public frmLogin: FormGroup<LoginForm> = this.formBuilder.group({
    login: new FormControl<string | null>(null, Validators.required),
    password: new FormControl<string | null>(null, Validators.required),
  });

  /** @ignore */
  public logoImg: string = './assets/images/logo-banco-bv.svg';

  /** @ignore */
  public appVersion: string = packageInfo.version;
  /**
   * Constructor
   *
   * @param renderer <Renderer2>
   * @param router <Router>
   * @param formBuilder <UntypedFormBuilder>
   * @param notificationService <BvNotificationService>
   * @param loginService <BvLoginService>
   * @param configurationService <ConfigurationService>
   * @param _platformId <object>
   */
  constructor(
    private renderer: Renderer2,
    private router: Router,
    private formBuilder: UntypedFormBuilder,
    private notificationService: BvNotificationService,
    private loginService: BvLoginService,
    private authService: AuthService,
    public configurationService: ConfigurationService,
    @Inject(PLATFORM_ID) private _platformId: object
  ) {}

  /**
   * Inicialização do Componente
   */
  ngOnInit() {
    this.renderer.addClass(document.body, 'login');

    if (isPlatformBrowser(this._platformId)) {
      this.loginService.logout().pipe(take(1)).subscribe();
    }
  }

  /**
   * Finalização do Componente
   */
  ngOnDestroy() {
    this.renderer.removeClass(document.body, 'login');
  }

  /**
   * Se o form estiver válido realiza login, caso contrário, exibe erro
   */
  async login(): Promise<void> {
    const loginData = this.frmLogin.getRawValue();
    if (!this.frmLogin.valid || !loginData.login || !loginData.password) {
      this.frmLogin.markAllAsTouched();
      return;
    }

    try{
    const token = await this.authService.login(loginData.login, loginData.password);

    localStorage.setItem('token', token);

    this.router.navigate(['users']);
    }catch(error) {
        
      this.notificationService.warn(' Mensagem', 'Nao foi possivel realizar o login');
    };
  }


}
