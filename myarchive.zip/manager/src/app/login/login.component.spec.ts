import { CommonModule } from '@angular/common';
import { Renderer2, Type, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';

import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { Router } from '@angular/router';
import { BvLoginService, ConfigurationService } from '@arqt/ng15-framework';

import {
  BvNotificationModule,
  BvNotificationService,
} from '@arqt/ng15-ui/notification';
import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of, throwError } from 'rxjs';

import { spyOn } from 'jest-mock';
import { HttpErrorResponse } from '@angular/common/http';

import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let loginService: BvLoginService;
  let router: Router;
  let notificationService: BvNotificationService;
  let renderer2: Renderer2;

  const mockUser = {
    name: 'Rodolfo Zappa',
    roles: ['ADMIN'],
  };

  beforeEach(() => {
    const configurationService = {
      settings: {},
    };

    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        LoginRoutingModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        BvNotificationModule,
        HttpClientTestingModule,
      ],
      providers: [
        Renderer2,
        FormBuilder,
        Router,
        BvLoginService,
        BvNotificationService,
        { provide: ConfigurationService, useValue: configurationService },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    });

    fixture = TestBed.createComponent(LoginComponent);
    loginService = TestBed.inject(BvLoginService);
    notificationService = TestBed.inject(BvNotificationService);
    router = TestBed.inject(Router);

    component = fixture.componentInstance;
    renderer2 = fixture.componentRef.injector.get<Renderer2>(
      Renderer2 as Type<Renderer2>
    );

    spyOn(router, 'navigate').mockReturnValue(new Promise<boolean>(() => true));
    spyOn(console, 'error');
    spyOn(console, 'warn');
    spyOn(notificationService, 'error').mockImplementation(() => {
      return;
    });
    spyOn(notificationService, 'warn').mockImplementation(() => {
      return;
    });
    spyOn(notificationService, 'success').mockImplementation(() => {
      return;
    });

    component.ngOnInit();
    fixture.detectChanges();
  });

  afterEach(() => {
    component.ngOnDestroy();
    spyOn(console, 'error').mockRestore();
    spyOn(console, 'warn').mockRestore();
    spyOn(loginService, 'authenticate').mockRestore();
    spyOn(notificationService, 'error').mockRestore();
    spyOn(notificationService, 'warn').mockRestore();
    spyOn(notificationService, 'success').mockRestore();
    spyOn(router, 'navigate').mockRestore();
  });

  describe('Init', () => {
    it('can load instance', () => {
      spyOn(loginService, 'authenticate').mockReturnValue(of(mockUser));
      expect(component).toBeTruthy();
    });
  });

  describe('login', () => {
    it('should login correctly', () => {
      spyOn(loginService, 'authenticate').mockReturnValue(of(mockUser));
      component.frmLogin.setValue({
        login: 'login',
        password: 'password',
      });
      component.login();
      expect(loginService.authenticate).toHaveBeenCalledWith(
        'login',
        'password'
      );
      expect(router.navigate).toHaveBeenCalledWith(['dashboard']);
    });

    it('should not login (Error)', () => {
      spyOn(loginService, 'authenticate').mockReturnValue(
        throwError(() => new Error('Erro ao efetuar Login'))
      );

      component.frmLogin.setValue({
        login: null,
        password: null,
      });

      fixture.detectChanges();
      component.login();

      // não pode disparar auth request com form inválido
      expect(loginService.authenticate).not.toHaveBeenCalled();

      component.frmLogin.setValue({
        login: 'login',
        password: 'password',
      });
      fixture.detectChanges();
      component.login();

      expect(loginService.authenticate).toHaveBeenCalledWith(
        'login',
        'password'
      );

      expect(notificationService.warn).toHaveBeenCalledWith(
        'Erro ao efetuar Login',
        'Fechar',
        5000
      );
    });
  });

  it('should not login (HttpErrorResponse)', () => {
    spyOn(loginService, 'authenticate').mockReturnValue(
      throwError(
        () =>
          new HttpErrorResponse({
            status: 503,
            statusText: 'Erro desconhecido',
          })
      )
    );

    component.frmLogin.setValue({
      login: null,
      password: null,
    });

    fixture.detectChanges();
    component.login();

    // não pode disparar auth request com form inválido
    expect(loginService.authenticate).not.toHaveBeenCalled();

    component.frmLogin.setValue({
      login: 'login',
      password: 'password',
    });
    fixture.detectChanges();
    component.login();

    expect(loginService.authenticate).toHaveBeenCalledWith('login', 'password');
    expect(notificationService.warn).toHaveBeenCalledWith(
      'Erro desconhecido',
      'Fechar',
      5000
    );
  });

  describe('OnDestroy', () => {
    it('should destroy with all components initialized', () => {
      spyOn(loginService, 'authenticate').mockReturnValue(of(mockUser));

      component.frmLogin.setValue({
        login: 'login',
        password: 'password',
      });

      component.login();
      fixture.detectChanges();

      const renderer2Spy = spyOn(renderer2, 'removeClass');

      component.ngOnDestroy();
      fixture.detectChanges();
      expect(renderer2Spy).toHaveBeenCalledWith(document.body, 'login');
    });
  });
});
