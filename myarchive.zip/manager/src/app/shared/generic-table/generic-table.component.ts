import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-generic-table',
  templateUrl: './generic-table.component.html',
  styleUrls: ['./generic-table.component.scss'],
})
export class GenericTableComponent implements OnChanges {
  @Input() tableData: any;
  @Input() tableHeaders: any;

  @Output() rowAction: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild(MatTable, {static: true}) table?: MatTable<any>;
  @ViewChild(MatSort, {static: true}) sort?: MatSort;
  @ViewChild(MatPaginator, {static: false}) pagging?: MatPaginator;

  objectKeys = Object.keys;
  dataSource: MatTableDataSource<any>;
  pageIndex = 0;
  pageSize = 10;
  length = 0;
  pageSizeOptions: number[] = [5, 10, 25, 100];


  constructor() {
    this.dataSource = new MatTableDataSource()
  }

/**
 

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource(this.tableData);
    this.length = this.tableData.length;
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.pagging;
  }
 */

  ngOnChanges(): void {
    this.dataSource.data = this.tableData || [];
    this.length = this.tableData.length || 0;
    this.dataSource.sort = this.sort || null;
    this.dataSource.paginator = this.pagging || null;
  }

  handlePageEvent(event: PageEvent): void {
    this.length = event.length;
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex;
  }

  rowClicked(row: any) {
    this.rowAction.emit(row);
  }
}
