import { Directive, ElementRef } from '@angular/core';

/**
 * Diretiva responsável pelo gerenciamento de highlight
 */
@Directive({
  selector: '[appHighlight]',
})
export class HighlightDirective {
  /**
   * Constructor
   * @param el <ElementRef>
   */
  constructor(el: ElementRef) {
    el.nativeElement.style.backgroundColor = 'yellow';
  }
}
