import { Directive, ViewContainerRef, TemplateRef, Input } from '@angular/core';
/**
 * Diretiva responsável pelo gerenciamento de visibilidade
 */
@Directive({
  selector: '[appHasContentAccess]',
})
export class HasContentAccessDirective {
  /** @ignore */
  private hasView = false;

  /**
   * Constructor
   * @param viewContainer <ViewContainerRef>
   * @param templateRef <TemplateRef>
   */
  constructor(
    private viewContainer: ViewContainerRef,
    private templateRef: TemplateRef<HasContentAccessDirective>
  ) {}

  /**
   * Permite a visibilidade de conteúdo
   */
  @Input() set appHasContentAccess(login: string) {
    if (/^[P-p]\d+(\.)\d+$/.test(login) && !this.hasView) {
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.hasView = true;
    } else {
      this.viewContainer.clear();
      this.hasView = false;
    }
  }
}
