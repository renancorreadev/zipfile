import { HighlightDirective } from './highlight.directive';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

@Component({
  template: `<input
    type="text"
    appHighlight
  />`,
})
export class TestFormErrorsHighlightComponent {}

describe('HighlightDirective', () => {
  let fixture: ComponentFixture<TestFormErrorsHighlightComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestFormErrorsHighlightComponent, HighlightDirective],
    });
    fixture = TestBed.createComponent(TestFormErrorsHighlightComponent);
    inputEl = fixture.debugElement.query(By.css('input'));
  });

  it('Should have yellow background', () => {
    expect(inputEl.nativeElement.style.backgroundColor).toBe('yellow');
  });
});
