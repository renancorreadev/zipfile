import { HasContentAccessDirective } from './has-content-access.directive';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';

@Component({ selector: 'app-test-cmp', template: '' })
export class TestComponent {
  public login = 'P43.1';

  setLogin(_login: string) {
    this.login = _login;
  }
}

describe('HasContentAccessDirective', () => {
  let fixture: ComponentFixture<TestComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, HasContentAccessDirective],
      imports: [CommonModule],
    });
  });

  it('should not be rendered when login is valid', () => {
    const template =
      '<div *appHasContentAccess="login" class="success">Conteúdo exclusivo para Login Válido!</div>';

    fixture = createTestComponent(template);
    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.css('.success')).length).toEqual(1);
    expect(fixture.nativeElement.querySelector('div').textContent).toEqual(
      'Conteúdo exclusivo para Login Válido!'
    );
  });

  it('should be rendered when login is invalid', () => {
    const template =
      '<div *appHasContentAccess="login" class="success">Conteúdo exclusivo para Login Válido!</div>';

    fixture = createTestComponent(template);
    fixture.componentInstance.login = 'ABC';
    fixture.detectChanges();
    const query = fixture.debugElement.queryAll(By.css('.success'));
    expect(query.length).toEqual(0);
  });
});

function createTestComponent(
  template: string
): ComponentFixture<TestComponent> {
  return TestBed.overrideComponent(TestComponent, {
    set: { template: template },
  }).createComponent(TestComponent);
}
