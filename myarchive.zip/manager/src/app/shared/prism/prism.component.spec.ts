import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrismComponent } from './prism.component';
import { SharedModule } from '../shared.module';

describe('PrismComponent', () => {
  let component: PrismComponent;
  let fixture: ComponentFixture<PrismComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: [],
      providers: [],
    }).compileComponents();

    fixture = TestBed.createComponent(PrismComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    // h1 = fixture.nativeElement.querySelector('<pre>');
  });

  it('should create', () => {
    component.ngAfterViewInit();
    expect(component).toBeDefined();
    // expect(h1.textContent).toContain(component.);
  });
});
