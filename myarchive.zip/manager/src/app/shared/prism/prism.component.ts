import {
  Component,
  Input,
  Renderer2,
  ElementRef,
  AfterViewInit,
  PLATFORM_ID,
  Inject,
} from '@angular/core';

import { isPlatformBrowser } from '@angular/common';
import Prism from 'prismjs';

/**
 * Componente responsável pelo gerenciamento de Prism
 */
@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'prism-block',
  template: ``,
})
export class PrismComponent implements AfterViewInit {
  /**
   * Constructor
   *
   * @param _renderer <Renderer2>
   * @param _el <ElementRef>
   * @param _platformId <object>
   */
  constructor(
    private _renderer: Renderer2,
    private _el: ElementRef,
    @Inject(PLATFORM_ID) private _platformId: object
  ) {
    this.nativeElement = _el.nativeElement;
  }

  /** @ignore */
  @Input() code?: string;
  /** @ignore */
  @Input() language?: string;
  /** @ignore */
  private preNode?: Node;
  /** @ignore */
  private codeNode?: Node;
  /** @ignore */
  private nativeElement: Node;

  /**
   * Retorno de chamado após a criação do componente
   */
  ngAfterViewInit() {
    this.preNode = this._renderer.createElement('pre');
    this.codeNode = this._renderer.createElement('code');
    this._renderer.addClass(this.codeNode, 'language-' + this.language);
    this._renderer.appendChild(this.nativeElement, this.preNode);
    this._renderer.appendChild(this.preNode, this.codeNode);

    if (this.code && this.codeNode) {
      this.codeNode.textContent = this.code;
    }

    if (isPlatformBrowser(this._platformId) && this.codeNode) {
      Prism.highlightElement(this.codeNode as Element);
    }
  }
}
