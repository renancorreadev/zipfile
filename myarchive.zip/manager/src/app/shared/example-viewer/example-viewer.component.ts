import { Component, Input } from '@angular/core';

/**
 * Componente responsável pelo gerenciamento de Viewer
 */
@Component({
  selector: 'app-example-viewer',
  templateUrl: './example-viewer.component.html',
  styleUrls: ['./example-viewer.component.scss'],
})
export class ExampleViewerComponent {
  /** @ignore */
  @Input() title?: string;
  /** @ignore */
  public toogleSource = false;

  /**
   * Verifica a variável toogle
   */
  public toogle() {
    this.toogleSource = !this.toogleSource;
  }
}
