import { NgModule } from '@angular/core';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { AppComponent } from './app.component';
import { AppModule } from './app.module';
import { InlineStyleModule } from './shell/inline-style/inline-style.module';
import { InlineStyleComponent } from './shell/inline-style/inline-style.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  bootstrap: [AppComponent, InlineStyleComponent],
  imports: [
    AppModule,
    InlineStyleModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
    }),
    NoopAnimationsModule,
  ],
  providers: [{ provide: 'ORIGIN_URL', useValue: location.origin }],
})
export class AppBrowserModule {}
