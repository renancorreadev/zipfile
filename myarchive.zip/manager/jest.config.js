const defaultLocalConfig = {
  moduleNameMapper: {
    '^@app/(.*)': ['<rootDir>/src/app/$1'],
  },
};

let localConfig;

const fs = require('fs');
const localFile = './jest-local.config.js';

if (fs.existsSync(localFile)) {
  localConfig = require(localFile);
}

const importedConfig = localConfig ?? defaultLocalConfig;

module.exports = {
  ...importedConfig,
  roots: ['<rootDir>/src', '<rootDir>/libs'],
  collectCoverageFrom: [
    'src/app/**/*.ts',
    'libs/**/*.ts',
    '!libs/bff/api-client/**/*.ts',
    '!src/*.ts',
    '!**/index.ts',
    '!src/environments/**',
    '!src/**/*.{module,interface,model,resolver,dto,cy}.ts',
  ],
  setupFilesAfterEnv: ['<rootDir>/setup-jest.ts'],
  preset: 'jest-preset-angular',
  globalSetup: 'jest-preset-angular/global-setup',
  moduleDirectories: ['node_modules'],
  moduleFileExtensions: ['ts', 'js', 'html'],
  transformIgnorePatterns: ['node_modules/(?!.*.mjs$)'],
  transform: {
    '^.+\\.(ts|js|html|svg)$': [
      'jest-preset-angular',
      {
        stringifyContentPathRegex: '\\.(html|svg)$',
        isolatedModules: true,
      },
    ],
  },
  testResultsProcessor: 'jest-sonar-reporter',
};
