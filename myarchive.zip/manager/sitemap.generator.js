'use strict';
exports.__esModule = true;
var static_paths_1 = require('./universal/static.paths');
var cryptoRandomString = require('crypto-random-string');
var glob_1 = require('glob');
var fs = require('fs');
var Sitemap = /** @class */ (function () {
  function Sitemap() {
    this.url_list = static_paths_1.ROUTES; // Define as rotas importadas do universal prerender
    this.root_dir = './src/assets/sitemap-'; // Define o caminho do sitemap sem a hash
  }
  Object.defineProperty(Sitemap.prototype, 'root', {
    set: function (root) {
      // regex para validar a URL
      var exp =
        /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,4}\b([-a-zA-Z0-9@:]*)/g;
      var regex = new RegExp(exp);
      if (root !== undefined && root.match(regex)) {
        this.root_path =
          root.substring(root.length - 1, root.length) === '/'
            ? root.substring(0, root.length - 1)
            : root;
        console.log("Hostname definido para '" + this.root_path + "'");
      } else {
        this.removeTempFiles();
        throw new Error('Hostname inválido! e.g.: npm run sitemap <hostname>');
      }
    },
    enumerable: true,
    configurable: true,
  });
  Sitemap.prototype.generate = function () {
    var _this = this;
    this.xml = '<?xml version="1.0" encoding="UTF-8"?>';
    this.xml +=
      '\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    this.url_list.forEach(function (uri) {
      _this.xml += '\n  <url>';
      _this.xml +=
        '\n    <loc>' + _this.root_path + (uri === '/' ? '' : uri) + '</loc>';
      _this.xml += '\n  </url>';
    });
    this.xml += '\n</urlset>';
  };
  Sitemap.prototype.create = function () {
    var _this = this;
    glob_1.glob(this.root_dir + '*', function (err, files) {
      if (files.length > 1) {
        _this.removeTempFiles();
        throw new Error(
          "Mais de uma pasta do sitemap existe, 'there can be only one!'"
        );
      }
      if (files.length === 0) {
        _this.dir = '' + _this.root_dir + cryptoRandomString({ length: 6 }); // Gera um nome de pasta com uma hash no final
        fs.mkdirSync(_this.dir);
      } else if (files.length === 1) {
        _this.dir = files[0]; // Pega o nome da pasta já existente
        console.log(
          'J\u00E1 existe uma pasta do sitemap, utilizando: ' + _this.dir
        );
      }
      console.log("Gerando sitemap em '" + _this.dir + "'...");
      _this.generate();
      var path = _this.dir + '/sitemap.xml';
      var stream = fs.createWriteStream(path); // Cria o arquivo sitemap.xml
      stream.write(_this.xml); // Escreve o xml no sitemap
      stream.end();
      console.log(
        '\x1b[32m%s\x1b[0m',
        "Sitemap gerado com sucesso em '" + path + "'"
      );
      _this.removeTempFiles();
      console.log(
        '\x1b[36m%s\x1b[0m',
        '\n==========================================================================\n\n'
      );
      console.log(
        '\x1b[36m%s\x1b[0m',
        'O endere\u00E7o do sitemap em PRD ap\u00F3s o deploy deve ser:'
      );
      console.log(
        '\x1b[36m\x1b[1m%s\x1b[0m',
        '' + _this.root_path + path.substring(5, path.length)
      );
      console.log(
        '\x1b[36m%s\x1b[0m',
        'O sitemap deve ser informado diretamenta pelo Google Search Console'
      );
      console.log(
        '\x1b[36m%s\x1b[0m',
        '\n\n==========================================================================\n'
      );
    });
  };
  Sitemap.prototype.removeTempFiles = function () {
    console.log('Removendo arquivos temporários...');
    try {
      fs.unlinkSync('./universal/static.paths.js');
      console.log('Arquivos temporários removidos!');
    } catch (er) {
      console.error(er);
    }
  };
  return Sitemap;
})();
var sitemap = new Sitemap();
sitemap.root = process.argv[2];
sitemap.generate();
sitemap.create();
