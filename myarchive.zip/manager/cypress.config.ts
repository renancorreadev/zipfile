import { defineConfig } from 'cypress';
import mergeReports from 'cypress-sonarqube-reporter/mergeReports';

export default defineConfig({
  reporter: 'cypress-sonarqube-reporter',
  reporterOptions: {
    mergeOutputDir: './',
    mergeFileName: 'e2e-report.xml',
  },

  video: false,

  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
      on('after:run', (results) => {
        return mergeReports(results, config);
      });
    },
    experimentalRunAllSpecs: true,
    experimentalMemoryManagement: true,
  },

  component: {
    devServer: {
      framework: 'angular',
      bundler: 'webpack',
      options: {
        projectConfig: {
          root: './',
          sourceRoot: 'src',
          buildOptions: {
            outputPath: 'dist/browser',
            index: 'src/index.html',
            main: 'src/main.browser.ts',
            polyfills: ['zone.js'],
            tsConfig: 'src/tsconfig.app.json',
            inlineStyleLanguage: 'scss',
            assets: [
              'src/favicon.ico',
              'src/assets',
              'src/manifest.json',
              'src/robots.txt',
              {
                glob: '**/*',
                input:
                  './node_modules/foundation-ui/dist-stencil/foundation-ui/assets/fonts',
                output: './assets/fonts',
              },
              {
                glob: '**/*',
                input:
                  'node_modules/foundation-ui/dist-stencil/foundation-ui/assets/images',
                output: './assets/images',
              },
            ],
            styles: [
              'src/styles.scss',
              './node_modules/foundation-ui/dist-stencil/foundation-ui/foundation-ui.css',
            ],
            stylePreprocessorOptions: {
              includePaths: ['./node_modules'],
            },
            scripts: [],
            buildOptimizer: false,
            optimization: false,
            vendorChunk: true,
            extractLicenses: false,
            sourceMap: {
              scripts: true,
              vendor: true,
              styles: true,
            },
            namedChunks: true,
          },
        },
      },
    },
    specPattern: '**/*.cy.ts',
  },
});
