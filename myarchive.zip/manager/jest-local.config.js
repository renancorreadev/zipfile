module.exports = {
  moduleNameMapper: {
    '^@app/version': ['<rootDir>/package.json'],
    '^@app/(.*)': ['<rootDir>/src/app/$1'],
    '@bff/api-client': ['<rootDir>/libs/bff/api-client/src/public-api.ts'],
  },
};
