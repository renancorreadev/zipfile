const { engines, dependencies, devDependencies } = require('./package.json');
const { writeFileSync } = require('fs');

const clearVersionRegex = /^[~^><=]{1,2}/;
const clearVersion = (version) => {
  return version.replace(clearVersionRegex, '');
};

/**
 * Variável com os dados das versões utilizadas
 */
const packages = [
  { tech: 'Angular', version: clearVersion(devDependencies['@angular/cli']) },
  { tech: 'Node', version: clearVersion(engines.node) },
  { tech: 'Npm', version: clearVersion(engines.npm) },
  { tech: 'Typescript', version: clearVersion(devDependencies.typescript) },
  { tech: 'ESLint', version: clearVersion(devDependencies.eslint) },
  //{ tech: 'Codelyzer', version: clearVersion(devDependencies.codelyzer) },
  { tech: 'RxJS', version: clearVersion(dependencies.rxjs) },
]
  .map(({ tech, version }) => `{ tech: '${tech}', version: '${version}' }`)
  .join(',\n  ');

const content = `/**
 * Model para definição de dados de componentes de tecnologia
 */
export interface TechItemModel {
  /** @ignore */
  tech: string;
  /** @ignore */
  version: string;
}

/**
 * Variável com os dados das versões utilizadas
 */
export const packages: TechItemModel[] = [
  ${packages},
];
`;

return writeFileSync('./src/app/app.versions.ts', content);
