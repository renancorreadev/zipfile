<p align="center">
    <img alt="Banco BV" src="https://intranet.bvnet.bv/Style%20Library/Iteris.BV.Intranet/images/logo-bv.png" width="300px">
</p>

<p align="center">
    <img alt="WSL" src="https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black">&nbsp;&nbsp;&nbsp;
    <img alt="Docker" src="https://img.shields.io/badge/Docker-007ACC?style=for-the-badge&logo=docker&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Angular" src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="TypeScript" src="https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="HTML" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="SCSS" src="https://img.shields.io/badge/Sass-CC6699?style=for-the-badge&logo=sass&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Bootstrap" src="https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Node" src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="NPM" src="https://img.shields.io/badge/NPM-gray?style=for-the-badge&logo=npm">&nbsp;&nbsp;&nbsp;
    <img alt="Jest" src="https://img.shields.io/badge/Jest-orange?style=for-the-badge&logo=Jest&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Cypress" src="https://img.shields.io/badge/cypress-43853D?style=for-the-badge&logo=cypress">&nbsp;&nbsp;&nbsp;
    <img alt="ESLint" src="https://img.shields.io/badge/eslint-3A33D1?style=for-the-badge&logo=eslint&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Prettier" src="https://img.shields.io/badge/prettier-1A2C34?style=for-the-badge&logo=prettier&logoColor=F7BA3E">&nbsp;&nbsp;&nbsp;
    <img alt="Editor" src="https://img.shields.io/badge/editorconfig-gray?style=for-the-badge&logo=editorconfig&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Git" src="https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Json" src="https://img.shields.io/badge/Json-gray?style=for-the-badge&logo=json&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Jenkins" src="https://img.shields.io/badge/jenkins-D24939?style=for-the-badge&logo=jenkins&logoColor=white">&nbsp;&nbsp;&nbsp;
    <img alt="Sonar" src="https://img.shields.io/badge/Sonar-CB2029?style=for-the-badge&logo=sonar&logoColor=white">
    <br>
    <br>
    <br>
    <img alt="Release" src="https://img.shields.io/badge/ÚLTIMA_RELEASE%3A_DEZEMBRO%2F2023-V_0.17.0-green">
</p>
<br>
<br>

# 📇 Sumário

- [Aplicação de Referência](#custom-id-1)
- [Configurações](#custom-id-2)
- [Ambiente Local](#custom-id-3)
- [Como Utilizar a Aplicação de Referência](#custom-id-4)
- [Publicação](#custom-id-5)
- [Compodoc](#custom-id-6)
- [Testes Unitários](#custom-id-7)
- [Verificação das Regras do ESLint](#custom-id-8)
- [Testes E2E](#custom-id-9)
- [Finazalição](#custom-id-10)
  <br>
  <br>

# 🖥️ Aplicação de Referência <a name="custom-id-1" id="custom-id-1"></a>

Esse projeto como propósito demonstrar o uso e funcionamento dos componentes `@arqt/ng15-framework`, `@arqt/ng15-ui` e `@arqt-refe/ng15-biblioteca`. Portanto, consequentemente, dependências como `@angular/animations`, `@angular/material` e `foundation-ui` estarão presentes no conteúdo do `package.json`. Confira a documentação vigente no [Confluence](https://confluence.bvnet.bv/pages/viewpage.action?pageId=185196866).

Esses pacotes têm a finalidade, como por exemplo, administrar referências:

- Chamadas de integração de APIs;
- Tratamento de logs e erros;
- Máscaras para formatar dados sensíveis;
- Validações de dados e campos;
- Permissões e credenciais;
- Padrões visuais;
- CRUD para simulação;
- Login e logout.

Além disso, a aplicação disponibiliza ambientes de navegação para exemplificar as diretrizes e conteúdos:

- Dashboard;
- Exemplos:

  - Clientes;
  - MFE Lib;
  - Página 404;
  - Acesso negado.

- Core:

  - Configuração;
  - Logs e erros;
  - Armazenamento.

- Segurança:

  - Diretrizes;
  - Criptografia.

- PWA:
  - Acesso a câmera;
  - Notificações.

É possível verificar o desempenho da aplicação pelos ambientes DES e UAT acessando o [link](https://ng15-bvlb-base-wallet-manager-app.appuat.bvnet.bv/dashboard).
<br>
<br>

# ⚙️ Configurações <a name="custom-id-2" id="custom-id-2"></a>

Com o objetivo de centralizar as configurações da aplicação e facilitar o gerenciamento e manutenção dos critérios estabelecidos, deve-se respeitar e manter o padrão de organização e arquitetura.
<br>

## Ambiente Local <a name="custom-id-3" id="custom-id-3"></a>

Em caso de utilização do Windows, tenha instalada e configurada a ferramente WSL for Docker 2.0. Veja os detalhes na documentação no [Confluence](https://confluence.bvnet.bv/display/ARQUI/Windows+com+WSL).

Posteriormente, na sua pasta `root`, contida no subsistema Linux, crie um espaço de trabalho referente aos projetos Angular 15. Veja o exemplo de scripts por meio do terminal WSL:

```
[root@suamaquina ~]# cd git/Angular-15

[root@suamaquina Angular-15]# git clone https://bitbucket.bvnet.bv/scm/arqt-refe/ng15-bvlb-base-wallet-manager-app.git

[root@suamaquina Angular-15]# cd ng15-bvlb-base-wallet-manager-app

[root@suamaquina ng15-bvlb-base-wallet-manager-app]# code .
```

Para manusear esse projeto localmente, é necessário utilizar o Node.js 18. Você pode usar o nvm para selecionar as múltiplas instâncias do Node:

```
node -v
nvm use 18
```

É necessário o uso do repositório NPM (Nexus) do Banco para instalação de todas as bibliotecas de componentes:

```
npm config set registry https://nexus.bvnet.bv/repository/npm-group/
npm config set strict-ssl false
```

<br>

## Como Utilizar a Aplicação de Referência <a name="custom-id-4" id="custom-id-4"></a>

Para realizar a instalação de todos os pacotes dependentes, utilize o comando a seguir:

```
npm install
```

Inicie aplicação utilizando o comando abaixo. Localmente ela é fixada em `http://localhost:4200/`, `http://127.0.0.1:4200`, ao mesmo tempo que o servidor de mock (json-server) é executado ` http://127.0.0.1:3200`.

```
npm run start
```

<br>
<br>

# 🌐 Publicação <a name="custom-id-5" id="custom-id-5"></a>

O processo de publicação da referência inicia na execução dos testes unitários, testes e2e e o passo-a-passo do deploy. Além disso, outros scripts como o de lint, compodoc e cobertura dos testes podem ser verificados no arquivo `package.json`.
<br>

## Compodoc <a name="custom-id-6" id="custom-id-6"></a>

Compodoc é uma ferramenta de documentação para aplicações Angular. Ele gera uma documentação estática do seu aplicativo. Além disso, ajuda a fornecer uma documentação clara e útil de seus aplicativos, auxliando desenvolvedores de sua equipe ou visitantes a entenderem facilmente os recursos de seu aplicativo ou biblioteca.

```
- Instalação global: npm install -g @compodoc/
- Instalação local: ng add @compodoc/compodoc
```

Para gerar a documentação execute o comando a seguir:

```
npm run compodoc
```

## Testes Unitários (Jest) <a name="custom-id-7" id="custom-id-7"></a>

Os testes são executados a partir do comando:

```
npm run test
```

Para a geração de relatório de cobertura execute o comando:

```
npm run test:coverage
```

<br>

## Verificação das Regras do ESLint <a name="custom-id-8" id="custom-id-8"></a>

Utilize o comando a seguir:

```
npm run lint
```

## Testes E2E (Cypress) <a name="custom-id-9" id="custom-id-9"></a>

Execução interativa:

```
npm run cypress
```

Execução em batch:

```
npm run e2e
```

<br>

## Finalização <a name="custom-id-10" id="custom-id-10"></a>

Por fim, siga os seguintes passos. Se possível, verifique o diagrama de [esteira CI/CD para aplicações](https://confluence.bvnet.bv/display/ARQUI/Angular+15+-%3E+DevOps#Angular15%3EDevOps-EsteiradeCI/CDparaAplica%C3%A7%C3%B5es).

- Publicação da branch
- Code review
- Processos de CI/CD
- Abertura de PR
- Processos de CI/CD
- Geração de release
- Publicação da nova versão
- Atualização da documentação
