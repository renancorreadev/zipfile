import CryptoJS from 'crypto-js';
import { existsSync, readFileSync, unlinkSync, writeFileSync } from 'fs';
import { join } from 'path';
import { environment } from '../src/environments/environment';
import { SitemapGenerator } from './sitemap.generator';

const ATUAL_FOLDER = join(process.cwd(), 'src/assets');
const ORIGIN_FILE = join(ATUAL_FOLDER, 'env.vars.json');

if (!existsSync(ORIGIN_FILE)) {
  console.log('Arquivo de variáveis de ambiente não encontrado.');
} else {
  const originalFile = readFileSync(ORIGIN_FILE, 'utf-8');

  if (!environment.projectName) {
    throw new Error('Project Name not defined');
  }

  const projKey = environment.projectName.substring(0, 16);
  console.log('projKey', projKey);
  const contentCrypto = encryptUsingAES256(originalFile, projKey);

  // Gera o sitemap
  const listFile = JSON.parse(originalFile);
  const sitemap = new SitemapGenerator();
  sitemap.hostname = listFile.PRD.sitemap
    ? listFile.PRD.sitemap.hostname || ''
    : '';
  sitemap.sitemapDir = listFile.PRD.sitemap
    ? listFile.PRD.sitemap.folder || ''
    : '';
  sitemap.create();

  if (existsSync(join(ATUAL_FOLDER, 'list.txt'))) {
    unlinkSync(join(ATUAL_FOLDER, 'list.txt'));
  }
  writeFileSync(join(ATUAL_FOLDER, 'list.txt'), contentCrypto, 'utf-8');
  unlinkSync(ORIGIN_FILE);
  console.log('Variáveis de ambiente gerado com sucesso');
}

function encryptUsingAES256(content: string, _projKey: string) {
  const _key = CryptoJS.enc.Utf8.parse(_projKey);
  const _iv = CryptoJS.enc.Utf8.parse(_projKey);
  const encrypted = CryptoJS.AES.encrypt(content.toString(), _key, {
    keySize: 16,
    iv: _iv,
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7,
  });
  return encrypted.toString();
}
