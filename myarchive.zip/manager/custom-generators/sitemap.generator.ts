import { ROUTES } from './static.paths';
import cryptoRandomString from 'crypto-random-string';
import * as fs from 'fs';
// import { glob } from 'glob';
// import * as rimraf from 'rimraf';

export class SitemapGenerator {
  private _hostname?: string;
  private _sitemapDir: string = '';
  private xml?: string;
  private root_dir: string;
  private url_list: string[] = ROUTES; // Importa as rotas do universal prerender

  constructor() {
    this.root_dir = './src/assets/'; // Define o caminho onde o sitemap será gerado
    this.sitemapDir = ''; // O nome da pasta do sitemap
  }

  /**
   * Define o nome da pasta onde o sitemap será gerado.
   * A pasta sempre será gerada em /src/assets, se nenhum nome for setado será utilizado o nome padrão com uma hash aleatória.
   * E.g.: /src/assets/sitemap-43f3k7
   */
  set sitemapDir(dir: string) {
    this._sitemapDir = dir
      ? dir
      : 'sitemap-' + cryptoRandomString({ length: 6 });
  }

  get sitemapDir(): string {
    return this._sitemapDir;
  }

  /**
   * Define o hostname para a aplicação em PRD.
   * E.g.: https://www.bv.com.br
   */
  set hostname(root: string | undefined) {
    // regex para validar a URL
    const exp =
      /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,4}\b([-a-zA-Z0-9@:]*)/g;
    const regex = new RegExp(exp);
    if (root && root !== '') {
      // Verifica se o hostname está setado
      if (root.match(regex)) {
        // Verifica se o hostname é válido
        this._hostname = root.endsWith('/')
          ? root.substring(0, root.length - 1)
          : root;
        console.log(`Hostname definido para '${this._hostname}'`);
      } else {
        throw new Error(
          'Hostname para sitemap inválido! e.g.: https://www.bv.com.br'
        );
      }
    }
  }

  get hostname(): string | undefined {
    return this._hostname;
  }

  /**
   * Gera o XML para ser gravado
   */
  private generateXml() {
    // Monta o XML a partir das rotas no arquivo /universal/static.paths.ts
    this.xml = '<?xml version="1.0" encoding="UTF-8"?>';
    this.xml +=
      '\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    this.url_list.forEach((uri) => {
      this.xml += '\n  <url>';
      this.xml +=
        '\n    <loc>' + this.hostname + (uri === '/' ? '' : uri) + '</loc>';
      this.xml += '\n  </url>';
    });
    this.xml += '\n</urlset>';
  }

  /**
   * Cria o sitemap com o hostname informado.
   */
  public create() {
    if (this.hostname) {
      const path = this.root_dir + this.sitemapDir;
      fs.mkdir(path, { recursive: true }, (er) => {
        // Cria o diretório
        if (!er || er.code === 'EEXIST') {
          this.generateXml();
          const fullPath = `${path}/sitemap.xml`;
          const stream = fs.createWriteStream(fullPath); // Cria o arquivo sitemap.xml
          stream.write(this.xml); // Escreve o xml do sitemap
          stream.end();
          console.log(`Sitemap gerado com sucesso em '${fullPath}'`);
          console.log(`O endereço do sitemap em PRD após o deploy deve ser:`);
          console.log(
            `${this.hostname}${fullPath.substring(5, fullPath.length)}`
          );
          console.log(
            'O sitemap deve ser disponibilizado diretamente pelo Google Search Console'
          );
        } else {
          console.log('Sitemap: ', er.code);
        }
      });
    } else {
      console.log(
        'Hostname para sitemap não foi definido, pulando etapa de geração do XML para sitemap'
      );
    }
  }
}
