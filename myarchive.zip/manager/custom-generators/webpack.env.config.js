const path = require('path');
const ngtools = require('@ngtools/webpack');
const AngularWebpackPlugin = ngtools.AngularWebpackPlugin;

module.exports = {
  optimization: {
    minimize: false,
  },
  mode: 'none',
  target: 'node',
  externals: [/(node_modules)/],
  entry: {
    envs: './custom-generators/generate-env.ts',
  },
  resolve: {
    extensions: ['.ts', '.js'],
    modules: ['node_modules'],
  },
  output: {
    path: path.join(__dirname, '../dist'),
    filename: '[name].js',
  },
  module: {
    rules: [
      {
        test: /\.[cm]?js$/,
        use: {
          loader: 'babel-loader',
          options: {
            cacheDirectory: true,
            compact: false,
            plugins: ['@angular/compiler-cli/linker/babel'],
          },
        },
      },
      {
        test: /\.ts$/,
        loader: '@ngtools/webpack',
      },
    ],
  },
  plugins: [
    new AngularWebpackPlugin({
      tsconfig: './custom-generators/tsconfig.json',
      jitMode: true,
    }),
  ],
};
