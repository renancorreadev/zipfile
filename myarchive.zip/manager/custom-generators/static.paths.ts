export const ROUTES = [
  '/' /* Caso Server Side Render, desabilitar rota inicial */,
  '/login',
  '/static/hot-site',
];
