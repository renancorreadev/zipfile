module.exports = (req, res, next) => {
  if (req.url === '/j_security_check') {
    res.header('Access-Control-Allow-Headers', 'Authorization, Refresh');
    res.header('Access-Control-Expose-Headers', 'Authorization, Refresh');
    res.header('Authorization', 'Bearer mockBearer');
    res.header('Refresh', '3e81541a-dcaa-4b8f-8f8e-e50c91ca4e7d');
    res.status(200).send();
  } else if (req.url === '/refreshToken') {
    res.send({
      bearer: 'mockBearer',
      refresh: 'mockRefresh',
    });
  } else {
    next();
  }
};
