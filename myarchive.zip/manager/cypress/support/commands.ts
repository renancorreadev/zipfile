/// <reference types="cypress" />

const baseUrl = 'http://localhost:3200';

const loggerUrl = {
  method: 'POST',
  url: `${baseUrl}/api-utils/logger`,
};

const logoutUrl = {
  method: 'GET',
  url: `${baseUrl}/api-security/logout`,
};

const meUrl = {
  method: 'GET',
  url: `${baseUrl}/api-security/me`,
};

const jSecurityCheckUrl = {
  method: 'POST',
  url: `${baseUrl}/j_security_check`,
};

/**
 * Preparo Inicial para testes
 */
Cypress.Commands.add('prepare', () => {
  /** logger */
  cy.intercept(loggerUrl, { statusCode: 200 });

  /** logout */
  cy.intercept(logoutUrl, { statusCode: 200, body: {} });
});

/**
 * Intercept Login Error
 */
Cypress.Commands.add('interceptLoginError', () => {
  /** me */
  cy.intercept(
    { ...meUrl, times: 1 },
    {
      statusCode: 401,
    }
  );

  /** j_security_check */
  cy.intercept(
    { ...jSecurityCheckUrl, times: 1 },
    {
      statusCode: 401,
    }
  );
});

/**
 * Intercept Login User
 */
Cypress.Commands.add('interceptLoginNormalUser', () => {
  /** j_security_check */
  cy.intercept(jSecurityCheckUrl, {
    statusCode: 200,
    body: {},
  });

  /** me */
  cy.intercept(meUrl, {
    statusCode: 200,
    body: {
      name: 'user',
      roles: ['FUNC', 'USER'],
    },
  });
});

/**
 * Intercept Login Admin
 */
Cypress.Commands.add('interceptLoginAdminUser', () => {
  /** j_security_check */
  cy.intercept(jSecurityCheckUrl, {
    statusCode: 200,
    body: {},
  });

  /** me */
  cy.intercept(meUrl, {
    statusCode: 200,
    body: {
      name: 'admin',
      roles: ['ESTAG', 'ADMIN', 'FUNC', 'USER'],
    },
  });
});

Cypress.Commands.add(
  'navigateTo',
  (firstLevel: string, secondLevel: string) => {
    cy.get(`${firstLevel} > .mat-list-item-content`).should('exist');
    cy.get(`${firstLevel} > .mat-list-item-content`).click();

    cy.get(`${secondLevel} > .mat-list-item-content`).should('be.visible');
    cy.get(`${secondLevel} > .mat-list-item-content`).click();
  }
);

// eslint-disable-next-line @typescript-eslint/no-namespace
declare namespace Cypress {
  interface Chainable {
    prepare(): Chainable<void>;
    interceptLoginError(): Chainable<void>;
    interceptLoginNormalUser(): Chainable<void>;
    interceptLoginAdminUser(): Chainable<void>;
    navigateTo(firstLevel: string, secondLevel: string): Chainable<void>;
  }
}
