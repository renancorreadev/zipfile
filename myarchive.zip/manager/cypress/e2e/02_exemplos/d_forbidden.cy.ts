describe('Página Acesso Negado', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
    cy.navigateTo('#exemplos', '#acessonegado');
  });

  it('Página Acesso Negado Should be Visible', () => {
    // navegou pra rota certa
    cy.location('pathname').should('eq', '/forbidden');

    // achou breadcrumb
    cy.get('.breadcrumb-item > .ng-star-inserted')
      .contains('Forbidden')
      .should('be.visible');

    // achou título
    cy.get('h2 > .hydrated')
      .contains('Restrição de Acesso')
      .should('be.visible');

    // achou card
    cy.get('.card > foundation-heading-text.hydrated')
      .contains('Acesso negado')
      .should('be.visible');
  });
});
