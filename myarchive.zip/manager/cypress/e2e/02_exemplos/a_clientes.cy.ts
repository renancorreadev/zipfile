describe('Clientes', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
    cy.navigateTo('#exemplos', '#clientes');
  });

  it('Clientes Should be Visible', () => {
    // navegou pra rota certa
    cy.location('pathname').should('eq', '/exemplos/clientes/lista');

    // achou breadcrumb
    cy.get('.breadcrumb-item > .ng-star-inserted')
      .contains('Lista')
      .should('be.visible');

    // achou título
    cy.get('.mat-h1 > .hydrated').contains('Clientes').should('be.visible');
  });

  it('Novo Cliente', () => {
    // clicar botão 'Novo Cliente'
    cy.contains('foundation-primary-button', 'Novo Cliente')
      .should('be.visible')
      .click();

    // clicar botão 'Lista Clientes'
    cy.contains('foundation-primary-button', 'Lista de Clientes')
      .should('be.visible')
      .click();

    // navegou pra rota certa
    cy.location('pathname').should('eq', '/exemplos/clientes/lista');

    // clicar botão 'Novo Cliente (de novo)'
    cy.contains('foundation-primary-button', 'Novo Cliente')
      .should('be.visible')
      .click();

    // navegou pra rota certa
    cy.location('pathname').should('eq', '/exemplos/clientes/cadastro');

    // botão que acionou rota deve ter sumido
    cy.contains('foundation-primary-button', 'Novo Cliente').should(
      'not.exist'
    );

    // botão salvar deve estar desabilitado
    cy.contains('foundation-primary-button', 'Salvar')
      .should('be.visible')
      .shadow()
      .find('button')
      .should('be.disabled');

    // achou breadcrumb
    cy.get('.active > .ng-star-inserted')
      .contains('Cadastro')
      .should('be.visible');

    // digita nome
    cy.contains('foundation-text-field', 'Nome')
      .find('input')
      .type('Cypress Test User');

    // digita nascimento
    cy.contains('foundation-text-field', 'Nascimento').type('24/05/1977');

    // seleciona estado civil
    cy.get('#estadoCivil')
      .click()
      .wait(150)
      .shadow()
      .find('button')
      .contains('Casado')
      .click();

    // digita cpf
    cy.contains('foundation-text-field', 'CPF')
      .find('input')
      .type('22694477003');

    // digita email
    cy.contains('foundation-text-field', 'E-mail')
      .find('input')
      .type('user@cypress.io');

    // seleciona sexo
    cy.contains('foundation-radio-button', 'Masculino').click();

    // clicar em salvar
    cy.contains('foundation-primary-button', 'Salvar')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();

    // navegou pra rota certa
    cy.location('pathname').should('eq', '/exemplos/clientes/lista');

    // clicar em editar
    cy.get('#row_2')
      .should('exist')
      .find('foundation-tooltip')
      .find('foundation-square-icon-button')
      .eq(0)
      .should('exist')
      .click();

    // verifica conteúdo de nome
    cy.contains('foundation-text-field', 'Nome')
      .find('input')
      .should('have.value', 'Cypress Test User')
      .clear()
      .type('New Cypress Test User');

    // clicar em salvar
    cy.contains('foundation-primary-button', 'Salvar')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();

    // clicar em excluir
    cy.get('#row_2')
      .should('exist')
      .find('foundation-tooltip')
      .find('foundation-square-icon-button')
      .eq(1)
      .should('exist')
      .click();

    // clicar em cancelar
    cy.contains('foundation-secondary-button', 'Cancelar')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();

    // confirma que linha 3 ainda existe
    cy.get('#row_2').should('exist');

    // clicar em excluir novamente
    cy.get('#row_2')
      .should('exist')
      .find('foundation-tooltip')
      .find('foundation-square-icon-button')
      .eq(1)
      .should('exist')
      .click();

    // clicar em excluir (confirmar)
    cy.contains('foundation-primary-button', 'Excluir')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();

    // confirma que linha 3 não existe
    cy.get('#row_2').should('not.exist');
  });
});
