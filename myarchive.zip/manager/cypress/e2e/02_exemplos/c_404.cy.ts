describe('Página 404', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
    cy.navigateTo('#exemplos', '#página404');
  });

  it('Página 404 Should be Visible', () => {
    // navegou pra rota certa
    cy.location('pathname').should('eq', '/exemplos/notfound');

    // achou breadcrumb
    cy.get('.breadcrumb-item > .ng-star-inserted')
      .contains('Página 404')
      .should('be.visible');

    // achou título
    cy.get('[variant-type="1"]').contains('Página 404').should('be.visible');

    // achou card
    cy.get('.card > foundation-heading-text.hydrated')
      .contains('Página não encontrada')
      .should('be.visible');
  });
});
