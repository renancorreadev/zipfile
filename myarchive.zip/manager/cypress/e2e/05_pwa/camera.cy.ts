describe('Câmera', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de camera', () => {
    //navega até a página camera
    cy.navigateTo('#pwa', '#câmera');

    //valida o path
    cy.location('pathname').should('eq', '/pwa/camera');
  });

  it('Deve encontrar o título Acesso à Câmera via API Web na página', () => {
    //navega até a página camera
    cy.navigateTo('#pwa', '#câmera');

    //valida se o título é visível
    cy.contains('Acesso à Câmera via API Web').should('be.visible');
  });

  it('Deve habilitar a camera ', () => {
    //navega até a página camera
    cy.navigateTo('#pwa', '#câmera');

    //clica no botão de habilitar a camera
    cy.contains('foundation-primary-button', 'Câmera')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();

    //valida se a tela da camera é aberta
    cy.get('video.col-12').should('not.be.null');
  });

  it('Deve realizar a captura de tela ', () => {
    //navega até a página camera
    cy.navigateTo('#pwa', '#câmera');

    //clica no botão de habilitar a camera
    cy.contains('foundation-primary-button', 'Câmera')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();

    //valida se a tela da camera é aberta
    cy.get('video.col-12').should('not.be.null');

    //clica no botão de captura imagem
    cy.contains('foundation-primary-button', 'Capturar')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();

    //clica no botão de baixar imagem
    cy.contains('foundation-primary-button', 'Download')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();
  });
});
