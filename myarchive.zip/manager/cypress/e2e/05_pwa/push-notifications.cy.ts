describe('Push notifications', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de PWA', () => {
    //navega até a página push-notifications
    cy.navigateTo('#pwa', '#pushnotifications');

    //valida o path
    cy.location('pathname').should('eq', '/pwa/push-notifications');
  });

  it('Deve encontrar o título Push notifications na página', () => {
    //navega até a página push-notifications
    cy.navigateTo('#pwa', '#pushnotifications');

    //valida o título da página
    cy.contains('Push Notifications').should('be.visible');
  });

  it('Deve clicar no botão <> e abrir modo desenvolvedor', () => {
    //navega até a página push-notifications
    cy.navigateTo('#pwa', '#pushnotifications');

    //clica no botão <>
    cy.get('.mat-button-wrapper > .mat-icon').click();

    //valida se as abas estão abertas
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });

  it('Deve clicar no botão', () => {
    //navega até a página push-notifications
    cy.navigateTo('#pwa', '#pushnotifications');

    //clica no botão de enviar notificação
    cy.contains('foundation-primary-button', 'Assinar')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();
  });
});
