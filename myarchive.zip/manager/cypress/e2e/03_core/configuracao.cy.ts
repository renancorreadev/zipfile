describe('Configuração', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de configuração', () => {
    //navega até a página configuração
    cy.navigateTo('#core', '#configuração');

    //valida se o path está correto
    cy.location('pathname').should('eq', '/core/config');
  });

  it('Deve encontrar o título Configuração na página', () => {
    //navega até a página configuração
    cy.navigateTo('#core', '#configuração');

    //valida se o título da página está visível
    cy.contains('Configuração').should('be.visible');
  });

  it('Deve clicar no botão <> e abrir modo desenvolvedor', () => {
    //navega até a página configuração
    cy.navigateTo('#core', '#configuração');

    //clica no botão <>
    cy.get('.d-flex > .mat-focus-indicator').click();

    //valida se as abas estão visíveis
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });
});
