describe('Erro', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de erros', () => {
    //navega até a página erro
    cy.navigateTo('#core', '#erro');

    //valida o path
    cy.location('pathname').should('eq', '/core/error-handling');
  });

  it('Deve encontrar o título Tratamento de erro na página', () => {
    //navega até a página erro
    cy.navigateTo('#core', '#erro');

    //valida se o título da página é visível
    cy.contains('Tratamento de Erro').should('be.visible');
  });

  it('Deve clicar no botão <> de erros de runtime e abrir modo desenvolvedor', () => {
    //navega até a página erro
    cy.navigateTo('#core', '#erro');

    //clica no botão <>
    cy.get(
      '[title="Erros de Runtime"] > .mat-card > .mat-card-title > .d-flex > .mat-focus-indicator'
    ).click();

    //valida se as abas são visíveis
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });

  it('Deve clicar no botão simular runtime e exibir mensagem de erro', () => {
    //navega até a página erro
    cy.navigateTo('#core', '#erro');

    //clica no botão de erros de runtime
    cy.contains('mat-card', 'Erros de Runtime')
      .find('foundation-primary-button')
      .click();

    //valida se a snack bar de erro é exibida
    cy.get('.mat-snack-bar-container').contains('Erro');
  });

  it('Deve clicar no botão <> de erros de api e abrir modo desenvolvedor', () => {
    //navega até a página erro
    cy.navigateTo('#core', '#erro');

    //clica no botão <>
    cy.get(
      '[title="Erros de API"] > .mat-card > .mat-card-title > .d-flex > .mat-focus-indicator'
    ).click();

    //valida se as abas são exibidas
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });

  it('Deve clicar no botão simular erros de API e exibir mensagem de undefined', () => {
    //navega até a página erro
    cy.navigateTo('#core', '#erro');

    //clica no botão erros de API
    cy.contains('mat-card', 'Erros de API')
      .find('foundation-primary-button')
      .click();

    //valida se a snack bar de undefined é exibida
    cy.get('.mat-snack-bar-container').contains('404 Not Found');
  });
});
