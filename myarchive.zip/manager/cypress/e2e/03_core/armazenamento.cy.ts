describe('Armazenamento', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de Armazenamento', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //valida se o path atual é correspondente
    cy.location('pathname').should('eq', '/core/storage');
  });

  it('Deve encontrar o título Tratamento de erro na página', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //valida se o titulo da página é visível
    cy.contains('Armazenamento Local').should('be.visible');
  });

  it('Deve clicar no botão <> da session e abrir modo desenvolvedor', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //clica no botão <>
    cy.get(
      '[title="Session"] > .mat-card > .mat-card-title > .d-flex > .mat-focus-indicator'
    ).click();

    //valida se as abas estão visíveis
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });

  it('Deve salvar texto do input no sessionStorage', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //digita a string a ser salva no sessionStorage
    cy.contains('mat-card', 'Session')
      .contains('foundation-text-field', 'Valor')
      .find('input')
      .type('sessionstorage');

    //salva a string no sessionStorage
    cy.contains('mat-card', 'Session')
      .contains('foundation-primary-button', 'Salvar')
      .click()
      .should(() => {
        expect(sessionStorage.getItem('Session_key')).to.eq('"sessionstorage"');
      });
  });

  it('Deve apagar a variável do input no sessionStorage', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //digita a string a ser salva no text-field
    cy.contains('mat-card', 'Session')
      .contains('foundation-text-field', 'Valor')
      .find('input')
      .type('sessionstorage');

    //salva uma string no sessionStorage
    cy.contains('mat-card', 'Session')
      .contains('foundation-primary-button', 'Salvar')
      .click()
      .should(() => {
        expect(sessionStorage.getItem('Session_key')).to.eq('"sessionstorage"');
      });

    //deleta a string do sessionStorage
    cy.contains('mat-card', 'Session')
      .contains('foundation-primary-button', 'Remover a Chave')
      .click()
      .should(() => {
        expect(sessionStorage.getItem('Session_key')).to.be.null;
      });
  });

  it('Deve clicar no botão <> do local e abrir modo desenvolvedor', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //seleciona o botão de <>
    cy.get(
      '[title="Local"] > .mat-card > .mat-card-title > .d-flex > .mat-focus-indicator'
    ).click();

    //valida se as abas estão visíveis
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });

  it('Deve salvar texto do input no localStorage', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //digita a string a ser salva no localStorage
    cy.contains('mat-card', 'Local')
      .contains('foundation-text-field', 'Valor')
      .find('input')
      .type('localstorage');

    //salva a string no localStorage
    cy.contains('mat-card', 'Local')
      .contains('foundation-primary-button', 'Salvar')
      .click()
      .should(() => {
        expect(localStorage.getItem('Local_key')).to.eq('"localstorage"');
      });
  });

  it('Deve apagar a variável do input no localStorage', () => {
    //navega até a página armazenamento
    cy.navigateTo('#core', '#armazenamento');

    //digita a string a ser salva no localStorage
    cy.contains('mat-card', 'Local')
      .contains('foundation-text-field', 'Valor')
      .find('input')
      .type('localstorage');

    //salva a string no localStorage
    cy.contains('mat-card', 'Local')
      .contains('foundation-primary-button', 'Salvar')
      .click()
      .should(() => {
        expect(localStorage.getItem('Local_key')).to.eq('"localstorage"');
      });

    //deleta a string do localStorage
    cy.contains('mat-card', 'Local')
      .contains('foundation-primary-button', 'Limpar')
      .click()
      .should(() => {
        expect(localStorage.getItem('Session_key')).to.be.null;
      });
  });
});
