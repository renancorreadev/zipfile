describe('Log', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de Logs', () => {
    //navega até a página log
    cy.navigateTo('#core', '#log');

    //valida se o path está correto
    cy.location('pathname').should('eq', '/core/log');
  });

  it('Deve encontrar o título Log na página', () => {
    //valida se o path está correto
    cy.navigateTo('#core', '#log');

    //valida se o título é visível
    cy.contains('Log').should('be.visible');
  });

  it('Deve clicar no botão <> e abrir modo desenvolvedor', () => {
    //navega até a página log
    cy.navigateTo('#core', '#log');

    //clica no botão <>
    cy.get(
      'body > app-root > app-shell > div > bv-sidenav > mat-sidenav-container > mat-sidenav-content > bv-scrollbar > div > div.bv-scrollbar-view > div.content-area > div > div > div:nth-child(2) > app-lib-core > app-log > div > div > app-example-viewer > mat-card > mat-card-title > div > button'
    ).click();

    //valida se as abas estão visíveis
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });

  it('Deve clicar no botão info e enviar log ', () => {
    //navega até a página log
    cy.navigateTo('#core', '#log');

    //intercepta as requisições
    cy.intercept('POST', 'http://localhost:3200/api-utils/logger').as(
      'postlog'
    );

    //clica no botão de info
    cy.contains('foundation-primary-button', 'Info').click();

    //valida o retorno da requisição
    cy.wait('@postlog').its('response.statusCode').should('be.oneOf', [200]);
  });

  it('Deve clicar no botão warning e enviar log ', () => {
    //navega até a página log
    cy.navigateTo('#core', '#log');

    //intercepta as requisições
    cy.intercept('POST', 'http://localhost:3200/api-utils/logger').as(
      'postlog'
    );

    //clica no botão de warning
    cy.contains('foundation-primary-button', 'Warning').click();

    //valida o retorno da requisição
    cy.wait('@postlog').its('response.statusCode').should('be.oneOf', [200]);
  });

  it('Deve clicar no botão error e enviar log ', () => {
    //navega até a página log
    cy.navigateTo('#core', '#log');

    //intercepta as requisições
    cy.intercept('POST', 'http://localhost:3200/api-utils/logger').as(
      'postlog'
    );

    //clica no botão de error
    cy.contains('foundation-primary-button', 'Error').click();

    //valida o retorno da requisição
    cy.wait('@postlog').its('response.statusCode').should('be.oneOf', [200]);
  });
});
