describe('Login, Dashboard e Logout', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginError();
    cy.visit('http://localhost:4200');
  });

  it('login error', () => {
    cy.get('#login').type('usuario');
    cy.get('#password').type('password');

    cy.get('.login_button').click();

    cy.contains('Fechar').should('be.visible');
    cy.contains('Fechar').click();
  });

  it('login succesfully', () => {
    cy.interceptLoginNormalUser();

    cy.contains('Arquitetura SPA').should('not.exist');
    cy.get('#login').type('admin');
    cy.get('#password').type('password');
    cy.get('.login_button').click();

    cy.get('.login_button').should('not.exist');
    cy.contains('Arquitetura SPA').should('be.visible');

    cy.get('.menu-box-exit').click();
    cy.get('.login_button').should('be.visible');
    cy.contains('Arquitetura SPA').should('not.exist');
  });
});
