describe('Criptografia', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de criptografia', () => {
    //navega até a página configuração
    cy.navigateTo('#segurança', '#criptografia');

    //valida o path
    cy.location('pathname').should('eq', '/seguranca/criptografia');
  });

  it('Deve encontrar o título Componente de criptografia na página', () => {
    //navega até a página configuração
    cy.navigateTo('#segurança', '#criptografia');

    //valida se o título é visível
    cy.contains('Componente de Criptografia').should('be.visible');
  });

  it('Deve clicar no botão <> do local e abrir modo desenvolvedor', () => {
    //navega até a página configuração
    cy.navigateTo('#segurança', '#criptografia');

    //clica no botão <>
    cy.get('.d-flex > .mat-focus-indicator').click();

    //valida se as abas são exibidas
    cy.contains('HTML').should('be.visible');
    cy.contains('Typescript').should('be.visible');
    cy.contains('SCSS').should('be.visible');
  });

  it('Deve criptografar texto', () => {
    //navega até a página configuração
    cy.navigateTo('#segurança', '#criptografia');

    //digita a mensagem a ser criptografada
    cy.contains(
      'foundation-text-field',
      'Insira um dado para ser criptografado'
    ).type('mensagem criptografada');

    //valida se o campo foi preenchido
    cy.contains('textarea', 'Dado criptografado').should('not.be.empty');
  });
});
