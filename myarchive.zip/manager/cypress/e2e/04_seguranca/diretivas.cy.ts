describe('Segurança usuario comum', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginNormalUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de segurança', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida o path
    cy.location('pathname').should('eq', '/seguranca/diretivas');
  });

  it('Deve encontrar o título Configuração na página', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida se o título é visível
    cy.contains('Diretivas de Segurança').should('be.visible');
  });

  it('Deve encontrar a mensagem O usuário logado tem role de FUNCIONARIO', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida se a mensagem de funcionário é visível
    cy.contains('mat-card', 'Exibir/Ocultar')
      .contains(
        'foundation-body-text',
        'O usuário logado tem role de FUNCIONÁRIO'
      )
      .should('be.visible');
  });

  it('Deve clicar no botão ver guia', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida se o botão para funcionários está habilitado
    cy.contains('foundation-primary-button', 'Ver Guia')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();
  });
});

describe('Segurança usuario Admin', () => {
  beforeEach(() => {
    cy.prepare();
    cy.interceptLoginAdminUser();
    cy.visit('http://localhost:4200');
  });

  it('Deve navegar até a página de segurança', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida o path
    cy.location('pathname').should('eq', '/seguranca/diretivas');
  });

  it('Deve encontrar o título Configuração na página', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida se o título é visível
    cy.contains('Diretivas de Segurança').should('be.visible');
  });

  it('Deve encontrar a mensagem O usuário logado tem role de ADMIN', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida se a mensagem de ADMIN é visível
    cy.contains('mat-card', 'Exibir/Ocultar')
      .contains('foundation-body-text', 'O usuário logado tem role de ADMIN')
      .should('be.visible');
  });

  it('Deve clicar no botão ver rendimentos', () => {
    //navega até a página diretivas
    cy.navigateTo('#segurança', '#diretivas');

    //valida se o botão de admin está habilitado
    cy.contains('foundation-primary-button', 'Ver Rendimentos')
      .shadow()
      .find('button')
      .should('be.enabled')
      .click();
  });
});
