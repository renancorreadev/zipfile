#!/usr/bin/env bash

#########################################
#  ENVIRONMENT VARS
#########################################
LIB_DIR="./libs/bff/api-client"
OUTPUT_DIR="${LIB_DIR}/src/lib"

API_YAML="${LIB_DIR}/bff-api.yaml"

#########################################
#  API BFF
#########################################
# test if file exists
if [[ -f ${API_YAML} ]]; then
  # test if dir exists
  if [[ -d ${OUTPUT_DIR} ]]; then
    rm -rf ${OUTPUT_DIR}/*
  else
    mkdir -p ${OUTPUT_DIR}
  fi

  # generate
  npx ng-openapi-gen \
    --input ${API_YAML} \
    --output ${OUTPUT_DIR} \
    --configuration BffApiConfiguration \
    --module BffApiModule \
    --baseService BffApiBaseService \
    --indexFile true \
    --enumStyle alias
else
  echo "File not Found: ${API_YAML} "
  exit 0
fi

echo ""

find ${OUTPUT_DIR} -type f -exec sed -i '/\/\* tslint:disable \*\//d' {} \;
