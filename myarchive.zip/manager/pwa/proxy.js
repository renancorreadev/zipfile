const server = require('node-http-server');
const proxy = require('request');
const { existsSync } = require('fs');

const config = Object.assign(new server.Config(), {
  port: 4200,
  root: `${__dirname}/../dist/browser/`,
});

server.onRawRequest = (request, response, serve) => {
  try {
    let { path } = request.uri;

    if (/\/api/.test(path)) {
      path = path.replace('/api', '');
      proxy(
        {
          url: `${request.uri.protocol}://127.0.0.1:3200${path}${request.uri.search}`,
          encoding: 'binary',
          headers: request.headers,
          body: request.body,
          method: request.method,
        },
        (error, proxiedResponse, proxiedBody) => {
          let body;
          if (error) {
            request.statusCode = 500;
            body = JSON.stringify(error);
          } else {
            body = proxiedBody;
          }
          response.headers = proxiedResponse.headers;
          response.setHeader('Content-Type', 'application/json');

          serve(request, response, body);
        }
      );
      return true;
    } else if (!existsSync(`${config.root}/${path}`)) {
      request.uri.pathname = '/';
    }
  } catch (error) {
    console.error(error);
  }
  return false;
};

Object.assign(config.contentType, {
  svg: 'image/svg+xml',
  woff2: 'application/font-woff',
  woff: 'application/font-woff',
});

server.deploy(config);
